# Morphic

**From captured objects to editable motion.**

Morphic is a browser studio and visual explanation of how captured shape, appearance
and physical simulation fit together. Start with the sloth's observed motion, adjust
its response, or explore everyday objects. Save a portable session, replay an
interaction, export a shape, and follow the article's synchronized visual comparisons.

The sloth uses attributed PhysTwin observations and appearance with Morphic's fitted
response. Scanned and reconstructed examples use assigned behavior. Morphic owns the
simulation, fitting, capture workflow and interactive deployment; upstream reconstruction
and datasets are credited. It does not claim recovered material properties or a new
reconstruction algorithm.

## Run

Node.js 22.12+ and a WebGL 2 browser are required. Examples, local capture storage,
import and interaction need no paid service. New reconstruction requires a configured
GPU worker and is unavailable in a standalone static deployment. See
[GPU setup and pilot results](docs/GPU_SETUP.md).

```powershell
npm ci
npm run examples:download
npm run dev
```

For a prepared Runpod worker, run `npm run studio:gpu -- --help` for first-time
connection setup. Afterwards, `npm run studio:gpu` checks the saved connection
and starts the local studio with the same session deadline and job allowance.
`npm run studio:gpu -- --check` only checks the connection. These commands do
not rent or stop a GPU; see [worker setup](docs/GPU_SETUP.md#connecting-your-worker).

- `/`: the studio, opening on the sloth, with a shared selector for six objects.
- `/article.html`: the educational article with GIFs, comparisons and measured evidence.
- `/?mode=capture`: photo/video review, local storage, optional GPU reconstruction,
  interaction and portable sessions. The glove includes three of its input views.
- `/guide.html`: personal generation requirements and setup.
- `/synthetic.html`: controlled identification experiment and targeted ablations.

`npm run build` creates a portable static `dist/`. `npm run preview` serves it.
Relative build paths support a portfolio subdirectory.

In capture review, tap a photo or sampled video frame to include or exclude it.
Only the selected views are submitted, up to twelve. Saving a capture preserves
all original files and the selection; reopening restores that choice. Older
captures without selection metadata use the default evenly spaced selection.
Browser storage is local to that browser and is not a backup of your originals.

## What the evidence says

A real CO3D toy-truck capture, re-encoded from dataset frames with its room
background intact, completed the studio's twelve-view reconstruction path.
Automatic foreground removal, opening, dragging, portable session export and
offline reopening/replay worked. On 61 reserved frames, mean silhouette IoU was
0.824 for twelve-view TRELLIS, 0.837 for a single-view reference, and 0.877 for an
input-silhouette hull. Both generated meshes received twelve supplied input masks
and camera poses as evaluation alignment aids. Geometry remains imperfect, and
more views did not improve this case. This is one real-capture workflow, not a
general quality benchmark or measured plastic behavior.

The first real-photo reconstruction comparison uses a Deform360 kitchen sponge
and 23 reserved camera views. Mean silhouette IoU is 0.458 for two-photo TRELLIS,
0.445 for the better single-photo run, and 0.636 for a simple two-view visual hull.
All learned outputs receive the same input-only two-view alignment aid; this is
a pipeline comparison on one object with supplied masks/calibration, not proof
of a novel model or ordinary handheld-video reliability. Full methods, missing
views and evidence are in [the capture evaluation](docs/REAL_CAPTURE_EVALUATION.md).

### Observed behavior study

![Observed stretch and Morphic prediction](public/media/measured/sloth-stretch-response.jpg)

The real experiment uses attributed PhysTwin RGB-D observations. It fits sloth lift
and push, validates on double lift, then scores a reserved stretch recording.

| Filtered 3D track RMSE (mm) | Default | Joint fit | Two-region fit |
| --------------------------- | ------: | --------: | -------------: |
| Lift / fit                  |   39.46 |     28.87 |          29.17 |
| Push / fit                  |   69.03 |     36.72 |          36.26 |
| Double lift / validation    |   20.32 |     23.89 |          23.66 |
| Stretch / test              |   28.19 |     27.78 |          28.08 |

Fitting improves reconstruction of its inputs but does **not** reliably improve a new
interaction over the default. Stretch landmark errors are effectively equal. Static
and fitted hand-warp baselines, unsuccessful pilots, all parameter vectors, and
source hashes are retained. Each trial uses an observed initial shape.

A separate synthetic study identifies a two-region response within the same solver
family: 5.50 mm preset, 3.96 mm uniform fit, 0.87 mm regional fit on the primary unseen
action, averaged across three noise seeds. It is not real material recovery.

## Reproduce

The distributed example assets and reports can be inspected without downloading the full research datasets.
To recompute measured scores, create a Python environment using
`requirements-research.txt`, then run:

```powershell
python scripts/fetch-phystwin.py --cases single_lift_sloth single_push_sloth double_lift_sloth double_stretch_sloth --video
python scripts/verify-measured.py
# Optional fresh optimization; existing runs are never overwritten:
python scripts/fit-measured-joint.py --output work/reproduced-joint
```

The verifier recomputes all 24 filtered-track and 24 landmark scores and compares all
four full Python/JavaScript trajectories. The recorded check found zero coordinate
difference. Node timing excludes rendering and video encoding.

```powershell
npm test
npm run build
node scripts/verify-behavior.mjs
```

For the synthetic experiment, use `npm run behavior:study` or
`npm run behavior:fit -- public/behavior/dataset.json work/example-fit.json`.
Create `work` first and use a fresh output path.

For article authoring only, set `MORPHIC_LOCAL_ARTIFACTS=1` before starting Vite.
Generated videos and sessions then also save into `work/video-exports/`. The endpoint
is local, opt-in, and absent from the deployed static application. Ordinary downloads
remain available. Video export uses fixed simulation timestamps, not wall-clock capture.

## Ownership and limits

Morphic independently implements the graph XPBD solver, inverse-fitting experiments,
observation protocol, matching JavaScript deployment, appearance binding, EWA Gaussian
renderer and covariance transport, portable sessions, and evidence/article tooling.
Established methods are attributed; algorithmic novelty is not claimed.

PhysTwin supplies the real observations, generated shape priors, and pretrained
first-frame Gaussian appearances. Morphic did not capture those recordings or train
their appearance. FreeForm/Simplicits official sources and papers were investigated
but are not executed backends here. PhysReal motivates the staged material ablation.
No upstream benchmark is presented as a Morphic result.

The measured graph uses metric coordinates, unit node masses, prescribed hand motion,
and the first observed frame as rest. Its compliance is an effective discrete response,
not Young's modulus. It has no measured force, calibrated mass, self-collision, volume
constraint, or continuum-convergence result. The appearance field can fold during a
large lift; the article shows and quantifies that failure.

The original preset studio retains its separate 1.6 m longest-dimension normalization
and assigned 100 kg/m³ density. Those settings are fictional scene assumptions and
are not transferred into the measured mode. Import accepts static self-contained GLBs;
arbitrary-video reconstruction, fracture, and plastic flow are outside the current scope.

## Documentation

- [Measured data and protocol](docs/MEASURED_DATA.md)
- [Current measured validation](docs/MEASURED_VALIDATION.md)
- [Research choices and primary sources](docs/BEHAVIOR_RESEARCH.md)
- [Runtime architecture](docs/ARCHITECTURE.md)
- [Retained original validation](docs/VALIDATION.md)
- [Observation format](docs/OBSERVATIONS.md)
- [Source asset provenance](docs/ASSETS.md)
- [Third-party attribution](THIRD_PARTY_NOTICES.md)
- [Execution state](EXECUTION_STATE.md)

Morphic was previously named MatterLab. Project code is MIT; third-party works retain
their licenses. No paid compute was used.

## Portfolio delivery

The static application supports a nested path through Vite's relative base. The local
portfolio integration lives at `C:/Users/jaund/Downloads/Portfolio/morphic/`, with its
card in `projects.html` and thumbnail in `assets/figures/morphic-thumbnail.gif`.
It includes the full original studio, observed-behavior mode and both articles.
The current delivery has not been committed, pushed or published to GitHub Pages.
