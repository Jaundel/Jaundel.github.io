# Third-party notices

Morphic's project source is MIT. Third-party works retain their licenses:

| Component                                       | Purpose                                                 | License                               |
| ----------------------------------------------- | ------------------------------------------------------- | ------------------------------------- |
| Three.js 0.180.0                                | Loader, PBR renderer, controls, environment, GLB export | MIT                                   |
| Mediabunny 1.56.2 | Frame-timestamped browser video encoding | MPL-2.0 |
| PhysTwin observations, shape priors, pretrained Gaussians | Real-data fitting and appearance comparisons | Publisher MIT license; attribution below |
| Vite 7.3.6 and its dependency tree              | Local development and static build                      | MIT and dependency licenses           |
| glTF Transform 4.2.1                            | Offline Draco decoding and asset packaging              | MIT                                   |
| draco3dgltf 1.5.7                               | Offline mesh decoder                                    | Apache-2.0                            |
| DM Sans and Space Grotesk, via Fontsource 5.3.0 | Locally bundled typefaces                               | SIL Open Font License 1.1             |
| Poly Haven assets                               | Textured food models                                    | CC0-1.0                               |
| The Met Open Access scans                       | Captured museum objects                                 | Public-domain / CC0; see asset ledger |

Dependency license files are installed with their packages. Bundled runtime license texts are retained in `public/licenses/`, included in the production build. See [asset provenance](docs/ASSETS.md) for individual authors, processing, and primary-source links.

The solver is an independent implementation of established XPBD and tetrahedral interpolation methods, with attribution in [research notes](docs/RESEARCH.md). PhysGaussian, Simplicits, FreeForm, and DecoupledGaussian are cited research; their source code and sample datasets are not redistributed here.

The measured examples derive from Hanxiao Jiang et al., PhysTwin (2025), using the
[official dataset](https://huggingface.co/datasets/Jianghanxiao/PhysTwin) revision
`05665bcd0edad8f069c7def9cbb58d2eb75d68d0`. `public/measured/` includes their generated
shape priors, source images, derived response packages and a filtered SH0 approximation
of two pretrained Gaussian appearances. `public/media/measured/` includes attributed
source-video excerpts with Morphic prediction overlays and simulator renders. The
appearance and source observations were not captured or trained by Morphic. The
publisher's license is retained at `public/measured/PHYSTWIN-LICENSE.txt`. Source hashes
and transformations are documented in `docs/MEASURED_DATA.md` and the measured evidence.

Mediabunny is distributed unmodified as a bundled dependency. Its license and upstream
source location are retained in `public/licenses/mediabunny-MPL-2.0.txt`; the upstream
source is available at https://github.com/Vanilagy/mediabunny.

The optional reconstruction worker invokes Microsoft's official
[TRELLIS](https://github.com/microsoft/TRELLIS) (MIT), source revision
`442aa1e1afb9014e80681d3bf604e8d728a86ee7`, with the public
`microsoft/TRELLIS-image-large` checkpoint. The pilot's T image and three character
views are upstream test inputs, not photographs captured by Morphic. The generated
assets are local inference outputs, not a new Morphic reconstruction algorithm.
Model weights and CUDA dependencies are installed separately on the GPU worker;
their respective upstream licenses apply. TRELLIS.2 remains an unexecuted optional
worker pending authorized access to its gated dependencies. No DINOv3 or RMBG-2.0
weights are redistributed here.

## CO3D baseball glove example

The public baseball-glove demonstration uses CO3D v2 by Jeremy Reizenstein et al.
(https://github.com/facebookresearch/co3d), sequence `601_92967_186813`. Three
aspect-preserving resized input photographs, a TRELLIS-generated derivative mesh,
and a provenance report are provided for noncommercial research/education under
CC BY-NC 4.0. The full license is in `public/captures/glove/LICENSE.txt`.
Seven reviewed photographs were used; reserved evaluation frames were not published.
Morphic assigns the demonstration's behavior; the glove's material was not measured.
