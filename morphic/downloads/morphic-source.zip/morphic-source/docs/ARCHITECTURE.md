# Runtime contracts

The original tetrahedral studio and the measured graph model have distinct numerical
contracts. The observation-fitting extension is documented in [OBSERVATIONS.md](OBSERVATIONS.md)
and [BEHAVIOR_RESEARCH.md](BEHAVIOR_RESEARCH.md). Response fields share this forward
solver with the browser. The following describes the preserved capture studio.

```mermaid
flowchart LR
    A[Static textured GLB] --> B[Validate and normalize]
    B --> C[Triangle occupancy and tetrahedral cage]
    C --> D[Exact barycentric bindings]
    C --> E[120 Hz XPBD worker]
    F[Tick-indexed actions] --> E
    E --> G[Transfer coarse positions]
    G --> H[GPU skinning and normal transport]
    D --> H
    B --> H
    H --> I[Three.js PBR and shadow pass]
    F --> J[Portable session and checkpoint]
    B --> J
    J --> E
```

## Preparation

`src/io/glb.js` checks GLB chunk boundaries and rejects external resources, required unsupported extensions, animation, and skins. The browser uses Three's loader; an independent geometry-only importer drives CLI experiments. All mesh-node world transforms are baked before normalization. The longest dimension is set to 1.6 m; the minimum height starts at 0.25 m.

`cage.js` uses vertical ray parity to fill grid cells and adds cells containing surface vertices. A shared Freudenthal split divides each occupied cell into six consistently connected tetrahedra. Lumped mass is `density × rest volume / 4` per incident tetrahedron. Approximate volume and measured source dimensions must not be confused.

The fractional grid coordinates select a tetrahedron. Four nonnegative barycentric weights sum to one and exactly reproduce a rest vertex and every affine map. Binding refers to node IDs, not tetrahedron orientation, so orienting tetrahedra afterward leaves bindings unchanged. Large open faces or sparse disconnected geometry are not guaranteed to produce a faithful solid; no claim of universal meshing is made.

## Simulation

`solver.js` is DOM-free and runs in Node tests or the browser worker. It predicts positions with gravity and exponential velocity damping, then performs five Gauss–Seidel sweeps at a fixed `dt = 1/120 s`.

For a scalar constraint `C`, with inverse masses `w`, the update is:

```
alpha = compliance / dt²
deltaLambda = (-C - alpha * lambda) / (sum(w * |gradient C|²) + alpha)
deltaPosition = w * gradient C * deltaLambda
```

Each step resets multipliers, then accumulates them across its sweeps. Edges use `C = length - restLength`; tetrahedra use `C = V/V0 - 1`, with analytical volume gradients. Presets change edge compliance, bulk compliance, damping, and friction. They are not calibrated Young's modulus/Poisson-ratio inputs.

Mouse grabs select the nearest cage node to a picked surface location, project motion onto a camera-facing plane, and bound correction speed. Pins and opposing-handle gestures share the constraint path. The floor and slope project nodes; nonnegative surface bindings then preserve the planar half-space. Sphere contact additionally projects the embedded visual vertices through mass-weighted barycentric gradients.

A whole-step backtracking limiter rejects configurations below 2% of a tetrahedron's rest signed volume. If no admissible movement is found within the bounded search, the last valid geometry is retained while simulation time advances. This allows a saturated gesture to release and recover. It can suppress motion and is not a replacement for an energy-consistent inversion barrier or adaptive time integration. `limitedSteps` is recorded in diagnostics.

## Scheduling and replay

The worker accumulates real time into fixed steps, permits up to six catch-up steps per callback, and bounds debt. Under overload it slows simulated time rather than increasing the integration step. Pausing clears wall-clock debt. Rendering receives at most roughly 60 snapshots per second. Histories longer than ten minutes are paused at the runtime boundary.

Inputs are applied in worker arrival order and stored at the current integer tick. Session schema 1 includes engine version, `dt`, iteration count, density, resolution, all actions, source GLB, its SHA-256, and final Float64 node positions. Replay rebuilds from rest and recomputes the trajectory, then compares against the checkpoint. It does not animate cached frames.

This release verifies exact same-runtime replay. Float32 render transport does not overwrite Float64 solver state. Cross-engine or cross-architecture bitwise equivalence is not guaranteed. Version or asset-hash mismatches fail explicitly. Imports never execute code from the session.

## Rendering and export

`skinning.js` uploads a float texture containing coarse node positions. Per-vertex node IDs, weights, and rest normals remain on the GPU. The vertex shader evaluates four-node interpolation. It constructs `F = Ds × inverse(Dm)` and transforms the rest normal by `transpose(inverse(F))`; texture coordinates remain unchanged. The depth material uses the same position deformation, keeping shadows attached.

The `?cpu=1` path updates positions and reconstructs surface normals on the CPU. Its normals are averaged over visual triangles, so shaded pixel agreement with the piecewise tetrahedral normal transport is not expected under deformation. Rest images and silhouette positions are the appropriate geometric checks.

CPU surface positions are refreshed on demand for ray picking and export. Export snapshots the current mesh with textures; simulation-specific attributes are omitted. GPU textures, geometries, and material resources are disposed when replacing an object. The browser holds captures locally and sends no capture data to a service.

## Boundaries

In the original preset mode, only one object is simulated. Self-contact, fracture, plasticity and material recovery are not implemented in that mode. Contact is discrete; rapidly moving thin structures can tunnel. A proxy can bridge narrow gaps. Finite-iteration solutions and preset response depend on resolution; automated numerical evidence defines the validated cases rather than a promise of arbitrary physical accuracy.

## Measured graph mode

`bootstrap.js` selects the preserved studio or `measured-studio.js`. Its declarative
layout is `measured-studio.html`. Both modes reuse capture import, rendering utilities,
interaction conventions, and exports. Measured import disables scene normalization.

`measured_graph.py` prepares a deterministic 320-node graph, local object springs,
controller springs and four-node inverse-distance displacement bindings. It fits
parameters with SciPy on the CPU. `measured-graph.js` implements the same fixed-step
XPBD update; full trajectory parity is checked by `verify-measured.py`. The graph has
unit masses and no tetrahedral volume constraint. It is not a transfer of the old
preset parameters, nor an implementation of FreeForm or Simplicits.

A serialized graph includes rest coordinates, connections, edge rest lengths, material
regions, controller trajectories, all numerical settings and response parameters.
Observations are stored separately for scoring and article overlays. Rollout needs
only the serialized graph and loading. The browser never fetches later observations
for stepping; its calibration file is used only for a display camera.

`recorded-camera.js` maps OpenCV extrinsics into Three.js and preserves camera
intrinsics with letterboxing. Physics remains in dataset metres. Display rotation,
centering and scale never feed back into the recorded loading or fitted model.

`gaussian-appearance.js` performs SH0 EWA rendering, depth sorting, four-node center
transport and covariance push-forward. The nearest-node displacement field reproduces
translations, not arbitrary affine maps; it can fold. This differs from the original
studio's affine-exact tetrahedral embedding. The article makes that boundary visible.

Measured sessions embed the response, original GLB, optional packed Gaussian appearance,
hashes, actions and final node positions. `measured-session.js` validates the action
log before replay. Replay recomputes states and reports drift. Intentional edits remain
separate from the frozen response. GLB export carries the deformed mesh proxy; Gaussian
appearance remains available in the saved session.

Video export locks renderer dimensions, advances exactly one recorded frame at a time,
and uses Mediabunny/WebCodecs with explicit frame timestamps. Slow rendering affects
export duration, not simulation speed in the encoded video. An opt-in Vite plugin can
save local authoring artifacts; static deployments have no filesystem endpoint.
