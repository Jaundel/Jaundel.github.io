# From observed motion to editable objects

The canonical visual article is [article.html](../article.html). It contains real
recordings beside simulated appearance, synchronized landmark comparisons, the frozen
result table, interactive response editing, a mesh/Gaussian comparison, and a visible
late-lift failure. It follows the typography and spacing of the existing portfolio.

The prior controlled experiment is preserved at [synthetic.html](../synthetic.html).
The original pre-behavior article remains [ARTICLE_BASELINE.md](ARTICLE_BASELINE.md).

## Thesis and limits

Morphic turns observed motion into a portable, editable response asset and evaluates
it on a separate recording. Fitting improves the training recordings; it does not
reliably improve the reserved interaction over an unfitted reference. The article
reports that negative result rather than treating reconstruction as prediction.

Appearance reconstruction and RGB-D acquisition are credited to PhysTwin. The local
contributions are the compact XPBD adaptation, inverse-fitting experiments, deployment
parity, browser Gaussian transport, reproducible evidence, and interaction/export/replay.
FreeForm, Simplicits, PhysReal and PhysGaussian are explained at the level actually used.

## Article structure

1. A reserved stretch recording beside its full-appearance simulated prediction.
2. Lift and push fitting, including the failed lift-only fit.
3. Validation and test comparisons with all frozen model scores.
4. Compact graph, explicit physical assumptions, and implementation consistency.
5. Regional fitting: positive synthetic control, unhelpful real-data capacity.
6. Intentional material editing under identical loading.
7. Appearance comparison and a quantified folding failure.
8. Reproduction, evidence, and method attribution.

All displayed measurements originate in the local evidence reports. Videos preserve
the source time base. Deliberate edits are not scored as recovered material behavior.
