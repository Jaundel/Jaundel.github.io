# From a captured object to an object you can touch

Morphic begins where a 3D viewer usually ends. A museum scan arrives as geometry and texture: it can be inspected, but it has no response to a hand, gravity, or a surface. Morphic builds a physical representation around that capture, lets it deform, and keeps a record of the experiment that can be replayed.

![A scanned tablet in the physical studio](media/met_tablet-deformed.png)

The current collection includes a documented Met scan of a proto-cuneiform tablet and a Moche vessel, alongside two textured food assets. The original surface remains recognizable during deformation. Assigning jelly to the tablet is deliberately fictional; the system does not claim to recover the properties of ancient clay.

## Two resolutions, one object

The tablet has nearly 100,000 triangles. Using every visual vertex as a physical unknown would make the interaction budget unnecessarily expensive. Instead, the runtime constructs a coarse tetrahedral volume and binds each original vertex to four simulation nodes.

The embedding has a concrete contract: at rest it reconstructs the original vertex; under any affine deformation it reconstructs that deformation exactly. That is stronger than choosing nearby handles and hoping their weighted displacement looks right. Tests enforce the contract.

The simulation runs at 120 Hz in a worker. It owns mass, velocity, edge and volume constraints, handles, and contacts. The renderer receives coarse node positions, then evaluates surface positions and inverse-transpose normal transport on the GPU. The same deformation is used for the shadow pass.

## The optimization had to preserve the result

On the tested Radeon 860M laptop, the tablet's GPU path ran at approximately 60 FPS while the CPU reference averaged about 11 FPS. Those numbers compare complete update strategies; they are local observations rather than universal claims.

Keeping the reference exposed a bug: the museum GLB stored positions, normals, and texture coordinates in an interleaved buffer. A packed-array update accidentally overwrote neighboring attributes. Fixing the update made the two rest images agree to about 0.000019 display levels of mean absolute error on the 0–255 scale. The optimization only became a credible result after that check.

## A failure worth showing

An aggressive squash inverted two tetrahedra near the vessel's thin features. The runtime now limits steps that would destroy orientation and allows release to recover. This makes the tool more robust, but it can clip requested motion. The exact failing run, an unsuccessful guard, and the accepted rerun remain in the evidence directory.

The physical model is deliberately bounded. It uses established compliant constraints rather than a calibrated material model. The volume proxy can bridge gaps, and the sphere-contact case can saturate. Those limits are measurable engineering problems, not details to crop out of a demo.

## Replay is an experiment

A saved session contains the original capture, its hash, solver settings, and a tick-indexed list of actions. Loading it rebuilds the object and recomputes the trajectory. It then checks the result against stored final node positions. All twelve tested object/material trajectories reproduced exactly within the same runtime.

This makes an interaction inspectable: the same action sequence can be retained when the solver changes, and differences can be measured instead of judged only from a video.

## What the research contributed

PhysGaussian established the importance of evolving appearance with deformation, not moving primitive centers alone. Simplicits demonstrated an occupancy-based interface between representation and reduced simulation. FreeForm made corrected particle kernels and skinning eigenmodes a particularly attractive next backend. Morphic's current solver is an independent XPBD implementation, and its research contribution is not claimed to be a new physical method.

The present engineering result is the complete capture-to-interaction runtime: preparation, numerical behavior, GPU transport, mouse input, contact, export, and verifiable replay. The next substantial step is a calibrated constitutive reference and a matched comparison with the actual FreeForm implementation.

**Accompanying material:** [demo video](media/morphic-demo.webm), [validation](VALIDATION.md), [research sources](RESEARCH.md), and [asset credits](ASSETS.md).
