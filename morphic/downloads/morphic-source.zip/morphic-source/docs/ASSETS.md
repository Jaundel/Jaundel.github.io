# Asset provenance

The asset bytes, processing, and SHA-256 are recorded in [`public/assets/manifest.json`](../public/assets/manifest.json). The studio preserves surface geometry, UVs, and textures while replacing its deformation; it does not infer the original material.

| Asset                                                                  | Provenance                                                                                                                     | License                         | Processing                                                          |
| ---------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ | ------------------------------- | ------------------------------------------------------------------- |
| [Lemon](https://polyhaven.com/a/lemon)                                 | Kuutti Siitonen / Poly Haven. Textured model; the inspected metadata does not prove its capture procedure.                     | CC0-1.0                         | Original 1K glTF and textures losslessly packaged into GLB.         |
| [Sweet potato](https://polyhaven.com/a/sweet_potato)                   | Jan Martens / Poly Haven. Textured model; acquisition method unverified.                                                       | CC0-1.0                         | Original 1K glTF and textures losslessly packaged into GLB.         |
| [Clay tablet](https://www.metmuseum.org/art/collection/search/329081)  | The Metropolitan Museum of Art, Met Imaging. Proto-cuneiform tablet, ca. 3100–2900 BCE; object 1988.433.1.                     | Public-domain / CC0 Open Access | Museum optimized GLB, Draco decoded without further simplification. |
| [Moche bottle](https://www.metmuseum.org/art/collection/search/308558) | The Metropolitan Museum of Art, Met Imaging. Tuber-inspired stirrup-spout bottle, Moche artists, 600–800 CE; object 64.228.57. | Public-domain / CC0 Open Access | Museum optimized GLB, Draco decoded without further simplification. |

The Met's [2026 release announcement](https://www.metmuseum.org/press-releases/3-d-models-announcement-2026) identifies these collection releases as scans, with the initial 100 produced by Met Imaging, and describes the majority as downloadable under CC0. Both selected collection records mark the objects Public Domain and provide the 3D/download interface. The asset endpoints are the museum's public Vntana delivery URLs. Source hashes and derived hashes are separate. The public third-party [catalogue](https://github.com/InconsolableCellist/met_scans) was a discovery aid; attribution and rights are grounded in the museum's own pages.

Poly Haven's [asset license](https://polyhaven.com/license) permits redistribution and adaptation under CC0. Its website and branding are not included.

The Met's authentic artifact names and context are retained here. The simulated material presets are creative experiments on digital copies, not claims about historic artifacts' actual mechanical properties.

An initially considered hand-painted avocado model was rejected as evidence of real-world capture. The Stanford repository was also considered but not used: the retrieved source text includes additional use restrictions, so an assumed permissive license from a third-party summary was insufficient.

Rebuild assets with `npm run assets`. It downloads roughly tens of megabytes of public data, verifies Poly Haven file MD5 checksums, packages textures, decodes museum Draco geometry, and writes new provenance hashes. The original museum meshes already represent upstream optimization of higher-resolution scans. No original photographs were available for photometric comparison.
