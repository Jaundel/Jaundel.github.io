# Capturing behavior in Morphic

## Measured-stage decision

The compact graph backend now fits PhysTwin recordings and deploys with exact local
Python/JavaScript trajectory parity. Lift and push fitting improve, but double-lift
validation is worse than the default and reserved stretch errors are nearly equal.
Two regions add little. Keep the uniform model and report those outcomes; more fitting
capacity is not supported by this result. Full tables: MEASURED_VALIDATION.md.

The Gaussian path earns a narrow role through the visible fur/detail comparison. It
uses attributed upstream first-frame appearance with independent browser transport,
not PhysGaussian MPM. The appearance map can fold at large deformation. FreeForm and
Simplicits remain unexecuted alternatives: the current CPU physics cost is small,
and no fidelity gain has been measured for a replacement. The earlier audit below
is preserved as the decision history, not a statement that measured data are absent.


## Initial controlled-stage decision

Morphic should be organized around one question: **does a response fitted from one
interaction predict another?** Its appearance renderer, interaction tools, and replay
system are useful infrastructure for this question. A second solver is valuable only
when it makes that result more accurate, more expressive, or cheaper to deploy.

The implemented first stage keeps the XPBD engine and adds bounded inverse fitting,
two-region response fields, held-out evaluation, material editing, and a synchronized
article. This is an independent engineering synthesis. It is neither a reproduction
of an upstream complete pipeline nor a novel constitutive model.

The result at that stage was explicitly synthetic. It establishes that the observation
contract and optimizer can recover a useful response in the same model family.
It does not establish real material capture, continuum convergence, generalization
across objects, or accuracy of the existing museum assets' assigned behavior.

## What the repository already provides

The inspected baseline is commit `2eb91199f1e27285b4fcda42df3d85b404ce61d8`.
It separates detailed textured appearance from a coarse tetrahedral cage; uses
edge and relative-volume XPBD constraints; implements GPU surface deformation and
normal transport; supports mouse loading, contacts, GLB export, and action replay.
The baseline's 13 Node tests passed before changes. Its older performance and contact
results remain in the original validation files, with their original scope.

The research bottleneck is identification, not rendering capacity. Existing preset
names are artistic settings. Normalizing a scan to a 1.6 m extent and assigning
100 kg/m³ density cannot recover its material properties. The new experiment instead
uses explicitly known metre coordinates and records every numerical assumption.

## Primary research and official implementation audit

### PhysTwin

PhysTwin fits a spring-mass representation from RGB-D observations and couples it
to Gaussian appearance. Its method separates fitting from future and novel-interaction
evaluation. Its sparse-to-dense fitting motivates starting with few parameters. The
paper's physical parameterization, controller springs, and integration are not
Morphic's XPBD formulation. [Paper, Jiang et al., ICCV 2025](https://arxiv.org/html/2503.17973v1).

The official trainer constructs graph connectivity, passes tracked observations and
visibility to the Warp simulator, and optimizes spring quantities using Adam. The
runtime defaults to CUDA. Its repository also documents Windows setup, so Windows
alone is not the limiting factor on this machine. No upstream rollout was executed.
[Official trainer](https://github.com/Jianghanxiao/PhysTwin/blob/main/qqtt/engine/trainer_warp.py),
[setup and data](https://github.com/Jianghanxiao/PhysTwin).

**Adopt:** action/observation separation and global-to-local identification.
**Do not import:** its fitted spring coefficients into XPBD.

### FreeForm

FreeForm builds material-aware skinning eigenmodes using corrected RKPM kernels and
a generalized eigenproblem, then performs reduced nonlinear elastic dynamics.
It is a representation/simulation method, not an observation-fitting system.
Sharp contact, high-frequency deformation, and kernel conditioning matter for
its use here. [Paper, Xiang et al., CVPR 2026](https://arxiv.org/html/2605.29318v1).

The local official Kaolin snapshot is
`d52da9f86d460e8abcd99037e21ff0bec57997ed`. Inspection covered `rkpm.py`:
coordinate normalization, farthest-point samples, SciPy neighborhood radii, corrected
kernel solves, mass/Hessian construction, and `torch.lobpcg`. It is not an
ordinary graph-Laplacian basis. [Official implementation](https://github.com/NVIDIAGameWorks/kaolin/blob/d52da9f86d460e8abcd99037e21ff0bec57997ed/kaolin/physics/simplicits/rkpm.py).

**Decision:** defer execution until a calibrated continuum reference and a supported
environment exist. The first comparison must hold geometry, material law, loading,
and quadrature fixed. Measure preparation, solve time, and deformation error
separately. Recompute or validate the basis after material edits; a material-dependent
basis cannot be assumed valid for every edited field.

### Simplicits

Simplicits uses an occupancy interface and per-object neural skinning weights trained
with physical energy and orthogonality objectives. Reduced coordinates can therefore
drive different appearance representations. [Paper, Modi et al., SIGGRAPH 2024](https://arxiv.org/html/2407.09497v1).

The original repository snapshot is
`691b285a6216f0b9013469df2288a5b05c979b1c`. The training code selects CUDA, MPS,
or CPU and computes deformation gradients for elastic-energy losses.
The simulation interface exposes boundary conditions and reduced implicit solves.
CPU selection is not a benchmark or proof that the modern Kaolin dependency chain
works locally. [Official training implementation](https://github.com/itsvismay/simplicits/blob/691b285a6216f0b9013469df2288a5b05c979b1c/3-Training.py).

**Decision:** use it as the conceptual comparator if FreeForm is evaluated.
Do not add per-object neural training merely to acquire a research backend.
Morphic already separates physical state from appearance, although its discretization
is tetrahedral rather than occupancy-only.

### PhysReal

PhysReal's September 2026 preprint progresses from global properties to local material
patches and then neural constitutive corrections within differentiable MPM.
This ordering motivates a capacity ladder: add parameters only after the simpler
model has a repeatable predictive failure. [Paper, Deng et al., 2026](https://arxiv.org/html/2609.07532v1).

The [linked project page](https://physreal.github.io/anonymous_web/) was inspected,
including its links. No official simulation/training code was linked there during
this audit. An official implementation was therefore not inspected or executed.
This is an availability limitation, not evidence against the method.

**Adopt:** progressive global-to-local fitting. **Defer:** neural stress and plasticity
residuals until real residuals establish their necessity. Two XPBD regions reproduce
the organizational idea, not PhysReal's mechanics.

### PhysGaussian

PhysGaussian evolves Gaussian appearance with physical deformation and uses MPM.
It is relevant when splats provide a demonstrated capture-quality benefit.
[Paper, Xie et al., CVPR 2024](https://arxiv.org/html/2311.12198v1).
The official `gs_simulation.py` driver initializes CUDA-oriented dependencies
and Gaussian/MPM state. The retained local snapshot is
`8339ed6aa2cd5d50e1001a254a3d95aea678a956`.
[Official driver](https://github.com/XPandora/PhysGaussian/blob/8339ed6aa2cd5d50e1001a254a3d95aea678a956/gs_simulation.py).

**Decision:** retain textured meshes. No local result establishes a splat advantage.
Source, weights, sample assets, and renderer licenses need separate review before
redistribution. No upstream source or assets were copied into the new implementation.

## Newer work that changes the decision

[DeformMaster, Li et al., 2026](https://arxiv.org/html/2605.09586v1) emphasizes
distributed compliant actuation as well as physics-neural dynamics. Its relevance
is a warning: uncertain contact/loading can masquerade as wrong material.
Record support, actuator trajectory, and attachment geometry before increasing model
capacity. A prescribed point handle is an intentionally restricted first protocol.

[PhysWorld, Yang et al., 2025](https://arxiv.org/html/2510.21447v1) uses fitted
physics to synthesize demonstrations for a learned dynamics model.
That is a potential deployment path when throughput becomes a measured obstacle.
It introduces another approximation to validate and is unnecessary for the small
current runtime.

[PhysCoRe, 2026](https://arxiv.org/html/2607.20653v1) investigates
physics-corrected residual dynamics and confidence. It reinforces the value of
explicit model-mismatch detection, but does not justify adding a residual learner
before Morphic has real observations.

[PokeFlex, Obrist et al.](https://pokeflex-dataset.github.io/) provides a more
useful data lead than uncalibrated internet video: textured geometry and motion
paired with robot interaction information. Its [data portal](https://pokeflex.ait.ethz.ch/)
requires registration. No account was created, terms accepted, or data claimed as
evaluated. PhysTwin's public data archives are an alternative, but their full
preprocessing and geometry/loading alignment remain work to execute.

## Architecture and compatibility

The physical state remains `(x, v)` in the existing solver. A response field supplies
one or two edge compliances, one bulk compliance, one damping rate, and friction.
For two regions, rest-space edge midpoints select a side of an explicit split plane.
Topology and mass remain fixed. There is no smoothness prior across that boundary;
the boundary is supplied, not discovered.

The optimizer minimizes mean squared Euclidean marker error over fitting trials.
It searches positive compliance and damping in log space with bounded coordinate
pattern search. The global stage fits two parameters; the regional stage fits three.
Bulk compliance, friction, and the split are held fixed. This is a modest,
inspectable derivative-free baseline, not a claim of global optimality.

Trial input contains loading events separately from sparse observations. Missing
markers are omitted; optional positive weights express confidence. Markers can
reference cage nodes or embedded input vertices. The prediction function receives
only loading and requested output times. The fitting API rejects test-role trials.
Neither barrier prevents deliberate relabeling by an operator; published split
provenance and input hashes remain necessary.

The physical asset stores exact rest geometry and connectivity, solver settings,
field coefficients, SI-unit declaration, and provenance. Deployment refuses a changed
geometry or configuration. Material edits get an explicit intervention provenance.
Replay version 3 supports response events and retains version-2 baseline compatibility.
The browser and CLI import the same forward solver.

## Evidence and its interpretation

The exact controlled specimen is 0.24 × 0.72 × 0.24 m, with 63 nodes and 144
tetrahedra. Density is prescribed at 100 kg/m³, so its discrete mass is 4.1472 kg.
It is a test specimen, not an estimate of any museum object.
The coarse scan-envelope fixture used during development introduced irregular
boundary cells; it was replaced to remove that unnecessary confound from this study.

The experiment uses a uniform negative control and a heterogeneous target, each
with three noise seeds. The test actions change direction/amplitude and then
attachment point. Both fits use identical fitting observations. Results include
all current cases, sparse-observation ablation, iteration/timestep changes,
intentional bulk-model mismatch, and exact action replay.
See [raw results](evidence/behavior/results.json) and the [controlled interactive article](../synthetic.html).

A same-solver inverse test is deliberately easier than reality. It should succeed
before real capture is attempted, but cannot establish physical correctness.
Iteration sensitivity is especially informative: it shows why fitted compliance
cannot be advertised as a resolution-independent material property.
The original analytical spring and mass tests remain useful implementation checks;
they do not calibrate the tetrahedral continuum.

## Stages that would justify a stronger article

1. **Measured response:** obtain one usable measured object with dimensions, mass,
   unloaded geometry, supports, actuator path, and tracked motion. Preserve a separate
   trial before fitting. Report marker/force units and synchronization uncertainty.
2. **Forward-model decision:** compare XPBD's held-out residual with a calibrated
   constitutive reference. Establish time and spatial convergence before reporting
   Young's modulus. Keep XPBD if predictive response is adequate within a declared
   operating range; replace it if its discretization limits dominate.
3. **Regional capacity:** use additional regions only if a validation trial supports
   the added capacity. Keep final test observations untouched during selection.
   Test several intervention amplitudes and report failure under extrapolation.
4. **Appearance and editing:** render the same captured object under predicted motion,
   compare synchronized held-out views, then demonstrate a clearly labeled material
   intervention. Capture quality and motion accuracy need separate metrics.
5. **Compact deployment:** evaluate actual FreeForm and Simplicits against the same
   converged reference. Refitting in the deployed reduced model or quantified transfer
   error is mandatory. Gaussian appearance and learned residuals must each earn
   their cost through a targeted comparison.

Local inspection found a Ryzen AI 7 350 and Radeon 860M. This stage uses Node and
the existing browser stack; no paid service, rental, or upstream GPU training was
started. A later GPU request should specify the exact reference experiment,
supported environment, expected runtime, and a spending cap before approval.
