# Behavior-capture validation

This is a synthetic identification result, not measured physical capture.
The complete experiment and all attempted cases are in
[results.json](evidence/behavior/results.json). The interactive article consumes the
[serialized bundle](../public/behavior/study.json) directly.

## Protocol and outcomes

Known 0.24 × 0.72 × 0.24 m specimen; exact conforming mesh of 63 nodes and 144
tetrahedra. Prescribed density 100 kg/m³, zero gravity, pinned base, compliant
single-node handle, timestep 1/120 s and 12 solver iterations.
Training uses a 55 mm x pull and release. Primary test uses a 75 mm z pull.
The second test pulls 60 mm in negative x from a lower attachment on the opposite side.

Markers exclude the base and directly controlled node. Noise is independently
sampled per coordinate from a bounded distribution with standard deviation 0.5 mm.
Three seeds (1, 7, 23) are used for both the uniform and two-region specimens.
All models use the same fitting observations. Test motion never enters optimization.

Mean held-out Euclidean point RMSE, millimetres:

| Specimen   | Test action      | Preset | Uniform fit | Regional fit |
| ---------- | ---------------- | -----: | ----------: | -----------: |
| Uniform    | Larger z pull    |  4.938 |       0.865 |        0.866 |
| Uniform    | Lower attachment |  6.286 |       0.876 |        0.879 |
| Two-region | Larger z pull    |  5.497 |       3.963 |        0.867 |
| Two-region | Lower attachment |  7.122 |       5.063 |        0.882 |

The 3D noise floor is approximately 0.866 mm. Extra regional capacity helps the
heterogeneous specimen and adds little to the uniform negative control.
Three noise realizations do not establish generalization across objects or a
population-level confidence interval. Seed-level RMSE and maximum errors are retained.

## Targeted boundaries

For the heterogeneous specimen, seed 1:

- Regional fitting with only one observed marker per frame leaves 1.464 mm test RMSE.
  Both global and regional sparse fits are recorded, preserving the capacity comparison.
- Holding fitted coefficients fixed but changing iterations to 6 or 24 gives
  7.879 and 6.011 mm error, respectively, versus 0.864 mm at the fitted 12 iterations.
- Halving the timestep while preserving physical action/observation times gives
  8.196 mm error. Increasing numerical resolution is not parameter-preserving.
- Doubling the hidden density while retaining the fitted model gives 3.546 mm error.
  This quantifies a known-mass assumption violation, not a new constitutive effect.
- Changing only hidden bulk compliance produces 0.119 mm error against noiseless
  observations. This is a weakly excited quantity under bending, not a successful
  recovery of bulk properties. Its noise condition differs from the main tests.

No reported candidate result activates the orientation limiter. The optimizer
rejects clipped candidates; the full candidate histories record rejected losses as
null rather than presenting them as successful fits.

## Execution and deployment

Both fitting stages together took 8.20–8.49 seconds per case on the Ryzen AI 7 350,
Node v24.15.0, Windows. A warmed Node rollout including setup/session recording,
divided by its 180 steps, measured 0.307 ms median and 0.349 ms P95 across ten runs
after two warmups. This is not isolated kernel timing, browser FPS, or latency.

An independent CLI invocation on the serialized dataset reproduced the regional
field exactly. The verification script checks source/data hashes, exact geometry
deployment, both test scores, every regional trajectory coordinate, and zero
same-runtime action-replay drift.

The new response field is carried by replay engine 3. Engine-2 baseline sessions
remain accepted. Initial gravity and material settings are now included in new
sessions so constructor settings survive replay.

## Checks run

- `npm test`: 21 tests passed.
- `npm run build`: both studio and article built. The large shared Three.js chunk
  produces Vite's size warning; the build succeeds.
- `npm run format:check`: passed.
- `node scripts/verify-behavior.mjs`: hashes, serialized deployment, scores,
  trajectories and replay passed.
- `npm run behavior:fit -- public/behavior/dataset.json work/fit-verification.json`:
  field and scores matched the study.
- `python scripts/browser-behavior-check.py --url http://127.0.0.1:4174`:
  production-build Chrome checks passed with no page/console errors.

The browser check exercises fitting/test comparison, both novel actions, playback,
material editing, asset export/reload, incompatible-timestep rejection and 390px
overflow. All four original captures load, stretch, save and replay. Exported GLB
header validation is a smoke check, not a new complete appearance-quality evaluation.
[Browser report](evidence/behavior/browser-check.json).

## Scope that remains open

No real-object observations, held-out recordings, or held-out appearance measurements
were evaluated. No converged FEM reference or official FreeForm/Simplicits simulation
was executed. The new result does not resolve the original contact, geometry-envelope,
or extreme-deformation limits. The exact known specimen intentionally avoids those
confounds while establishing inverse fitting.

The previous article and manifest are retained as
[ARTICLE_BASELINE.md](ARTICLE_BASELINE.md) and
[baseline-manifest.json](evidence/baseline-manifest.json).
The new delivery manifest records file identity across this stage; it is not
independent experimental attestation.
