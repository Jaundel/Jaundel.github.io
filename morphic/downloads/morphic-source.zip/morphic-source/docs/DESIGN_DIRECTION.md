# Morphic presentation

The recognizable object and its measured response carry the page. Comparison views
share one clock and camera. Each caption identifies the recording, fitting input,
prediction, or intentional edit. The studio retains its useful controls and replay.

Palette follows the existing SEVEN and Neural Biome portfolio articles: white
`#ffffff`, ink `#222222`, blue links/interaction `#1d63b7`, secondary text `#626b73`,
rules `#dce1e6`, and a pale neutral 3D floor `#f5f7fa`. Blue denotes an available
interaction; data-series colors get their own persistent legend. Errors use
`#ad3d25` with explanatory text.

Studio typography retains DM Sans and the established Morphic wordmark. Article
typography follows the portfolio's Helvetica Neue/Arial headings and Georgia prose.
Keep body lines near 65–75 characters. Use modest headings, generous spacing around
demonstrations, and expandable technical explanations. Avoid decorative counters,
arbitrary section numbers, and metrics that distract from the experiment.

Article sequence: recognizable object responding → source recording and fitted
motion → unseen interaction → what changes with extra material capacity → intentional
editing → explicit failures and assumptions → reproducibility and attribution.
The existing synthetic fixture belongs in the explanatory/validation material.

Review: a generic hero with performance badges would obscure the question. Lead
with synchronized object motion, keep the navigation quiet, and place results beside
the corresponding recording. Do not write a success headline before measurement.
