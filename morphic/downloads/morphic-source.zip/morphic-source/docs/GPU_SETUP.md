# Personal reconstruction

The public studio has no shared inference service. New objects use your compute.
The sloth and all prepared examples work with WebGL 2, without a CUDA GPU.

## Local Linux GPU

Install the official [TRELLIS environment](https://github.com/microsoft/TRELLIS#-installation).
Upstream requires Linux and an NVIDIA GPU with at least 16 GB VRAM. This integration
was exercised on A100 80 GB; other hardware is unverified. AMD integrated graphics
cannot run this CUDA backend. Installation is manual, not a one-click installer.

For the recorded configuration use TRELLIS commit
`442aa1e1afb9014e80681d3bf604e8d728a86ee7` and the worker's default immutable
checkpoint revision `25e0d31ffbebe4b5a97464dd851910efc3002d96`.
The auxiliary DINOv2 loader uses upstream main, a reproducibility limitation.

Run in the activated TRELLIS environment from the Morphic source folder:

```sh
python scripts/reconstruct-baseline.py --source /path/to/TRELLIS \
  --images /path/to/front.jpg /path/to/back.jpg --output /path/to/new-object
```

Choose a new output directory. Keep the object still in overlapping views. The worker
writes `asset.glb` and `result.json`, or a failure report. Select both completed files
using **Save and open → Open 3D file** in the capture workspace. Shape completion is
generated, and behavior is assigned. This does not measure material properties.

## Prepared Runpod worker

Use your own account and budget. The tested configuration is an A100 worker with
the official Runpod PyTorch image, CUDA toolkit 12.8 and 100 GB ephemeral disk.
Configure your existing SSH key and verify the worker's SSH identity normally.

On the worker, clone official TRELLIS recursively into `/workspace/TRELLIS`, check
out the revision above and update its submodules. Copy `setup-runpod-baseline.sh`,
`reconstruct-baseline.py` and `reconstruct-trellis.py` from Morphic's `scripts/` to
`/workspace`. Run `bash /workspace/setup-runpod-baseline.sh`. This installs the
tested Python 3.11 / torch 2.6 / CUDA 12.4 dependency stack and compiled extensions.
Installation and model downloads can take substantially longer than inference.

On your own computer, inside Morphic:

```sh
npm ci
npm run examples:download
npm run studio:gpu -- --host YOUR_HOST --ssh-port YOUR_PORT --key YOUR_KEY_FILE --until ISO_UTC_DEADLINE --jobs 2
```

Use a timezone-bearing deadline at least sixteen minutes in the future. Use `--help`
for options. `--check` performs a read-only readiness check. Later `npm run studio:gpu`
reuses the original deadline and job allowance; it does not silently renew them.
The local server binds to loopback. Credentials never enter the browser bundle.

Select photos/video, review the sampled views, and create an object. One job runs at
a time. Completed results are retained in `work/reconstruction-jobs` and can reopen
without the worker. Save a portable session before moving between computers.

The launcher does not rent or stop hardware. The deadline limits submissions, not
billing. Download your outputs and stop the worker yourself. If a connection is
interrupted, check the existing job before resubmitting.

The seven-photo glove test completed in 125.85 seconds after installation, including
96.78 seconds loading/preprocessing, 6.37 seconds inference and 22.70 seconds export.
This is one measured run, not a promised latency. Warm batch inference is not implemented.
