# PhysTwin observations in Morphic

## Provenance

Dataset: [Jianghanxiao/PhysTwin](https://huggingface.co/datasets/Jianghanxiao/PhysTwin),
revision `05665bcd0edad8f069c7def9cbb58d2eb75d68d0`, labelled MIT by its publisher.
The selected source files and SHA-256 checksums are in the download manifest.
`scripts/fetch-phystwin.py` downloads exact ZIP members by HTTP ranges and validates
ZIP CRCs. A restricted NumPy unpickler reads data arrays; it does not permit arbitrary
Python globals. The large original archive need not be extracted.

Official code inspected at `81c718790a37e5e0102eb77af2c6edd34a9db25f`:
`qqtt/model/diff_simulator/spring_mass_warp.py`, `qqtt/engine/trainer_warp.py`,
`configs/real.yaml`, and the preprocessing scripts. Morphic's simulator is an
independent XPBD implementation; it is not the authors' explicit Warp integrator.

## What the source contains

The 30 fps recordings provide filtered RGB-D point tracks, visibility/motion-validity
flags, rigidified hand-controller trajectories, and an initial appearance prior.
Coordinates are metres; negative Z is above the table. Upstream preprocessing clamps
tracked Z coordinates below the table to zero. The validity filter uses neighboring
track motion and excludes the last frame. Accordingly, these are processed motion
observations, not calibrated motion-capture or force ground truth.

The textured GLB is generated using a first-frame image and TRELLIS, then aligned to
RGB-D coordinates. Surface and interior samples come from that mesh. Do not describe
it as a complete measured scan, or attribute the upstream reconstruction to Morphic.
Morphic retains the supplied appearance and fits its own response model.

Mass, applied force, and unloaded rest geometry are absent. The model uses unit node
masses, gravity, an observed first-frame rest state, and a fixed graph discretization.
Its fitted compliance is an effective response parameter. No Young's modulus, density,
or force accuracy can be inferred from this experiment.

## Protocol and development record

Initial pilot: fit all sloth-lift frames; evaluate sloth-push as development data.
The uniform fit improves the lift but worsens the push relative to the default graph
parameters. The two-region lift fit barely improves the fitting residual. These
negative results are retained in `evidence/measured/`, together with the exact pilot
source. The pilot settings are not the original studio's artistic presets.

The revised experiment fits lift and push together to constrain response and table
friction. Double lift is validation. The entire double-stretch recording was reserved until model selection, then scored
once in final-comparison-01.json. It is now opened test evidence, not a fresh tuning set. First-frame geometry and hand loading may be used to
initialize a test; subsequent object motion may only be used for scoring after model
selection. Report that this is transfer conditional on each trial's initial geometry,
not deployment of an identical unloaded mesh under every trial.

The graph uses 320 farthest-point samples, radius-limited nearest-neighbor springs,
distributed controller springs, eight substeps per 30 fps frame, and five XPBD
iterations. Appearance and observation markers use rest-space displacement weights.
Morphic's Python preparation and JavaScript deployment have reproduced the full
trajectories of all four frozen sloth trials with zero coordinate difference.
That verifies implementation consistency, not physical accuracy.

## Reproduce locally

Use Python 3.12 in an isolated environment with `requirements-research.txt`.
Run `scripts/fetch-phystwin.py`, then `scripts/fit-measured.py` for pilots or
`scripts/fit-measured-joint.py` for the joint experiment. Commands refuse to overwrite
prior experiment directories. The measured studio mode is `?mode=measured`.
The original studio remains available at `/` in light mode.

## Frozen result and appearance provenance

The selected uniform joint fit gives 28.87/36.72 mm on lift/push, 23.89 mm on
validation double lift (default 20.32), and 27.78 mm on reserved stretch (default 28.19).
Stretch landmark errors are effectively equal. See MEASURED_VALIDATION.md and the
frozen report for all baselines and the unhelpful regional-capacity ablation.

First-frame Gaussian appearances for lift and stretch were downloaded from the same
pinned dataset revision's gaussian_output.zip. The official export_gaussian_data.py
copies frame zero from three RGB-D cameras; dataset_readers.py distinguishes these
three training cameras from interpolated inspection views. Morphic did not retrain
these appearances or use future test-object motion in its predictor.

Morphic retains SH0 color and isotropic scale, filters alpha below .015 and scale below
.04 mm, and binds each retained Gaussian to four response nodes. EWA projection and
covariance push-forward are independently implemented. The CPU derivative audit finds
42/2048 inverted sampled appearance locations at the late lift frame. This limitation
is shown in the article; there is no claim of a globally invertible deformation field.

Video preparation occurs after scoring. Identical presentation crops may include
observed landmarks so motion remains visible; those crops never feed the optimizer.
