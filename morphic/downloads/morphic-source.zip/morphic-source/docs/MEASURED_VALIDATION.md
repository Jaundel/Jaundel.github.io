# Measured behavior validation

The authoritative measured report is [final-comparison-01.json](evidence/measured/final-comparison-01.json).
Its model-selection record was written before the reserved stretch response was scored.
This is a conditional parameter-transfer experiment using each trial's initial shape,
not one unloaded mesh deployed unchanged across trials.

## Outcomes

| Filtered-track 3D RMSE, mm | Default | Lift-only fit | Joint fit | Regional joint | Static | Hand warp |
|---|---:|---:|---:|---:|---:|---:|
| Lift / fit |39.46|24.45|28.87|29.17|43.62|66.71|
| Push / fit |69.03|79.65|36.72|36.26|138.85|64.03|
| Double lift / validation |20.32|42.45|23.89|23.66|72.80|54.02|
| Stretch / test |28.19|34.28|27.78|28.08|43.82|45.58|

The main uniform model fits lift and push jointly. The two-region model barely improves
the fitting objective and does not improve stretch. The simple uniform model was
selected. The stretch outcome does not establish a reliable benefit from fitting:
publisher-landmark mean errors are 22.94 mm default and 22.95 mm joint fit.

The zebra pilot also failed transfer: lift fitting improves 17.78 to 16.35 mm, while
double-lift validation changes from 17.66 to 18.41 mm. Pilot and joint sources/reports
are preserved under this directory. They are local Morphic results, not PhysTwin results.

## Checks that ran

- 30 Node tests: preserved baseline physics/assets/replay, synthetic inverse fitting,
  measured dynamics/replay, configuration rejection, calibrated projection, Gaussian
  binding validation, and session preflight.
- [verification.json](evidence/measured/verification.json): all 24 filtered and 24
  landmark scores recomputed; all four complete Python/JavaScript trajectories match
  with zero maximum coordinate drift on this machine.
- Browser: a Gaussian stretch object accepted a mouse grab/move/release. Its saved
  21 MB session embedded appearance, response, and events. Reloaded replay completed
  at 11.35 seconds with zero coordinate drift and no console errors.
- Video export: lift 85 frames and stretch 192 frames, each 30 fps and 1280x720.
  Actual encoded files were decoded and counted. A layout-resize failure was caught
  and fixed by locking render dimensions during export.
- The article's source/landmark panels are encoded in one file per recording and use
  original camera calibration and frame timing. Presentation crops do not affect scores.

- Final article controls, embedded region editing, and 390px/1440px layouts were
  checked in the browser. The original white studio also loaded and deformed its
  lemon capture. No browser console errors were observed.
- Ten delivered MP4 files decode with their expected frame counts at 30 fps. The
  portfolio GIF is 360x360 with 43 frames. [Delivery record](evidence/measured/delivery-check.json).
- The fitting figure uses 1040x336 looping GIFs derived from the synchronized lift
  and push evidence videos. The recording selector swaps those GIFs; their hashes
  are retained in [presentation-media.json](evidence/measured/presentation-media.json).
- The validation/test figure uses the same treatment for double lift and stretch.
  Each experimental comparison therefore has one control: its recording selector.
- The hero and material-edit comparisons also use looping GIFs. Appearance uses one
  synchronized side-by-side GIF as two views behind a directly draggable divider.
- The compiled site resolves 38 local HTML asset/link targets under the portfolio
  subdirectory. The article, original studio, and embedded measured runtime load there.

## Appearance boundary

227,714 retained lift Gaussians and 221,181 stretch Gaussians preserve recognizable
appearance in the browser. The supplied shape priors are visibly more faceted. This is
a qualitative comparison in a source camera, not a novel-view photometric benchmark.

The analytic displacement derivative agrees with central finite differences to
7.6e-10 over the sampled CPU check. At lift frame 84, 42/2048 sampled locations have
negative Jacobian determinant. The appearance field folds; a richer renderer does not
fix the motion model. The audit is [appearance-audit.json](evidence/measured/appearance-audit.json).
It validates a mathematical formula, not GPU arithmetic or physical volume.

## Interpretation

The graph predicts stretch better than static and fitted kinematic baselines. Parameter
fitting adds little over the default in the reserved test and loses on validation.
One object and one reserved action do not justify a population-level accuracy claim.
The synthetic positive result remains identification within the same solver family.

No force, mass, unloaded shape, constitutive law, or continuum limit was measured.
Node timing of roughly 2.4–3.7 ms per recorded frame is CPU simulation only. Render
performance and encoding cost are separate; no browser frame-rate guarantee is made.
