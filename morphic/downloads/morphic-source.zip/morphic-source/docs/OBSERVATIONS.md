# Observation and deployment contract

Use `npm run behavior:study` to create the complete example at
`public/behavior/dataset.json`. Then:

```powershell
npm run behavior:fit -- public/behavior/dataset.json work/example-fit.json
```

The output path must not already exist. Parent directories must exist.
The CLI produces both fits and scores every held-out trial. It does not select the
winning model from test scores. For real model selection, reserve an additional
validation trial and keep a final test untouched.

## Dataset

```json
{
  "schema": 1,
  "units": "m-kg-s",
  "origin": "measured",
  "provenance": {
    "source": "Acquisition identifier and source/license",
    "scale": "How metric scale and mass/density were established",
    "loading": "Supports, actuator calibration and synchronization"
  },
  "geometry": {
    "vertices": ["flat x,y,z coordinates; actual numbers required"],
    "triangles": ["flat zero-based indices; actual integers required"],
    "resolution": 6
  },
  "settings": {
    "dt": 0.008333333333333333,
    "iterations": 12,
    "density": 100,
    "gravity": 0
  },
  "initial": {
    "edge": [0.0002],
    "bulk": 0.0000002,
    "damping": 1.5,
    "friction": 0,
    "axis": 1,
    "split": 1.36
  },
  "trials": []
}
```

This is a schematic; the generated dataset is executable. Surface geometry uses the
baseline voxel envelope and embedding. For a known tetrahedral mesh, supply
`geometry.tetrahedra` and `geometry.h` instead of resolution; vertices are then
simulation nodes. Positive orientation and connected-node usage are checked, but
non-overlap/manifoldness and physical mesh quality remain the provider's responsibility.

Each trial has a unique `id`, a `role` of `fit` or `test`, `endTick`,
`events`, and `observations`. For example:

```json
{
  "id": "pull-x-01",
  "role": "fit",
  "endTick": 180,
  "events": [
    { "tick": 0, "action": { "type": "pin" } },
    {
      "tick": 0,
      "action": { "type": "grab", "node": 12, "target": [0, 1.5, 0] }
    },
    { "tick": 1, "action": { "type": "move", "target": [0.001, 1.5, 0] } },
    { "tick": 66, "action": { "type": "release" } }
  ],
  "observations": [
    {
      "tick": 6,
      "points": [{ "vertex": 4, "position": [0.02, 1.1, 0], "weight": 1 }]
    },
    {
      "tick": 12,
      "points": [{ "vertex": 4, "position": [0.03, 1.1, 0], "weight": 1 }]
    }
  ]
}
```

Point positions are metric world coordinates. Use either `vertex` for an input
appearance vertex evaluated through its four-node embedding or `node` for a
simulation marker. Do not use both. Omit occluded markers rather than zero-filling
positions. Observation frame times are strictly increasing; duplicate markers
within a frame are rejected. Optional positive weights represent confidence.
The loss is weighted 3D point squared error, not per-coordinate error.

At each tick, actions are applied before the next integration step. A frame at tick
6 is the state after six steps, before step 7. Move events use zero-order hold.
Resample actuator tracks onto the solver clock using a documented procedure; do not
round independent sensor timestamps without reporting alignment uncertainty.

The `pin` action fixes nodes near the lowest rest y coordinate using the existing
compliant pin constraint. A grab is a single-node compliant position target, not a
measured force or arbitrary contact patch. Initial velocity is zero and rest geometry
is supplied. The first release/pull should begin from that state. Experiments with
unknown prestress, changing support or distributed contact need a richer loading
adapter before they can be interpreted physically.

## Fitting assumptions

The fitted quantities are discrete edge compliance and a global damping rate.
The split plane is specified in rest coordinates and selects edge midpoints.
Global fitting has two parameters. Regional fitting has three. Bulk compliance,
friction, density, topology, and support stay fixed. Edge compliance is constrained
to `[1e-8, 0.1]`; damping searches approximately `[0.05, 30]` per second.
Candidates activating the orientation limiter are rejected.

The optimizer uses bounded coordinate pattern search in log space. It has a finite
evaluation budget and no global-optimum guarantee. It does not estimate confidence
intervals, material identity, or the uniqueness of the recovered field.

Changing scale, mass, actuator coupling or timestep can change the fitted coefficients.
Do not label them Young's modulus. Synthetic test success is a software/numerical
identification result. Measured tests require an independently documented acquisition.

## Physical assets

Assets include response engine version, exact solver geometry/connectivity, settings,
coefficients, units, and source provenance. Deployment rejects incompatible geometry
or settings instead of transferring coefficients silently. Surface appearance is
owned by the original capture pipeline and is not reconstructed by the fitter.

The article exports a controlled specimen asset and can reload compatible assets.
It cannot apply that asset to a museum scan or a different object. Deliberate local
edits are labeled `intentional-material-edit` and retain their source provenance.
Replay engine 3 records response changes as actions; baseline engine-2 sessions
remain loadable. A saved trajectory is recomputed from inputs.
