# Real capture evaluation

## Question

Does adding observed views improve the shape of an interactive asset when it is
seen from cameras excluded from reconstruction? A visually plausible asset alone
does not answer this question. Assigned simulation remains separate from geometry
accuracy and measured physical behavior.

## First pilot: kitchen sponge

Source: [Deform360](https://github.com/lhy0807/deform360), processed object
`057-kitchen-sponge`, episode 0. Dataset revision:
`e92deaf7e437e7e51ad464706ae647f522a279d9`.

The pinned 529,745,920-byte camera archive has SHA256
`eafe7ab59a271b13df6d1e210800cac6c5fb8a261c0eb9fcbe4edbc20d44721d`.
Only camera observations are exported. Point clouds, Gaussian reconstructions,
rendered depth and tracking are not reconstruction inputs or ground-truth geometry.
The archive contains some of these annotations, but the preparation script does
not read or export them.

Reproduce from the repository root with Python, requests and Pillow:

```powershell
python scripts/fetch-deform360-pilot.py
python scripts/prepare-deform360-pilot.py
```

Both commands run locally without paid compute. The first verifies the complete
archive hash and pinned sidecars. The second writes an immutable split before
reading image bytes and exports only designated input images. Existing evidence
that differs is rejected rather than silently overwritten.

### Frozen partition

32 cameras are listed in the episode metadata. Sorted-camera indices determine
the partition without selecting attractive images or optimizing coverage:

- Reconstruction: indices 0, 10, 21.
- Validation: indices 5, 16, 26.
- Test: the remaining 26 cameras.

The reconstruction cameras are `brics-odroid-001_cam0`,
`brics-odroid-012_cam0`, and `brics-odroid-021_cam1`. The middle camera lacks
`segmented/000000.png`; it is recorded as unavailable and is not replaced by a
validation or test camera. Thus the first supplied-mask comparison has **two**
usable input images. Missing masks in evaluation views must likewise be counted,
not silently treated as successful reconstructions or perfect empty silhouettes.

Frame 0 is the first aligned observation. Both exported inputs carry the same
first timestamp label, `frame_1769645001931630_000000000000`, and 253 timestamp
lines. This does not establish zero hardware synchronization error. The metadata
window 87–183 is a later interaction interval, not the chosen static frame.

The RGBA files retain original RGB under transparent pixels. Conditioning must
respect alpha; showing those files through a viewer that ignores alpha reveals
the capture dome. Supplied segmentation is an explicit experimental aid, not
evidence that Morphic can automatically isolate this object from a user video.

Local artifacts live under `work/deform360/057-kitchen-sponge/`:
`split.json`, `preparation.json`, `inputs/`, the calibration and metadata sidecars,
and the verified archive. Raw data is not bundled with the public studio.

## Comparison to run

1. Public TRELLIS single-image baseline, first usable input, seed 42.
2. Same checkpoint/settings with both usable views, seed 42.
3. If resources permit, TRELLIS.2 single-image baseline on that same first image.
   A newer checkpoint is an integration comparison, not a novel method.

Freeze model revisions, processed conditioning images, output meshes and reports
before reading test images. Fit any required pose/scale alignment using input
views only. Use validation views for method decisions, never test views. Confirm
the released calibration convention against authoritative calibration data before
projecting meshes; do not assume quaternion direction from field names alone.

Primary geometry measurement: per-camera silhouette intersection-over-union on
eligible test views, with each value and coverage count reported. Also report
input-view agreement, runtime and failure cases. An average must not hide missing
or empty projections. RGB similarity is secondary because capture lighting and
generated texture can confound it. This is a 2D projection evaluation, not proof
of accurate unseen 3D surfaces or recovered material physics.

For deployment, additionally verify load, drag, drop, reset, save and reopen on
each resulting asset. Replay agreement only tests deterministic computation.

## Preparation record (before reconstruction)

The archive and two inputs were verified and the partition frozen. Input images
had been visually inspected. No validation/test images had been inspected and
no held-out accuracy score existed at this point. The completed comparison follows.
The older upstream-character slideshow remains a pipeline fixture and must not
be presented as real handheld video evaluation. A successful dataset pilot must
be followed by actual user-like photos/video with automatic segmentation.

### Local geometry baseline, 2026-09-16

The released text poses were compared against official camera-to-world matrices
from raw dataset revision `5ea8c5d3fc7b4a7b4f9f921f2ceb1de24610f6a4`.
All 32 episode cameras match the inverse matrices with maximum absolute numerical
error `1.24e-12`. Four text-only cameras outside the episode roster were excluded.
This confirms the transform convention, not real-world calibration accuracy.

```powershell
python -m pip install -r scripts/requirements-capture-evaluation.txt
python scripts/verify-deform360-calibration.py
python scripts/reconstruct-deform360-hull.py
python -m unittest discover -s tests -p test_deform360_geometry.py
```

The standard visual-hull baseline intersects the two observed silhouette cones
on a 128-cubed grid. Grid placement uses input silhouette centroid rays only;
the volume expands if occupied voxels touch its boundary, and fails rather than
presenting a clipped volume as a closed object. Marching cubes produces an
untextured mesh of 3,792 vertices / 7,580 faces, verified watertight.

| Input camera | Silhouette IoU |
|---|---:|
| brics-odroid-001_cam0 | 0.9323 |
| brics-odroid-021_cam1 | 0.9302 |

These are **input-view fit scores**, not withheld-view prediction results. The
reported reconstruction/export/scoring runtime was 1.75 seconds after imports.
The output is visibly coarse; silhouette intersection cannot reconstruct hidden
concavities. It is a baseline for comparison, not an improved AI method.

Artifacts: `hull-baseline/asset.glb`, `world-mesh.ply`, per-input silhouette
projections and `report.json` under the local pilot folder. The report freezes
input, partition, calibration, source and output hashes. The script refuses to
overwrite an existing output directory. Its five analytical geometry tests pass.

The GLB passed Morphic's artifact validator and loaded in the browser studio.
Drop and replay were exercised; replay reported zero node drift. A final-frame
notification bug found during this check was fixed and browser-verified: completed
replay now shows Paused. Physics is still assigned by Morphic, not recovered from
the sponge. Drag/save/reopen were not separately verified for this particular mesh.

## Completed TRELLIS comparison, 2026-09-16

Three GPU reconstructions used official TRELLIS commit
442aa1e1afb9014e80681d3bf604e8d728a86ee7 and checkpoint revision
25e0d31ffbebe4b5a97464dd851910efc3002d96, seed 42: first photo alone, second
photo alone, and both photos. The worker now defaults to this immutable checkpoint
rather than looking up main. The auxiliary DINOv2 source remains an unpinned
upstream dependency, so full environment reproducibility is not established.

The input-only alignment procedure is deliberately shared across all three:
2,048 sampled surface points, 24 initial cube rotations, 30 symmetric similarity
ICP iterations against the input visual hull, then selection by input silhouette
IoU. This supplies BOTH input masks/calibration to alignment, even for a generator
conditioned on one photo. Thus these are reconstruction-plus-alignment pipeline
scores, not unaided single-image accuracy or an isolated model-quality comparison.
Alignment error can lower these scores; it is not independently disentangled.

A self-registration check reproduced the hull's mean input IoU of 0.9312. Seven
analytical tests cover pinhole projection, behind-camera rejection, degenerate
rays, IoU, rasterized silhouette and recovery of known rotation/scale/translation.
All outputs and their hashes were frozen before the evaluator read test masks.

| Method | Mean input IoU | Mean test IoU | Median test IoU |
|---|---:|---:|---:|
| Two-view visual hull | 0.9312 | 0.6358 | 0.6829 |
| TRELLIS first photo | 0.6606 | 0.4329 | 0.4503 |
| TRELLIS second photo | 0.7189 | 0.4449 | 0.4612 |
| TRELLIS two photos | 0.7215 | 0.4579 | 0.4473 |

23 of 26 test cameras had usable supplied first-frame masks; three absent previews
are listed in heldout-evaluation/scores.json. None was replaced. The three reserved
validation images remain unread. Test results must not be used to tune this case
and then presented as a fresh held-out improvement. Subsequent method development
requires a new untouched object/capture for its final test.

The two-photo generator gains 0.0130 mean IoU over the better single-photo result;
its median is slightly worse. The untextured visual hull scores highest. There is
no demonstrated novel hidden-view recovery method. One sponge/frame, correlated
cameras, supplied masks and known calibration do not establish user-video
performance, texture quality, true hidden geometry or physical parameters.

The three GLBs are hash-verified and passed the studio artifact validator. The
textured two-photo output opened in the browser with its provenance report.
GPU runtimes including load/inference/export were 124.59, 56.95 and 57.32 seconds;
the first included initial downloads, so these totals are not isolated algorithm
speed comparisons. The evidence archive is 4,940,829 bytes, SHA256
2d5f750e66e7a14099ee0c19ecdc2608db1601a927d12f8a24c845955810db0d.

Workers were stopped after the outputs were downloaded. No raw dataset images or generated sponge asset
were added to the public example bundle; processed-dataset license metadata was
absent when checked. Locally retained research outputs remain available.

## Ordinary-background capture protocol (prepared, not reconstructed)

The next case is CO3D v2 toytruck sequence `190_20494_39385`, selected from
metadata before RGB inspection. Its 202 decoded frames span 20.05 seconds.
Frames 1–141 are the input interval; frames 142–202 remain unextracted for later
held-out evaluation. The split is recorded in `work/co3d/toytruck-split.json`.
Both source archives match the official checksum manifest from CO3D repository
revision `eb51d7583c56ff23dc918d9deafee50f4d8178c3`.

Run `work/research-venv/Scripts/python.exe scripts/package-co3d-capture.py` to
verify the archives, extract only input RGB, and encode the 14.0649-second input
interval. Requires imageio-ffmpeg in the research environment. The generated
`toytruck-real-capture-reencoded.mp4` is derived from actual captured frames;
it is not the original native camera video. A sidecar records each original
frame hash, timestamp, split hash and output hash. No supplied masks, depth,
point cloud or held-out pixels enter this packaging operation.

The studio sampled 12 views, saved the original video and selected views, and
restored all 12 after a full browser reload. Full video decoding confirmed 141
frames at 1270×714. This establishes ingestion and persistence, not reconstruction
quality. Next run should use these default 12 samples with automatic foreground
removal and the existing fixed-seed public baseline before considering another
model. Inspect segmentation outputs and generated geometry before scoring;
freeze any registration/evaluation method before opening withheld pixels.

Dataset license is CC-BY-NC-4.0, retained locally. Model training overlap is
unknown. This single capture cannot establish generalization, physical truth,
or a novel reconstruction algorithm. No toytruck images or assets are bundled
in the public examples at this checkpoint.

## Ordinary-background GPU result — 2026-09-16

The prepared CO3D input completed the browser workflow on pod cioe65msk5ot9m
(A100 SXM 80GB). Job 50a254ac-8fc8-454a-b4e9-36f0a1c01dcb received the browser's
12 default 768px PNG samples. No supplied masks, depth, point cloud or camera
calibration were sent. Official TRELLIS U2-Net preprocessing isolated the toy,
with small visible background remnants in some views (notably conditioning-04).
The selected input video, input hashes and preprocessing outputs are retained.

| Input | Load + preprocessing (s) | Inference (s) | Export (s) | Total (s) |
|---|---:|---:|---:|---:|
| Twelve default video samples | 200.24 | 7.15 | 14.75 | 222.13 |
| First sample only | 43.60 | 5.97 | 13.33 | 62.90 |

The first run includes model downloads; total times are not isolated algorithm
speed comparisons. Both used seed42 and the previously pinned source/checkpoint.
The twelve-view asset is 1,575,960 bytes, SHA256
621001df3de9a18611444294cd62dbc66c81286971d2dd6ce231f3bf1dc90c92.
The single-view asset is 1,299,132 bytes, SHA256
bdb0aeddf69fa9c68e2c591b074f0f2eb2fba76a270d430618e8ccff50a62817.
Both passed the studio reconstruction validator and hash check.

Browser evidence: automatic opening from completed reconstruction; surface drag;
interaction replay with zero drift; reopening the completed job after the worker
was stopped; Chrome session download and file reopening with zero-drift replay.
Portable session: work/co3d/toytruck-session.morphic.json (2,125,768 bytes).
The embedded browser did not expose the attempted download; Chrome verified it.

The shape is recognizable, but wheels/underside are visibly rough. No held-out
score has been computed; 61 reserved images remain unextracted. The single-view
reference has not been visually or quantitatively compared yet. Soft-body motion
is assigned, not an estimate of the toy's plastic material or working wheels.

Archive work/co3d/toytruck-evidence.tar.gz preserves both results, 12 inputs,
conditioning images, logs, worker code and package manifest. Its remote/local
SHA256 matches: a0d8a5f19b1cc299ea36f2dd59195dac3f80cfe6962c36c2b20b2eeddfa8610b.
All workers were stopped after backup.

## Toy-truck reserved-view comparison — 2026-09-16

This supersedes the unscored status above. The 61 reserved test MASKS have now
been consumed. Raw held-out RGB remains unextracted, but this is no longer a fresh
held-out split for tuning and retesting these methods.

Camera conversion follows the pinned official CO3D ViewpointAnnotation:
https://github.com/facebookresearch/co3d/blob/eb51d7583c56ff23dc918d9deafee50f4d8178c3/co3d/dataset/data_types.py
and PyTorch3D camera projection documentation: https://pytorch3d.org/docs/cameras.
CO3D uses row-vector world-to-camera rotation, x-left/y-up and normalized
intrinsics. The adapter converts to x-right/y-down pinhole pixels, supporting
isotropic and legacy image-bound normalization. Analytical tests cover documented
non-square focal/principal-point values, axis signs, translation/rotation,
camera-center recovery, legacy normalization and invalid inputs. Across all202
metadata cameras, converted projections differ from direct NDC calculation by at
most0.000141 pixels. This verifies convention conversion, not calibration truth.

Each actual browser PNG was matched against all141 decoded INPUT video frames
at192x108 using RGB-channel-equivalent MSE. All matches agreed with the independent
12-midpoint timing rule; the next-best frame had more than twice the error.
Matched source frames:6,18,30,42,53,65,77,89,100,112,124,136. Supplied masks for
ONLY those frames were extracted for alignment. They were never generator inputs.

A128-cubed input silhouette hull is watertight (2464 vertices,4936 faces) with
mean input IoU0.9122. Both generated meshes were aligned using the same input hull,
24 cube rotations,2048 sampled surface points,seed42,and30 symmetric similarity
ICP iterations; the best candidate was selected only by input-mask IoU. This
additional twelve-view supervision means the single-view score is not unaided
single-view accuracy. Pose/scale alignment error is not separated from shape error.
World coordinates have arbitrary dataset scale, not measured meters.

The evaluator wrote heldout-evaluation/frozen-plan.json with mesh/source/split
hashes BEFORE reading test masks. It scored all61 reserved masks at full resolution
with threshold127; none was missing, empty, or replaced. No per-test registration.

| Method | Mean input IoU | Mean test IoU | Median test IoU |
|---|---:|---:|---:|
| Twelve-input silhouette hull |0.9122|0.8771|0.8813|
| TRELLIS first sample |0.8229|0.8368|0.8384|
| TRELLIS twelve samples |0.7931|0.8240|0.8232|

The twelve-view generator is0.0128 below the single-view reference in mean test
IoU. This case does not support the claim that more views improve reconstruction.
Possible segmentation, generative inconsistency and alignment effects have not
been disentangled. Correlated frames of one object, supplied annotations and
unknown training overlap limit generalization. Silhouette agreement cannot verify
texture, unseen concavities, rolling wheels or material parameters.

Local scripts:co3d_geometry.py,prepare-co3d-evaluation.py,reconstruct-co3d-hull.py,
align-co3d-mesh.py,evaluate-co3d-views.py. Outputs under
work/co3d/190_20494_39385/. Public own measurements:
public/reconstruction/toytruck-heldout-scores.json. No dataset pixels published.
Next method development needs a new untouched capture for a final test.

## Glove capture preparation and launcher check — 2026-09-16

A new category was prepared with scripts/prepare-co3d-photo-case.py using the
pinned official CO3D manifests. The script verifies archive checksums, selects
from metadata before image inspection, freezes the split, and extracts only
selected RGB files. Running it again preserved the same split and verified data.

Sequence baseballglove/601_92967_186813 has 202 frames. Twelve evenly spaced
frames from the first 70% were selected; the final 61 remain reserved. Review in
the studio revealed that frames 26,39,77,90,128 are identical black images.
They were excluded through the existing view controls before reconstruction;
frames 1,13,51,64,102,115,141 were submitted. The frozen split was not changed,
no replacement frames were selected, and no reserved RGB/masks were inspected.
This is a seven-view trial. Input review is retained in input-review.json.
Supplied masks, depth, camera poses and point clouds were not generator inputs.

The first live launcher probe failed because cold dependency imports needed
26.2 seconds, longer than its 15-second remote limit. The shared probe now allows
45 seconds remotely and 55 seconds for its SSH command. The same prepared worker
then passed. The launcher started the studio and saved its connection settings;
reopening the saved capture restored all five exclusions. Fresh regression tests
passed (45/45) and the production build succeeded after this correction.
Reconstruction results and shutdown are recorded in the following checkpoint.
