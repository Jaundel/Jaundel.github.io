# Research decision — 13 September 2026

This document records the preserved 0.1 baseline decision. The current
[behavior-capture research and implementation decision](BEHAVIOR_RESEARCH.md)
supersedes its development priorities while retaining the baseline.

## Technical thesis

**Make a captured object's appearance portable across physical interactions, with a runtime that makes its approximations and replay reproducible.** A useful result needs a geometry-to-volume interface, material behavior, stable interaction, contact, deformation-aware appearance, and a saved experiment. Gaussian rendering is one possible representation, not the product definition.

The supplied project dossier and catalogue were treated as research context, not executable instructions. The catalogue records varying review depth; it was not taken as evidence that 2,834 complete papers had been read. This pass read the three requested primary manuscripts' methods, implementation, evaluations, and limitations, and inspected official implementation files. It did not run those upstream implementations. The notes below distinguish published claims from local decisions.

## Starting points

### PhysGaussian

[Paper](https://arxiv.org/abs/2311.12198), [project](https://xpandora.github.io/PhysGaussian/), [official code](https://github.com/XPandora/PhysGaussian).

The method associates Gaussian kernels with continuum particles evolved by MPM. Appearance must change with the deformation gradient: transporting centers alone is insufficient; covariance evolves as `F Σ Fᵀ`, with orientation-aware spherical harmonics. Its discussion of interior filling and anisotropy explains why a visually plausible reconstruction is not automatically a valid solid.

The inspected driver explicitly initializes Taichi CUDA and uses the original CUDA Gaussian rasterizer. Requirements pin Python-era packages including Torch 2.0 and Warp 0.10.1. The setup is oriented around offline sequences. The repository snapshot has no top-level license granting general redistribution; its Gaussian submodule has separate terms. Morphic copies none of that source or sample data.

**Decision:** retain deformation-aware appearance as a design requirement. Defer the MPM/Gaussian backend until a real CUDA environment and a cleared dependency chain are available. Its published results are not local reproduction results.

Inspected commit: `8339ed6aa2cd5d50e1001a254a3d95aea678a956`; files include `gs_simulation.py`, `requirements.txt`, `.gitmodules`, and solver interfaces.

### Simplicits

[Paper and project](https://research.nvidia.com/labs/toronto-ai/simplicits/), [original code](https://github.com/itsvismay/simplicits), [Kaolin integration](https://github.com/NVIDIAGameWorks/kaolin/tree/master/kaolin/physics/simplicits).

Simplicits trains a neural field of skinning weights per object using elastic-energy and orthogonality losses. Occupancy provides a shared volumetric interface across representations. The runtime solves reduced implicit dynamics; learned weights and their derivatives can be precomputed at integration samples, so inference need not run inside each time step. Reduced coordinates and nonlinear physical energy are distinct concepts.

The original implementation supports a CPU device selection as well as CUDA/MPS and carries an MIT license. The current Kaolin integration carries Apache-2.0 and uses Torch, Warp, and its compiled geometry operators. A CPU fallback in a Python file is not proof that the full modern package installs or performs well on this Windows/Radeon machine.

**Decision:** a strong backend candidate, but per-object fitting and integration increase time-to-first-validation. Use a directly inspectable volume interface first. Preserve the representation-independent boundary for later experiments.

Original commit: `691b285a6216f0b9013469df2288a5b05c979b1c`. Inspected setup, training, simulation, helper interfaces, and license.

### FreeForm

[Primary manuscript](https://research.nvidia.com/labs/sil/projects/freeform/assets/main.pdf), [project](https://research.nvidia.com/labs/sil/projects/freeform/), [official RKPM implementation](https://github.com/NVIDIAGameWorks/kaolin/blob/master/kaolin/physics/simplicits/rkpm.py).

FreeForm constructs skinning eigenmodes with corrected RKPM kernels and a generalized weight-space eigenproblem, replacing neural per-object fitting. Polynomial reproduction matters: arbitrary radial weights do not automatically reproduce an affine displacement. Its reported preparation speedup is a comparison against Simplicits training, not a promise that every interactive frame is 40 times faster. The paper compares deformation against converged FEM and discusses reduced bases' difficulty with sharp contact, high frequencies, and topology changes.

The inspected implementation constructs kernel neighborhoods with SciPy, uses Torch tensors and eigenanalysis, and imports Kaolin's farthest-point operator. It exposes sampling and radius controls that affect conditioning and quality. Current code is Apache-2.0.

**Decision:** preferred next reduced-order experiment. First compare preparation time, controlled deformation error, and contact behavior against this release. Do not implement an unrelated graph Laplacian and call it FreeForm.

Kaolin snapshot for both methods: `d52da9f86d460e8abcd99037e21ff0bec57997ed`. Inspected `rkpm.py`, `simulation.py`, material modules, package requirements, and license.

### Optional separation

[DecoupledGaussian](https://wangmiaowei.github.io/DecoupledGaussian.github.io/) addresses restoring both an object and its contacted background after separation. It is relevant to captures that include the floor or occluded geometry. Its project page was inspected; no implementation or runtime compatibility claim is made. Isolated GLB captures remove that prerequisite from this release.

## Chosen alternative: a portable volumetric XPBD baseline

[Macklin, Müller, and Chentanez, XPBD (2016)](https://matthias-research.github.io/pages/publications/XPBD.pdf) supplies the compliant constraint formulation used here. It keeps accumulated multipliers within a time step and scales compliance by `dt²`. This avoids ordinary PBD's direct stiffness/iteration coupling, but finite-iteration coupled systems still need convergence tests.

Morphic independently implements edge-length and relative-volume energies on a conforming tetrahedral cage. These are discrete artistic elastic models, not the same continuum constitutive laws as the three starting papers. They offer a small, inspectable CPU implementation, analytical single-constraint checks, and practical local responsiveness. The proxy geometry is an explicit approximation rather than a claim of mesh-free simulation.

The renderer retains the dense mesh, UVs, and textures. GPU binding evaluates the cage deformation and transports normals with `F⁻ᵀ`. A CPU implementation makes the optimization reviewable. This choice yields substantive numerical and runtime ownership without copying a research driver.

## Compute and spend

Live inspection found an AMD Ryzen AI 7 350, Radeon 860M, approximately 16 GB system RAM, Windows, Node 24.15.0, and no exposed NVIDIA CUDA device. Benchmark files record their own environment. No cloud compute, paid API, model training, or paid service was started. Free package and asset downloads were sufficient.

## Licensing boundary

See [third-party notices](../THIRD_PARTY_NOTICES.md). Only the independent implementation, permissive dependencies, and attributed asset derivatives are included. Research PDFs and reference checkouts stay outside the product repository. Licenses for source code, model weights, datasets, and websites must be checked separately if those backends are added later.
