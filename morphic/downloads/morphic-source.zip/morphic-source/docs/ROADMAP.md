# Development stages

## Behavior-capture stage

Current priorities and completion boundaries are maintained in
[EXECUTION_STATE.md](../EXECUTION_STATE.md). Observation fitting, controlled held-out
tests, regional response editing, and an interactive article now precede a solver
replacement. [Research rationale](BEHAVIOR_RESEARCH.md).
Measured fitting, transfer testing, and Gaussian appearance are implemented. Reliable
transfer gains and a calibrated continuum comparison remain open scientific gates.

## Delivered baseline

1. **Architecture and provenance:** inspect local compute, read the requested research and official code, select a portable implementation, and obtain attributable sample objects.
2. **Numerical core:** build a volumetric proxy, analytical constraints, contacts, bounded interaction, deterministic action replay, and tests.
3. **Capture runtime:** preserve dense geometry and texture coordinates, implement GPU deformation and normals, support import/export and portable sessions.
4. **Evidence:** test multiple objects and materials, exercise real browser workflows, profile CPU versus GPU transfer, and retain failures and limitations.

This delivery closes a useful 0.1 loop; it is not completion of every possible research direction.

## Next engineering gates

1. **Calibrated constitutive reference.** Add a stable Neo-Hookean tetrahedral reference and beam/compression tests against an independent FEM implementation. Gate: convergence under time-step and mesh refinement before exposing Young's modulus as a meaningful quantity.
2. **Geometry-aware preparation.** Improve thin-feature treatment, interior confidence, and visible contact accuracy. Gate: held-out objects with handles, holes, and open boundaries, with explicit rejection criteria instead of silent bridging.
3. **FreeForm comparison.** Run the actual official RKPM backend on a verified supported environment. Match geometry, loads, and integration points; measure preparation, interaction, and deformation error. Do not assume a published training speedup applies to this runtime.
4. **Appearance validation.** The independent Gaussian renderer is implemented and compared visually. Next test additional views, deformation-field folding and measured whole-frame rendering cost; do not infer appearance accuracy from the preserved texture alone.
5. **Photograph acquisition.** Add a reproducible external reconstruction adapter with retained cameras and held-out photographs. Gate: appearance and geometry checks against real captures; no claim of reconstructing unseen interior material.

No paid compute is scheduled. Any rental or paid service requires a concrete proposed experiment, hardware requirement, estimated spend cap, and user authorization first.
