# Validation — Morphic 0.1

This is the retained baseline report. Current measured behavior results are in [MEASURED_VALIDATION.md](MEASURED_VALIDATION.md),
with synthetic identification in [behavior results](evidence/behavior/results.json).
Baseline measurements retain their original date and scope.

This is evidence for a working elastic capture runtime, not a certification of material accuracy or a reproduction of PhysGaussian, Simplicits, or FreeForm.

## What ran

- **13 automated Node tests:** signed volume and mass accounting, affine binding, zero-force rest invariance, damped free fall, an analytical implicit spring reference, drop contact, exact replay, invalid-input rejection, and all four assets' hashes/import/bindings.
- **12 trajectory cases:** four objects × three presets, each 600 fixed steps (five simulated seconds), with squash, stretch, and drop. All completed with no numerical faults, no inverted sampled elements, and **zero same-runtime replay position drift**. The solver additionally checks orientation at every accepted step.
- **18 discretization/ablation cases:** three cage resolutions × three time steps × volume constraint enabled/disabled.
- **Six contact cases:** lemon and tablet dropped against a floor, slope, and sphere. Every visual vertex was inspected every ten ticks.
- **Real-browser workflows:** all four objects deform, save, replay, and load portable sessions. Actual mouse picking/drag/release produces physics actions. Deformed GLB export re-imports successfully. Invalid sessions fail explicitly. A 390px layout has no horizontal overflow. Browser console and page errors: **zero**.
- **Appearance parity:** resting tablet rendered through both the CPU and GPU deformation paths, with fixed camera and lighting.

## Local measurements

Machine: AMD Ryzen AI 7 350, Radeon 860M, about 16 GB RAM, Windows. Node 24.15.0. Browser Chrome 152.0.7977.84, using the actual AMD D3D11 renderer through ANGLE, not SwiftShader. Source JSON records full machine/protocol details.

| Measurement                            |                 Result | Scope                                                             |
| -------------------------------------- | ---------------------: | ----------------------------------------------------------------- |
| Solver median step                     |       about 0.9–2.2 ms | 12 Node trajectory runs; resolution 8, five sweeps                |
| Solver P95 step                        |       about 1.3–2.9 ms | Same run; includes JIT/OS variation                               |
| Tablet rendered vertices / triangles   |        75,649 / 99,987 | Decoded museum GLB; no further simplification                     |
| Tablet physics nodes / tetrahedra      |            508 / 1,956 | Generated proxy                                                   |
| Dense tablet CPU-reference median FPS  |                  10.54 | Browser, active simulation                                        |
| Dense tablet GPU-skinning median FPS   |                  59.96 | Same asset, viewport, and scripted stretch                        |
| Dense tablet CPU update median         |                28.8 ms | Position update, normal reconstruction, bounds                    |
| Dense tablet GPU palette-update median | below timer resolution | Reported 0.0 ms; **not literally zero cost**                      |
| Rest-image mean absolute difference    |        0.0000187 / 255 | CPU vs GPU, all display-RGB channels                              |
| Rest-image RMS difference              |          0.00432 / 255 | 1,118 × 622 canvas capture                                        |
| Maximum replay position error          |                    0 m | Same-runtime recomputation, 12 trajectories and browser workflows |

The FPS comparison measures the whole update strategy, including different normal-update methods. It is not an isolated shader microbenchmark, a guaranteed frame rate on other devices, or hardware input-to-photon latency. CPU and GPU normal shading can differ under nonlinear deformation; the rest-image comparison verifies the common original appearance. It does not compare against withheld photographs.

The numerical trajectory table's largest sampled mean absolute local-volume error was about **8.8% during a forced deformation**. Final aggregate volumes were near their initial values. Preserving total volume alone can hide local errors, which is why both are reported.

## A retained failure and the fix

The initial strong squash on the thin-featured Moche bottle produced two inverted elements in sampled states. [`before-inversion-guard.json`](evidence/before-inversion-guard.json) preserves that failure. An initial global guard stopped the run and is retained in [`rejected-global-guard.json`](evidence/rejected-global-guard.json).

The accepted limiter retains positive orientation, advances time under a saturated handle, and allows release to recover. The same 600-step bottle/jelly trajectory now completes with zero inverted states and zero replay drift. It limits **69 of 600 steps**; the sweet-potato/foam case limits **64**. That is visible motion clipping, not an accuracy improvement to hide. The remaining ten trajectory cases did not activate the limiter.

A separate browser comparison caught incorrect updates to interleaved GLB attributes. Writing directly into the raw position buffer corrupted neighboring normals and texture coordinates on museum data. Attribute-aware `setXYZ` updates fixed this. The failed image/error record is retained; all quoted performance and parity results come from the corrected implementation.

Mouse-picking tests caught stale bounding boxes after deformation. The runtime now updates both bounding boxes and spheres before ray queries. A visible object alone did not prove interaction worked.

## What the ablation says

At resolution 8 and 120 Hz, the gravity-only lemon retained about **99.88%** of total proxy volume after two seconds with volume constraints, compared with **92.98%** when only those constraints were removed. The matched cage and edge constraints remained present in both cases.

Increasing time resolution generally reduced volume error in the complete solver. Increasing spatial resolution without increasing the solve budget did **not** produce uniformly better results. At resolution 12 / 60 Hz, the incomplete solve's worst local-volume metric was worse than the edge-only ablation. These are useful convergence warnings, not evidence of a calibrated continuum limit. No FEM accuracy claim is justified by this study.

## Contact boundary

The six bounded rubber drop tests measured zero floor/slope penetration and at most approximately `1.8e-8 m` sampled surface penetration against the sphere (Float32 skinning scale). This does not establish continuous collision freedom between ticks or through triangle interiors.

The lemon/sphere case activated step limiting on 238 of 360 steps and came to rest with saturated motion. It is a **known contact limitation**, despite its small penetration number. Sphere contact and extreme thin-feature deformation should be treated as exploratory. Floor and slope behavior are the stronger validated paths. No self-collision or object/object interaction is implemented.

## Reproduce and inspect

```powershell
npm test
npm run benchmark
node scripts/reference-study.mjs
node scripts/contact-study.mjs
python scripts/browser-check.py
python scripts/visual-check.py
npm run build
npm audit
```

Run the browser scripts with the local dev server available. The default screenshot/video script targets port 5173. The build and dependency audit passed; no audit vulnerabilities were reported. The GitHub workflow is supplied but was not dispatched during this delivery.

Raw evidence: [`benchmark.json`](evidence/benchmark.json), [`reference-study.json`](evidence/reference-study.json), [`contact-study.json`](evidence/contact-study.json), [`browser-check.json`](evidence/browser-check.json), [`visual-parity.json`](evidence/visual-parity.json), and the compiled-build [smoke check](evidence/production-smoke.json). Source and artifact hashes are recorded in the [evidence manifest](evidence/manifest.json). Run `python scripts/seal-evidence.py --verify` to check this delivery snapshot; text hashes normalize Git line endings. The manifest records file identity, not independent experimental attestation. Regenerate it only after intentionally updating and reviewing results. The [video](media/morphic-demo.webm) is a recording of the actual local runtime.
