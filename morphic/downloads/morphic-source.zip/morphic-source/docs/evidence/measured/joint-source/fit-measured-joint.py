"""Joint lift/push identification. Never open reserved stretch observations."""
import hashlib
import json
import time
from pathlib import Path
import numpy as np
from scipy.optimize import differential_evolution, minimize
from measured_graph import make_graph, rollout, score, save_graph

out=Path("work/measured-joint-01")
if out.exists():
    raise ValueError("Preserve the existing joint experiment")
out.mkdir(parents=True)
files=['scripts/measured_graph.py','scripts/fit-measured-joint.py']
source_hashes={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files}
trials=[make_graph(c) for c in ['single_lift_sloth','single_push_sloth']]
history=[]
calls=0
start=time.perf_counter()

def decode(x):
    return [10**x[0],10**x[0],10**x[1],10**x[2],x[3]]

def objective(x):
    global calls
    p=decode(x)
    values=[score(g,d,rollout(g,p),stride=3) for g,d in trials]
    value=float(np.sqrt(np.mean(np.square(values))))
    calls+=1
    if not history or value<history[-1]['rmse']:
        history.append({'evaluation':calls,'rmse':value,'trialRMSE':values,'parameters':p})
        print(json.dumps(history[-1]),flush=True)
    return value

bounds=[(-8,-2),(-8,-2),(-1,2),(0,1.5)]
fit=differential_evolution(objective,bounds,maxiter=40,popsize=7,seed=20260914,tol=.003,polish=False)
local=minimize(objective,fit.x,method='Nelder-Mead',bounds=bounds,options={'maxiter':140,'xatol':.005,'fatol':1e-6})
p=decode(local.x if local.fun<fit.fun else fit.x)
report={'model':'uniform response with fitted floor friction','fitCases':[g['case'] for g,d in trials],
        'parameters':p,'evaluations':calls,'seconds':time.perf_counter()-start,'history':history,'sourceHashes':source_hashes,
        'protocol':'Joint lift/push development. Double lift is validation. Stretch is reserved final test.',
        'fitRMSE':{g['case']:score(g,d,rollout(g,p)) for g,d in trials}}
if source_hashes!={s:hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in files}:
    raise RuntimeError('Source changed during fitting; refuse ambiguous evidence')
for g,d in trials:
    save_graph(out/(g['case']+'.json'),g,p,{'origin':'fitted-observations','fitCases':report['fitCases'],'dataset':'PhysTwin','sourceRevision':'05665bcd0edad8f069c7def9cbb58d2eb75d68d0'})
    np.save(out/(g['case']+'.npy'),rollout(g,p))
(out/'report.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='history'},indent=2),flush=True)
