"""Fit on lift only; evaluate development push separately. Stretch stays sealed."""
import argparse
import hashlib
import json
import time
from pathlib import Path
import numpy as np
from scipy.optimize import differential_evolution, minimize
from measured_graph import make_graph, rollout, score, save_graph

parser = argparse.ArgumentParser()
parser.add_argument("--case", default="single_lift_sloth")
parser.add_argument("--nodes", type=int, default=320)
parser.add_argument("--iterations", type=int, default=30)
parser.add_argument("--regional", action="store_true")
parser.add_argument("--output", default="work/measured-pilot")
args = parser.parse_args()
if "stretch" in args.case:
    raise ValueError("Stretch recordings are reserved test interactions")
out = Path(args.output)
if out.exists():
    raise ValueError("Choose a fresh output directory; preserve prior experiments")
out.mkdir(parents=True)
graph, data = make_graph(args.case, args.nodes)
baseline = [1e-5, 1e-5, 1e-6, 4.0]
count = 0
start = time.perf_counter()
history = []

def decode(x):
    if args.regional:
        return [10**x[0], 10**x[1], 10**x[2], 10**x[3]]
    return [10**x[0], 10**x[0], 10**x[1], 10**x[2]]

def objective(x):
    global count
    parameters = decode(x)
    value = score(graph, data, rollout(graph, parameters), stride=3)
    count += 1
    if not history or value < history[-1]["rmse"]:
        history.append({"evaluation": count, "rmse": value, "parameters": parameters})
        print(json.dumps(history[-1]), flush=True)
    return value

baseline_score = score(graph, data, rollout(graph, baseline))
print(json.dumps({"baselineRMSE": baseline_score, "nodes": len(graph['rest']), "edges": len(graph['edges'])}), flush=True)
bounds = [(-8, -2), (-8, -2), (-1, 2)]
if args.regional:
    bounds.insert(0, (-8, -2))
fit = differential_evolution(objective, bounds, maxiter=args.iterations, popsize=7, seed=20260914, tol=.003, polish=False)
local = minimize(objective, fit.x, method="Nelder-Mead", bounds=bounds, options={"maxiter": 90, "xatol": .01, "fatol": 1e-6})
parameters = decode(local.x if local.fun < fit.fun else fit.x)
trajectory = rollout(graph, parameters)
elapsed = time.perf_counter() - start
report = {"case": args.case, "model": "regional" if args.regional else "uniform", "parameters": parameters,
          "baselineParameters": baseline, "baselineRMSE": baseline_score, "fitRMSE": score(graph, data, trajectory),
          "evaluations": count, "seconds": elapsed, "nodes": len(graph['rest']), "edges": len(graph['edges']), "history": history,
          "protocol": "All lift frames are fitting; push is development; stretch is reserved separate-interaction test.",
          "sourceHashes": {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['scripts/measured_graph.py','scripts/fit-measured.py']}}
(out/'report.json').write_text(json.dumps(report,indent=2))
np.save(out/'trajectory.npy',trajectory)
save_graph(out/'asset.json', graph, parameters, {"origin": "fitted-observations", "dataset": "PhysTwin", "case": args.case, "sourceRevision": "05665bcd0edad8f069c7def9cbb58d2eb75d68d0"})
print(json.dumps({k:v for k,v in report.items() if k not in ['history','sourceHashes']},indent=2),flush=True)
