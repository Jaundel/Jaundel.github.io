"""Capacity ablation: add one spatial response coefficient to the joint fit."""
import hashlib
import json
import time
from pathlib import Path
import numpy as np
from scipy.optimize import differential_evolution, minimize
from measured_graph import make_graph, rollout, score, save_graph

out=Path('work/measured-joint-regional-01')
if out.exists(): raise ValueError('Preserve prior results')
out.mkdir(parents=True)
sources=['scripts/measured_graph.py','scripts/fit-measured-regional.py']
hashes={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sources}
trials=[make_graph(c) for c in ['single_lift_sloth','single_push_sloth']]
base=json.loads(Path('work/measured-joint-01/report.json').read_text())['parameters']
initial=np.asarray([np.log10(v) for v in base[:4]]+[base[4]])
history=[];calls=0;start=time.perf_counter()

def decode(x): return [10**v for v in x[:4]]+[x[4]]
def objective(x):
    global calls
    values=[score(g,d,rollout(g,decode(x)),stride=3) for g,d in trials]
    value=float(np.sqrt(np.mean(np.square(values))));calls+=1
    if not history or value<history[-1]['rmse']:
        history.append({'evaluation':calls,'rmse':value,'trialRMSE':values,'parameters':decode(x)})
        print(json.dumps(history[-1]),flush=True)
    return value

bounds=np.asarray([[-8,-2],[-8,-2],[-8,-2],[-1,2],[0,1.5]])
rng=np.random.default_rng(20260914)
population=np.clip(initial+rng.normal(size=(35,5))*[.5,.5,.7,.3,.12],bounds[:,0],bounds[:,1]);population[0]=initial
fit=differential_evolution(objective,bounds,init=population,maxiter=25,seed=20260914,tol=.001,polish=False)
local=minimize(objective,fit.x,method='Nelder-Mead',bounds=bounds,options={'maxiter':160,'xatol':.005,'fatol':1e-7})
p=decode(local.x if local.fun<fit.fun else fit.x)
report={'model':'two geometric regions with fitted floor friction','fitCases':[g['case'] for g,d in trials],
        'parameters':p,'evaluations':calls,'seconds':time.perf_counter()-start,'history':history,'sourceHashes':hashes,
        'regionDefinition':'Rest-frame world X split at node median. Geometric field, not established anatomical/material correspondence.',
        'fitRMSE':{g['case']:score(g,d,rollout(g,p)) for g,d in trials}}
if hashes!={s:hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in sources}:raise RuntimeError('Source changed during fitting')
(out/'report.json').write_text(json.dumps(report,indent=2))
for g,d in trials:
    save_graph(out/(g['case']+'.json'),g,p,{'origin':'fitted-observations','fitCases':report['fitCases'],'dataset':'PhysTwin'})
print(json.dumps({k:v for k,v in report.items() if k!='history'},indent=2),flush=True)
