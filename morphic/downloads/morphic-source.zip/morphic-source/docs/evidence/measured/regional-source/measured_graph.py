"""Compact distance-constraint response model for PhysTwin observations.

Independent XPBD implementation. Geometry/loading are derived from frame zero and
hand trajectories, never from later object observations. All masses are prescribed
unit masses: compliance is an effective discrete response, not a material modulus.
"""
from pathlib import Path
import json
import numpy as np
from numba import njit
from scipy.spatial import cKDTree
from numpy_pickle import load_numpy_data


def farthest_points(points, count):
    chosen = [int(np.argmax(np.linalg.norm(points - points.mean(axis=0), axis=1)))]
    distance = np.full(len(points), np.inf)
    for _ in range(min(count, len(points)) - 1):
        distance = np.minimum(distance, np.sum((points - points[chosen[-1]]) ** 2, axis=1))
        chosen.append(int(np.argmax(distance)))
    return np.asarray(chosen)


def make_graph(case, nodes=320, neighbours=14, radius=0.065):
    path = Path("work/phystwin") / case
    data = load_numpy_data(path / "final_data.pkl")
    points = np.concatenate([data["object_points"][0], data["surface_points"], data["interior_points"]])
    selected = farthest_points(points, nodes)
    rest = np.ascontiguousarray(points[selected])
    tree = cKDTree(rest)
    distances, near = tree.query(rest, k=neighbours + 1)
    pairs = sorted({tuple(sorted((i, int(j)))) for i in range(nodes) for d, j in zip(distances[i, 1:], near[i, 1:]) if d < radius})
    # Fail on disconnected structures rather than silently bridge distant limbs.
    from scipy.sparse import csr_matrix
    from scipy.sparse.csgraph import connected_components
    edges = np.asarray(pairs, dtype=np.int64)
    adj = csr_matrix((np.ones(len(edges)), (edges[:, 0], edges[:, 1])), shape=(nodes, nodes))
    components = connected_components(adj, directed=False)[0]
    if components != 1:
        raise ValueError(f"{case}: graph has {components} disconnected components")
    object_edges = len(edges)
    controller = data["controller_points"].copy()
    control_pairs = []
    for j, p in enumerate(controller[0]):
        dd, nn = tree.query(p, k=8)
        control_pairs.extend((int(i), nodes + j) for d, i in zip(dd, nn) if d < 0.06)
    if not control_pairs:
        raise ValueError("No contact between observed hands and object")
    edges = np.concatenate([edges, np.asarray(control_pairs, dtype=np.int64)])
    all_rest = np.concatenate([rest, controller[0]])
    lengths = np.linalg.norm(all_rest[edges[:, 0]] - all_rest[edges[:, 1]], axis=1)
    if lengths.min() < 1e-7:
        raise ValueError("Degenerate graph edge")
    # A documented world-X split; do not claim anatomical correspondence.
    region = np.zeros(len(edges), dtype=np.int64)
    split = float(np.median(rest[:, 0]))
    region[:object_edges] = (rest[edges[:object_edges, 0], 0] + rest[edges[:object_edges, 1], 0]) * .5 > split
    region[object_edges:] = 2
    # Observation binding is computed solely from the first-frame locations.
    distances, binding = tree.query(data["object_points"][0], k=4)
    weights = 1 / np.maximum(distances, 1e-5) ** 2
    weights /= weights.sum(axis=1, keepdims=True)
    graph = {"case": case, "rest": rest, "edges": edges, "lengths": lengths,
             "region": region, "controller": controller, "objectEdges": object_edges,
             "binding": binding, "weights": weights, "split": split,
             "fps": json.loads((path / "metadata.json").read_text())["fps"],
             "selected": selected}
    return graph, data


@njit(cache=True)
def simulate(rest, edges, lengths, region, controller, compliance, damping,
             friction=0.5, substeps=8, iterations=5, fps=30.0):
    n = len(rest)
    x = np.zeros((n + controller.shape[1], 3))
    x[:n] = rest
    x[n:] = controller[0]
    v = np.zeros((n, 3))
    result = np.zeros((len(controller), n, 3))
    result[0] = rest
    dt = 1.0 / (fps * substeps)
    decay = np.exp(-damping * dt)
    alpha = compliance / (dt * dt)
    lambdas = np.zeros(len(edges))
    for frame in range(1, len(controller)):
        for sub in range(substeps):
            previous = x[:n].copy()
            for i in range(n):
                for a in range(3):
                    v[i, a] *= decay
                v[i, 2] += 9.81 * dt
                for a in range(3):
                    x[i, a] += v[i, a] * dt
            for i in range(controller.shape[1]):
                for a in range(3):
                    x[n+i, a] = controller[frame-1, i, a] + (controller[frame, i, a] - controller[frame-1, i, a]) * (sub + 1) / substeps
            lambdas[:] = 0
            for _ in range(iterations):
                for e in range(len(edges)):
                    i, j = edges[e]
                    dx, dy, dz = x[i, 0] - x[j, 0], x[i, 1] - x[j, 1], x[i, 2] - x[j, 2]
                    length = np.sqrt(dx*dx + dy*dy + dz*dz)
                    if length < 1e-12:
                        continue
                    wj = 1.0 if j < n else 0.0
                    aa = alpha[region[e]]
                    dl = (-(length - lengths[e]) - aa * lambdas[e]) / (1.0 + wj + aa)
                    lambdas[e] += dl
                    q = dl / length
                    x[i, 0] += dx*q
                    x[i, 1] += dy*q
                    x[i, 2] += dz*q
                    if j < n:
                        x[j, 0] -= dx*q
                        x[j, 1] -= dy*q
                        x[j, 2] -= dz*q
                for i in range(n):
                    if x[i, 2] > 0:
                        penetration = x[i, 2]
                        x[i, 2] = 0
                        dx, dy = x[i, 0]-previous[i, 0], x[i, 1]-previous[i, 1]
                        length = np.sqrt(dx*dx + dy*dy)
                        if length > 1e-12:
                            q = min(1.0, friction * penetration / length)
                            x[i, 0] -= dx*q
                            x[i, 1] -= dy*q
            for i in range(n):
                for a in range(3):
                    v[i, a] = (x[i, a] - previous[i, a]) / dt
        result[frame] = x[:n]
    return result


def rollout(graph, parameters, frame_end=None, substeps=8, iterations=5):
    return simulate(graph["rest"], graph["edges"], graph["lengths"], graph["region"],
                    graph["controller"][:frame_end], np.asarray(parameters[:3], dtype=float),
                    float(parameters[3]), friction=float(parameters[4]) if len(parameters) > 4 else 0.5,
                    substeps=substeps, iterations=iterations, fps=float(graph["fps"]))


def marker_predictions(graph, observations0, trajectory):
    displacement = trajectory - graph["rest"]
    return observations0 + (displacement[:, graph["binding"]] * graph["weights"][None, :, :, None]).sum(axis=2)


def score_numpy(graph, data, trajectory, stride=1):
    count = len(trajectory)
    frames = np.arange(stride, count, stride)
    predicted = marker_predictions(graph, data["object_points"][0], trajectory[frames])
    mask = data["object_visibilities"][frames] & data["object_motions_valid"][frames]
    errors = np.sum((predicted - data["object_points"][frames]) ** 2, axis=2)
    return float(np.sqrt(np.mean(errors[mask])))


@njit(cache=True)
def score_kernel(rest, binding, weights, trajectory, observations, visible, valid, stride):
    total = 0.0
    count = 0
    for f in range(stride, len(trajectory), stride):
        for i in range(observations.shape[1]):
            if not visible[f, i] or not valid[f, i]:
                continue
            error = 0.0
            for a in range(3):
                displacement = 0.0
                for j in range(4):
                    n = binding[i, j]
                    displacement += weights[i, j] * (trajectory[f, n, a] - rest[n, a])
                difference = observations[0, i, a] + displacement - observations[f, i, a]
                error += difference * difference
            total += error
            count += 1
    return np.sqrt(total / count) if count else np.inf


def score(graph, data, trajectory, stride=1):
    return float(score_kernel(graph['rest'], graph['binding'], graph['weights'], trajectory,
                              data['object_points'], data['object_visibilities'],
                              data['object_motions_valid'], stride))


def save_graph(path, graph, parameters, provenance):
    values = {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in graph.items() if k not in ["selected", "binding", "weights"]}
    values.update(schema="morphic-measured-graph-1", parameters=list(parameters[:4]),
                  settings={"substeps": 8, "iterations": 5, "gravity": [0, 0, 9.81], "floorZ": 0, "friction": float(parameters[4]) if len(parameters)>4 else 0.5, "unitMass": 1},
                  units={"length": "m", "time": "s", "mass": "prescribed unit mass; not measured"}, provenance=provenance)
    Path(path).write_text(json.dumps(values, separators=(",", ":")))
