"""Register a generated mesh using the frozen INPUT visual hull and masks only.

This is an evaluation alignment aid, not part of ordinary user reconstruction.
Both single-image and multi-image generators receive this same two-view alignment
aid. Do not call their aligned scores unaided single-view reconstruction accuracy.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
import trimesh
from deform360_geometry import silhouette_iou

spec = importlib.util.spec_from_file_location('hull', Path(__file__).with_name('reconstruct-deform360-hull.py'))
hull = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hull)
ROOT = hull.ROOT


def sample_surface(mesh, count=2048):
    random = np.random.default_rng(42)
    selected = random.choice(len(mesh.faces), count, p=mesh.area_faces / mesh.area)
    uv = random.random((count, 2))
    uv[uv.sum(axis=1) > 1] = 1 - uv[uv.sum(axis=1) > 1]
    triangles = mesh.triangles[selected]
    return triangles[:, 0] + uv[:, :1] * (triangles[:, 1] - triangles[:, 0]) + uv[:, 1:] * (triangles[:, 2] - triangles[:, 0])


def similarity(source, target):
    a, b = source.mean(axis=0), target.mean(axis=0)
    centered = source - a
    u, singular, vt = np.linalg.svd(centered.T @ (target - b))
    sign = np.eye(3)
    sign[-1, -1] = np.linalg.det(vt.T @ u.T)
    rotation = vt.T @ sign @ u.T
    scale = np.sum(singular * np.diag(sign)) / np.sum(centered ** 2)
    if not np.isfinite(scale) or scale <= 0:
        raise ValueError('Invalid registration scale.')
    transform = np.eye(4)
    transform[:3, :3] = scale * rotation
    transform[:3, 3] = b - scale * rotation @ a
    return transform


def transform_points(points, transform):
    return points @ transform[:3, :3].T + transform[:3, 3]


def register(source, target, rotation, iterations=30):
    scale = np.sqrt(np.sum((target - target.mean(axis=0)) ** 2) /
                    np.sum((source - source.mean(axis=0)) ** 2))
    transform = np.eye(4)
    transform[:3, :3] = rotation * scale
    transform[:3, 3] = target.mean(axis=0) - transform[:3, :3] @ source.mean(axis=0)
    target_tree = cKDTree(target)
    for _ in range(iterations):
        moved = transform_points(source, transform)
        _, forward = target_tree.query(moved)
        _, reverse = cKDTree(moved).query(target)
        a = np.vstack([moved, moved[reverse]])
        b = np.vstack([target[forward], target])
        correction = similarity(a, b)
        transform = correction @ transform
    return transform


def main(args):
    destination = args.output.resolve()
    destination.mkdir(parents=True, exist_ok=False)
    split = json.loads((ROOT / 'split.json').read_text())
    preparation = json.loads((ROOT / 'preparation.json').read_text())
    hull_report = json.loads((ROOT / 'hull-baseline/report.json').read_text())
    calibration = json.loads((ROOT / 'calibration-verified.json').read_text())
    if hull.sha(ROOT / 'split.json') != hull_report['splitSha256']:
        raise ValueError('Input partition changed.')
    if hull.sha(ROOT / 'preparation.json') != hull_report['preparationSha256']:
        raise ValueError('Input preparation changed.')
    if hull.sha(ROOT / 'calibration-verified.json') != hull_report['calibrationSha256']:
        raise ValueError('Verified calibration changed.')
    if hull.sha(ROOT / 'hull-baseline/world-mesh.ply') != hull_report['outputs']['world-mesh.ply']:
        raise ValueError('Input-only hull changed.')
    target = trimesh.load(ROOT / 'hull-baseline/world-mesh.ply', force='mesh')
    original = trimesh.load(args.mesh, force='mesh')
    if not np.isfinite(original.vertices).all() or original.area <= 0:
        raise ValueError('Invalid generated geometry.')
    inputs = []
    for entry in preparation['inputs']:
        name = entry['camera']
        if name not in split['inputCameras']:
            raise ValueError('Non-input view requested for registration.')
        path = ROOT / 'inputs' / (name + '.png')
        if hull.sha(path) != entry['sha256']:
            raise ValueError('Input mask changed.')
        inputs.append((name, calibration['cameras'][name], np.asarray(Image.open(path).getchannel('A')) > 127))
    source_points, target_points = sample_surface(original), sample_surface(target)
    candidates = []
    best = None
    for index, rotation in enumerate(Rotation.create_group('O').as_matrix()):
        transform = register(source_points, target_points, rotation)
        mesh = original.copy()
        mesh.apply_transform(transform)
        scores = {name: silhouette_iou(hull.render_silhouette(mesh, camera), mask)
                  for name, camera, mask in inputs}
        mean = float(np.mean(list(scores.values())))
        candidates.append({'index': index, 'meanInputIoU': mean,
                           'inputIoU': scores, 'transform': transform.tolist()})
        if best is None or mean > best[0]:
            best = mean, mesh, candidates[-1]
        print(f'Candidate {index + 1}/24 input IoU {mean:.4f}', flush=True)
    best[1].export(destination / 'world-mesh.ply')
    best[1].export(destination / 'aligned.glb')
    report = {'schema': 1, 'method': '24 cube rotations + symmetric similarity ICP to input-only hull',
        'samplesPerMesh': 2048, 'seed': 42, 'iterations': 30,
        'generatedMeshSha256': hull.sha(args.mesh),
        'inputHullReportSha256': hull.sha(ROOT / 'hull-baseline/report.json'),
        'splitSha256': hull.sha(ROOT / 'split.json'),
        'alignmentSourceSha256': hull.sha(Path(__file__)),
        'best': best[2], 'candidates': candidates,
        'worldMeshSha256': hull.sha(destination / 'world-mesh.ply'),
        'heldOutEvaluation': 'not run',
        'limitation': 'Both generators receive two-view pose/scale alignment supervision.'}
    (destination / 'alignment.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'Best mean input IoU: {best[0]:.4f}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mesh', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    main(parser.parse_args())
