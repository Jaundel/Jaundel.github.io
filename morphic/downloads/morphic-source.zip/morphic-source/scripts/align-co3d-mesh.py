"""Align a frozen generated mesh using only the twelve CO3D input masks.

Both generators receive identical extra evaluation alignment supervision.
This is not an unaided single-view accuracy measurement.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.spatial.transform import Rotation
import trimesh
from deform360_geometry import silhouette_iou

spec = importlib.util.spec_from_file_location('alignment', Path(__file__).with_name('align-capture-mesh.py'))
alignment = importlib.util.module_from_spec(spec)
spec.loader.exec_module(alignment)
sha = alignment.hull.sha
ROOT = Path(__file__).resolve().parents[1] / 'work/co3d/190_20494_39385'


def main(args):
    prepared_path = ROOT / 'evaluation-inputs/preparation.json'
    prepared = json.loads(prepared_path.read_text())
    report_path = ROOT / 'input-hull/report.json'
    hull_report = json.loads(report_path.read_text())
    if sha(prepared_path) != hull_report['preparationSha256']:
        raise ValueError('Input preparation changed.')
    if sha(ROOT.parent / 'toytruck-split.json') != prepared['splitSha256']:
        raise ValueError('Frozen split changed.')
    hull_path = ROOT / 'input-hull/world-mesh.ply'
    if sha(hull_path) != hull_report['outputs']['world-mesh.ply']:
        raise ValueError('Input hull changed.')
    inputs = []
    for item in prepared['inputs']:
        path = prepared_path.parent / item['mask']
        if item['frame'] in prepared['heldoutFrames'] or sha(path) != item['maskSha256']:
            raise ValueError('Non-input or modified alignment mask.')
        inputs.append((item['frame'], item['camera'], np.asarray(Image.open(path)) > 127))
    target = trimesh.load(hull_path, force='mesh')
    original = trimesh.load(args.mesh, force='mesh')
    if not np.isfinite(original.vertices).all() or original.area <= 0:
        raise ValueError('Invalid generated geometry.')
    args.output.mkdir(parents=True, exist_ok=False)
    source_points, target_points = alignment.sample_surface(original), alignment.sample_surface(target)
    best, candidates = None, []
    for index, rotation in enumerate(Rotation.create_group('O').as_matrix()):
        transform = alignment.register(source_points, target_points, rotation)
        mesh = original.copy(); mesh.apply_transform(transform)
        scores = {number: silhouette_iou(alignment.hull.render_silhouette(mesh, camera), mask)
                  for number, camera, mask in inputs}
        mean = float(np.mean(list(scores.values())))
        candidate = {'index': index, 'meanInputIoU': mean, 'inputIoU': scores, 'transform': transform.tolist()}
        candidates.append(candidate)
        if best is None or mean > best[0]:
            best = mean, mesh, candidate
        print(f'Candidate {index + 1}/24: input IoU {mean:.4f}', flush=True)
    best[1].export(args.output / 'world-mesh.ply')
    best[1].export(args.output / 'aligned.glb')
    report = {'method': '24 cube rotations + symmetric similarity ICP to input-only hull',
              'samplesPerMesh': 2048, 'seed': 42, 'iterations': 30,
              'generatedMeshSha256': sha(args.mesh), 'preparationSha256': sha(prepared_path),
              'inputHullReportSha256': sha(report_path), 'sourceSha256': sha(Path(__file__)),
              'registrationHelperSha256': sha(Path(alignment.__file__)),
              'best': best[2], 'candidates': candidates,
              'worldMeshSha256': sha(args.output / 'world-mesh.ply'),
              'heldoutPixelsRead': False,
              'limitation': 'Both generators receive twelve supplied input masks and camera poses as evaluation alignment aids; alignment error is not separated from geometry error.'}
    (args.output / 'alignment.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'Best input IoU: {best[0]:.4f}', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mesh', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    main(parser.parse_args())
