"""Check the analytic appearance derivative against finite differences.

This validates the covariance-transport formula, not GPU arithmetic or image quality.
Nearest-node neighborhoods are held fixed for the local derivative.
"""
from pathlib import Path
import json
import hashlib
import numpy as np
import imageio.v2 as imageio
from PIL import Image,ImageDraw,ImageFont

case='single_lift_sloth'
packed=np.fromfile(f'public/measured/{case}/gaussians.bin',dtype='<f4').reshape(-1,16)
asset=json.loads(Path(f'public/measured/{case}/asset.json').read_text())
rest=np.asarray(asset['rest'])
indices=np.linspace(0,len(packed)-1,2048,dtype=int)
p=packed[indices,:3].astype(float)
ids=packed[indices,8:12].astype(int)
neighbors=rest[ids]
trajectory=np.load(f'work/measured-evaluation/{case}/jointUniform.npy')

def field(points,delta):
    difference=points[:,None,:]-neighbors
    raw=1/np.maximum(np.sum(difference**2,axis=-1),1e-10)
    weights=raw/raw.sum(axis=1,keepdims=True)
    return points+(weights[:,:,None]*delta).sum(axis=1)

def derivative(delta):
    difference=p[:,None,:]-neighbors
    distance2=np.sum(difference**2,axis=-1)
    raw=1/np.maximum(distance2,1e-10);total=raw.sum(axis=1,keepdims=True)
    weights=raw/total
    gradients=np.where((distance2>1e-10)[:,:,None],-2*difference*raw[:,:,None]**2,0)
    gradients=(gradients-weights[:,:,None]*gradients.sum(axis=1,keepdims=True))/total[:,:,None]
    return np.eye(3)+np.einsum('nki,nkj->nij',delta,gradients)

rows=[]
for frame in [0,42,84]:
    delta=trajectory[frame][ids]-neighbors
    F=derivative(delta);eps=1e-7
    numerical=np.stack([(field(p+np.eye(3)[a]*eps,delta)-field(p-np.eye(3)[a]*eps,delta))/(2*eps) for a in range(3)],axis=2)
    error=float(np.max(np.abs(F-numerical)))
    assert error<1e-5,error
    determinant=np.linalg.det(F)
    rows.append({'frame':frame,'maximumDerivativeError':error,'sampleCount':len(p),
                 'negativeDeterminantSamples':int((determinant<0).sum()),'minimumDeterminant':float(determinant.min())})
translation=np.tile([.03,-.02,.01],(len(p),4,1))
translation_error=float(np.max(np.abs(derivative(translation)-np.eye(3))))
assert translation_error<1e-12
report={'scope':__doc__,'translationDerivativeError':translation_error,'frames':rows,
        'sources':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [Path(__file__),Path('src/render/gaussian-appearance.js')]}}
Path('docs/evidence/measured/appearance-audit.json').write_text(json.dumps(report,indent=2))
calibration=json.loads(Path(f'public/measured/{case}/observations.json').read_text())
projection=np.asarray(calibration['K'])@np.linalg.inv(calibration['c2w'])[:3]
points=field(p,trajectory[84][ids]-neighbors)
pixels=np.c_[points,np.ones(len(points))]@projection.T
pixels=pixels[:,:2]/pixels[:,2:]*1.5+[4,0]
reader=imageio.get_reader('public/media/measured/sloth-gaussian-camera.mp4')
image=Image.fromarray(reader.get_data(84));reader.close()
draw=ImageDraw.Draw(image)
for u,v in pixels[np.linalg.det(derivative(trajectory[84][ids]-neighbors))<0]:
    draw.ellipse((u-5,v-5,u+5,v+5),outline='#b54030',width=2)
draw.rectangle((0,670,1280,720),fill='white')
draw.text((20,681),'2.80 s: red rings mark 42 / 2048 sampled locations with a folded appearance field',font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',20),fill='#222222')
image.save('public/media/measured/sloth-fold-diagnostic.jpg',quality=95)
print(json.dumps(report,indent=2))
