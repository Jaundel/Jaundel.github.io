import fs from "node:fs";
import os from "node:os";
import crypto from "node:crypto";
import {
  specimen,
  SETTINGS,
  INITIAL,
  loading,
  observe,
} from "../src/behavior/fixture.js";
import {
  fitResponse,
  evaluate,
  predict,
  makePhysicalAsset,
  deployAsset,
  verifyReplay,
} from "../src/behavior/experiment.js";

const { cage, vertices, triangles } = specimen();
const trainInput = loading(cage);
const testInput = loading(cage, { axis: 2, amplitude: 0.075 });
let sideNode = 0,
  closest = Infinity;
for (let i = 0; i < cage.rest.length / 3; i++) {
  const d = [0.12, 1.48, 0.12].reduce(
    (s, q, a) => s + (q - cage.rest[i * 3 + a]) ** 2,
    0,
  );
  if (d < closest) {
    closest = d;
    sideNode = i;
  }
}
const otherInput = loading(cage, { axis: 0, amplitude: -0.06, node: sideNode });
const cases = [
  { name: "uniform", truth: { ...INITIAL, edge: [7e-5], damping: 3.2 } },
  {
    name: "two-region",
    truth: { ...INITIAL, edge: [2e-5, 8e-4], damping: 3.2 },
  },
];
const rows = [];
let hero;
for (const example of cases) {
  for (const seed of [1, 7, 23]) {
    const train = observe(cage, SETTINGS, example.truth, trainInput, {
      noiseM: 0.0005,
      seed,
    });
    const test = observe(cage, SETTINGS, example.truth, testInput, {
      role: "test",
      noiseM: 0.0005,
      seed: seed + 100,
    });
    const other = observe(cage, SETTINGS, example.truth, otherInput, {
      role: "test",
      noiseM: 0.0005,
      seed: seed + 200,
    });
    const uniform = fitResponse(cage, SETTINGS, [train], INITIAL, {
      rounds: 13,
    });
    const regional = fitResponse(cage, SETTINGS, [train], uniform.field, {
      regional: true,
      rounds: 16,
    });
    const row = {
      case: example.name,
      seed,
      uniform,
      regional,
      test: Object.fromEntries(
        [
          ["preset", INITIAL],
          ["uniform", uniform.field],
          ["regional", regional.field],
        ].map(([name, field]) => [name, evaluate(cage, SETTINGS, field, test)]),
      ),
      testOther: Object.fromEntries(
        [
          ["preset", INITIAL],
          ["uniform", uniform.field],
          ["regional", regional.field],
        ].map(([name, field]) => [
          name,
          evaluate(cage, SETTINGS, field, other),
        ]),
      ),
    };
    rows.push(row);
    console.log(example.name, seed, JSON.stringify(row.test));
    if (example.name === "two-region" && seed === 1)
      hero = { train, test, other, uniform, regional, truth: example.truth };
  }
}
const asset = makePhysicalAsset(cage, SETTINGS, hero.regional, {
  kind: "fitted-to-synthetic-observations",
  trainingTrial: hero.train.id,
  assumptions:
    "Known rest geometry; fixed 100 kg/m3 density; no gravity; prescribed compliant handle; bulk fixed; no measured material modulus.",
});
const field = deployAsset(cage, SETTINGS, JSON.parse(JSON.stringify(asset)));
const ticks = hero.test.observations.map((f) => f.tick);
const predicted = predict(cage, SETTINGS, field, testInput, ticks);
const edited = { ...field, edge: [field.edge[0], field.edge[1] / 5] };
const curves = Object.fromEntries(
  [
    ["preset", INITIAL],
    ["uniform", hero.uniform.field],
    ["regional", field],
    ["edited", edited],
    ["reference", hero.truth],
  ].map(([key, f]) => [
    key,
    predict(cage, SETTINGS, f, testInput, ticks).frames,
  ]),
);
// Hold parameters fixed when changing numerical settings; this measures deployment sensitivity.
const sensitivity = [6, 12, 24].map((iterations) => ({
  iterations,
  ...evaluate(cage, { ...SETTINGS, iterations }, field, hero.test),
}));
const fineTrial = {
  ...hero.test,
  endTick: hero.test.endTick * 2,
  events: hero.test.events.map((e) => ({ ...e, tick: e.tick * 2 })),
  observations: hero.test.observations.map((f) => ({ ...f, tick: f.tick * 2 })),
};
const timestepSensitivity = evaluate(
  cage,
  { ...SETTINGS, dt: SETTINGS.dt / 2 },
  field,
  fineTrial,
);
const runtimeMs = [];
for (let i = 0; i < 12; i++) {
  const start = performance.now();
  predict(cage, SETTINGS, field, testInput, []);
  if (i >= 2) runtimeMs.push((performance.now() - start) / testInput.endTick);
}
runtimeMs.sort((a, b) => a - b);
const sparse = {
  ...hero.train,
  observations: hero.train.observations.map((f) => ({
    ...f,
    points: f.points.slice(0, 1),
  })),
};
const sparseFit = fitResponse(cage, SETTINGS, [sparse], INITIAL, {
  rounds: 13,
});
const sparseRegional = fitResponse(cage, SETTINGS, [sparse], sparseFit.field, {
  regional: true,
  rounds: 16,
});
const wrongMass = observe(
  cage,
  { ...SETTINGS, density: 200 },
  hero.truth,
  testInput,
  { role: "test" },
);
// A changed bulk response is withheld model mismatch, not measurement noise.
const mismatch = observe(
  cage,
  SETTINGS,
  { ...hero.truth, bulk: 0.003 },
  testInput,
  { role: "test" },
);
const report = {
  schema: 1,
  createdUTC: new Date().toISOString(),
  scope: "Synthetic identification only; NOT real-object validation",
  environment: {
    node: process.version,
    cpu: os.cpus()[0].model,
    platform: process.platform,
  },
  geometry: {
    nodes: cage.rest.length / 3,
    tetrahedra: cage.tets.length / 4,
    hM: cage.h,
  },
  protocol: {
    settings: SETTINGS,
    trainingAction: "x pull then release",
    testAction: "larger z pull then release",
    noisePerCoordinateStdM: 0.0005,
    seeds: [1, 7, 23],
    excluded: "pinned and directly driven nodes",
    objective:
      "mean squared 3D point error; test motion unavailable to optimizer",
    caveat:
      "Same-solver synthetic inverse test; no continuum convergence or physical accuracy claim",
  },
  rows,
  sensitivity,
  timestepSensitivity,
  runtime: {
    scope:
      "Node rollout including setup and session recording, divided by steps; two warmups then ten runs",
    medianStepMs: runtimeMs[5],
    p95StepMs: runtimeMs[9],
  },
  sparseAblation: {
    fit: sparseFit,
    test: evaluate(cage, SETTINGS, sparseFit.field, hero.test),
    regionalFit: sparseRegional,
    regionalTest: evaluate(cage, SETTINGS, sparseRegional.field, hero.test),
  },
  mismatch: evaluate(cage, SETTINGS, field, mismatch),
  wrongMass: evaluate(cage, SETTINGS, field, wrongMass),
  replayMaxErrorM: verifyReplay(cage, predicted),
  editedResponseDifferenceM: Math.sqrt(
    curves.edited
      .flatMap((f, i) => f.x.map((q, j) => (q - curves.regional[i].x[j]) ** 2))
      .reduce((a, b) => a + b, 0) /
      (ticks.length * cage.rest.length),
  ),
};
fs.mkdirSync("public/behavior", { recursive: true });
fs.mkdirSync("docs/evidence/behavior", { recursive: true });
const bundle = {
  report,
  asset,
  train: hero.train,
  test: hero.test,
  other: hero.other,
  curves,
};
fs.writeFileSync("public/behavior/study.json", JSON.stringify(bundle));
fs.writeFileSync(
  "docs/evidence/behavior/results.json",
  JSON.stringify(report, null, 2),
);
fs.writeFileSync(
  "docs/evidence/behavior/asset.json",
  JSON.stringify(asset, null, 2),
);
fs.writeFileSync(
  "public/behavior/dataset.json",
  JSON.stringify({
    schema: 1,
    units: "m-kg-s",
    origin: "synthetic",
    provenance: {
      source: "Morphic controlled XPBD generator",
      scale:
        "Exact .24 x .72 x .24 metre block, known tetrahedral discretization.",
      loading:
        "Pinned base and single compliant handle, action samples at 120 Hz.",
    },
    geometry: {
      vertices: Array.from(vertices),
      triangles: Array.from(triangles),
      tetrahedra: Array.from(cage.tets),
      h: cage.h,
    },
    settings: SETTINGS,
    initial: INITIAL,
    trials: [hero.train, hero.test, hero.other],
  }),
);
const inputs = [
  "src/physics/solver.js",
  "src/physics/material-field.js",
  "src/behavior/experiment.js",
  "src/physics/session.js",
  "src/behavior/fixture.js",
  "scripts/behavior-study.mjs",
  "public/behavior/study.json",
  "public/behavior/dataset.json",
];
fs.writeFileSync(
  "docs/evidence/behavior/hashes.json",
  JSON.stringify(
    Object.fromEntries(
      inputs.map((p) => [
        p,
        crypto
          .createHash("sha256")
          .update(fs.readFileSync(p, "utf8").replaceAll("\r\n", "\n"))
          .digest("hex"),
      ]),
    ),
    null,
    2,
  ),
);
console.log(
  "Replay drift:",
  report.replayMaxErrorM,
  "Sensitivity:",
  JSON.stringify(sensitivity),
);
