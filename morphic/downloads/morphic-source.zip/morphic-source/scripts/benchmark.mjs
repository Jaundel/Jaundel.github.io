import { readFile, writeFile, mkdir } from "node:fs/promises";
import { createHash } from "node:crypto";
import os from "node:os";
import { geometryFromGLB } from "../src/io/glb.js";
import { buildCage, deform } from "../src/physics/cage.js";
import { Solver } from "../src/physics/solver.js";
import { record, makeSession, replay } from "../src/physics/session.js";
const results = [];
for (const id of ["lemon", "sweet_potato", "met_tablet", "met_bottle"]) {
  const bytes = await readFile(`public/assets/${id}.glb`),
    buffer = bytes.buffer.slice(
      bytes.byteOffset,
      bytes.byteOffset + bytes.byteLength,
    );
  const geometry = geometryFromGLB(buffer),
    start = performance.now(),
    cage = buildCage(geometry.vertices, geometry.triangles, 8),
    prepareMs = performance.now() - start;
  for (const material of ["jelly", "rubber", "foam"]) {
    const s = new Solver(cage),
      times = [],
      initial = deform(cage, s.x);
    record(s, { type: "material", value: material });
    let maxVolumeError = 0,
      maxInverted = 0,
      maxDisplacement = 0,
      minSurface = Infinity;
    for (let i = 0; i < 600; i++) {
      if (i === 10) record(s, { type: "squash" });
      if (i === 200) record(s, { type: "stretch" });
      if (i === 400) record(s, { type: "drop" });
      const t = performance.now();
      s.step();
      times.push(performance.now() - t);
      if (s.fault) break;
      if (i % 10 === 0) {
        const d = s.diagnostics();
        maxVolumeError = Math.max(maxVolumeError, d.meanVolumeError);
        maxInverted = Math.max(maxInverted, d.inverted);
        const skin = deform(cage, s.x);
        for (let j = 0; j < skin.length; j++) {
          if (j % 3 === 1) minSurface = Math.min(minSurface, skin[j]);
          if (i < 400)
            maxDisplacement = Math.max(
              maxDisplacement,
              Math.abs(skin[j] - initial[j]),
            );
        }
      }
    }
    const copy = replay(cage, makeSession(s));
    let replayMaxError = 0;
    for (let i = 0; i < s.x.length; i++)
      replayMaxError = Math.max(replayMaxError, Math.abs(s.x[i] - copy.x[i]));
    times.sort((a, b) => a - b);
    results.push({
      id,
      material,
      sha256: createHash("sha256").update(bytes).digest("hex"),
      vertices: geometry.vertices.length / 3,
      triangles: geometry.triangles.length / 3,
      nodes: cage.rest.length / 3,
      tets: cage.tets.length / 4,
      prepareMs,
      stepMedianMs: times[300],
      stepP95Ms: times[570],
      maxVolumeError,
      maxInverted,
      maxDisplacement,
      minSurface,
      replayMaxError,
      final: s.diagnostics(),
    });
    console.log(id, material, JSON.stringify(results.at(-1)));
  }
}
await mkdir("docs/evidence", { recursive: true });
await writeFile(
  "docs/evidence/benchmark.json",
  JSON.stringify(
    {
      date: new Date().toISOString(),
      node: process.version,
      cpu: os.cpus()[0].model,
      platform: os.platform(),
      ram: os.totalmem(),
      protocol:
        "600 steps at 120 Hz. Squash tick 10; stretch 200; drop 400. 8 cells, 5 iterations. Same-runtime replay. Wall-clock step timings include JIT and diagnostics are sampled every 10 ticks.",
      results,
    },
    null,
    2,
  ) + "\n",
);
if (
  results.some(
    (r) =>
      r.final.fault ||
      r.final.tick !== 600 ||
      r.replayMaxError > 1e-10 ||
      r.maxInverted > 0 ||
      r.minSurface < 0,
  )
)
  process.exitCode = 1;
