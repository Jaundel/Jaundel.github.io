"""Reproducible article and baseline browser checks against a running Vite server."""
import argparse
import hashlib
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser()
parser.add_argument("--url", default="http://127.0.0.1:5174")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
out = root / "docs/evidence/behavior"
out.mkdir(parents=True, exist_ok=True)
errors, checks = [], []
with sync_playwright() as p:
    browser = p.chromium.launch(channel="chrome", headless=True)
    context = browser.new_context(viewport={"width": 1440, "height": 1050}, accept_downloads=True)
    page = context.new_page()
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.goto(args.url + "/article.html")
    page.wait_for_function("window.morphicBehavior")
    assert page.locator("#results tr").count() == 6
    assert page.locator("#other-results tr").count() == 6
    assert page.locator("#error-plot polyline").count() == 3
    page.locator("#comparison").scroll_into_view_if_needed()
    page.screenshot(path=str(out / "article-desktop.png"))
    initial = page.screenshot(clip=page.locator("#comparison").bounding_box())
    page.locator("#model").select_option("uniform")
    changed = page.screenshot(clip=page.locator("#comparison").bounding_box())
    assert hashlib.sha256(initial).digest() != hashlib.sha256(changed).digest()
    page.locator("#trial").select_option("other")
    assert page.evaluate("window.morphicBehavior.trial") == "other"
    page.locator("#trial").select_option("train")
    assert "reconstruction" in page.locator("#comparison-note").inner_text()
    page.locator("#trial").select_option("test")
    page.locator("#play").click()
    page.wait_for_function("window.morphicBehavior.frame !== 7")
    page.locator("#play").click()
    checks.append("Both held-out actions and fitting action; shared playback; comparison pixels change.")
    page.locator("#model").select_option("edited")
    page.locator("#edit").evaluate("(e) => e.value = '0.4'")
    page.locator("#edit").dispatch_event("change")
    assert page.locator("#edit-value").inner_text() == "2.5×"
    with page.expect_download() as download:
        page.locator("#export").click()
    asset_path = out / "browser-export.json"
    download.value.save_as(str(asset_path))
    asset = json.loads(asset_path.read_text())
    assert asset["provenance"]["kind"] == "intentional-material-edit"
    page.locator("#asset-file").set_input_files(str(asset_path))
    page.wait_for_function("document.querySelector('#asset-status').textContent.startsWith('Loaded')")
    assert page.evaluate("window.morphicBehavior.source") == "intentional-material-edit"
    asset["settings"]["dt"] /= 2
    bad = out / "incompatible-asset.json"
    bad.write_text(json.dumps(asset))
    page.locator("#asset-file").set_input_files(str(bad))
    page.wait_for_function("document.querySelector('#asset-status').textContent.includes('refit')")
    checks.append("Material edit reruns; export retains provenance; reload succeeds; timestep mismatch rejected.")
    page.set_viewport_size({"width": 390, "height": 844})
    page.goto(args.url + "/article.html")
    page.wait_for_function("window.morphicBehavior")
    assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
    page.locator("#comparison").scroll_into_view_if_needed()
    page.screenshot(path=str(out / "article-mobile.png"))
    checks.append("390px article has no horizontal page overflow.")
    page.set_viewport_size({"width": 1440, "height": 960})
    page.goto(args.url + "/")
    page.wait_for_function("window.morphicStats && document.querySelector('#loading').hidden")
    for name in ["lemon", "sweet_potato", "met_tablet", "met_bottle"]:
        page.locator("#asset").select_option(name)
        page.wait_for_function("document.querySelector('#loading').hidden && window.morphicStats.tick === 0")
        page.locator("#stretch").click()
        page.wait_for_function("window.morphicStats.tick >= 35")
        page.locator("#play").click()
        assert not page.evaluate("window.morphicStats.fault")
        with page.expect_download() as download:
            page.locator("#save").click()
        saved = root / "work" / (name + "-regression.json")
        download.value.save_as(str(saved))
        assert json.loads(saved.read_text())["engine"] == "morphic-xpbd-3"
        page.locator("#replay").click()
        page.wait_for_function("document.querySelector('#status').textContent.startsWith('Replay complete')", timeout=60000)
    with page.expect_download() as download:
        page.locator("#export").click()
    glb = root / "work" / "behavior-regression.glb"
    download.value.save_as(str(glb))
    assert glb.read_bytes()[:4] == b"glTF"
    checks.append("All four original captures load, stretch, save and replay; GLB export retains a valid header.")
    report = {"url": args.url, "browser": browser.version, "checks": checks, "errors": errors}
    (out / "browser-check.json").write_text(json.dumps(report, indent=2))
    browser.close()
assert not errors, errors
print(json.dumps(report, indent=2))
