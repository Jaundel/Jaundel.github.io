"""Real browser workflow checks. Run after npm run dev. Artifacts are reproducible.
pip install -r requirements-browser.txt; python scripts/browser-check.py
"""
import argparse, json, time, pathlib, statistics
from playwright.sync_api import sync_playwright

parser=argparse.ArgumentParser();parser.add_argument('--url',default='http://127.0.0.1:5173/');args=parser.parse_args()
root=pathlib.Path(__file__).resolve().parents[1];out=root/'docs'/'evidence';out.mkdir(parents=True,exist_ok=True)
media=root/'docs'/'media';media.mkdir(parents=True,exist_ok=True)
report={'url':args.url,'checks':[],'profiles':[]};errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(channel='chrome',headless=True)
    context=browser.new_context(viewport={'width':1440,'height':960},device_scale_factor=1,accept_downloads=True)
    page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('console',lambda m:errors.append(m.text) if m.type=='error' else None)
    def ready():
        page.wait_for_function("window.morphicStats && document.querySelector('#loading').hidden && !document.querySelector('#play').disabled")
        page.wait_for_timeout(300)
    def wait_ticks(t):
        try: page.wait_for_function(f'window.morphicStats.tick >= {t}',timeout=60000)
        except Exception:
            print(page.evaluate('window.morphicStats'),page.locator('#status').inner_text());raise
    def reset():
        page.locator('#reset').click();page.wait_for_function('window.morphicStats.tick===0');page.locator('#home').click();page.wait_for_timeout(300)
    page.goto(args.url);ready()
    report['browser']=browser.version
    report['webgl']=page.evaluate("""() => {const g=document.querySelector('canvas').getContext('webgl2');const e=g.getExtension('WEBGL_debug_renderer_info');return e?g.getParameter(e.UNMASKED_RENDERER_WEBGL):'unavailable'}""")
    assert page.evaluate("getComputedStyle(document.documentElement).backgroundColor")=='rgb(16, 19, 20)'
    page.screenshot(path=str(media/'studio.png'))
    report['checks'].append('Styled initial render; local fonts and assets load without errors')
    for asset in ['lemon','sweet_potato','met_tablet','met_bottle']:
        page.locator('#asset').select_option(asset);page.wait_for_function('window.morphicStats.tick===0');ready()
        page.locator('#squash').click();wait_ticks(65);page.locator('#play').click()
        stats=page.evaluate('window.morphicStats');assert stats['inverted']==0 and not stats['fault']
        page.screenshot(path=str(media/f'{asset}-deformed.png'))
        page.locator('#play').click();wait_ticks(180);page.locator('#play').click()
        with page.expect_download() as d:page.locator('#save').click()
        path=out/f'{asset}.morphic.json';d.value.save_as(str(path));s=json.loads(path.read_text())
        assert s['endTick']>=180 and s['asset']['glb'] and any(e['action']['type']=='squash' for e in s['events'])
        page.locator('#replay').click();page.wait_for_function("document.querySelector('#status').textContent.startsWith('Replay complete')",timeout=60000)
        assert page.locator('#drift').inner_text()=='0 m'
        # Re-import the saved portable session, including its embedded asset.
        page.locator('#session-file').set_input_files(str(path));page.wait_for_function("document.querySelector('#state').textContent==='REPLAYING'",timeout=60000)
        page.wait_for_function("document.querySelector('#status').textContent.startsWith('Replay complete')",timeout=60000)
        assert page.locator('#drift').inner_text()=='0 m'
        report['checks'].append(f'{asset}: deformation, save, replay, portable load all passed')
        # Don't commit bulky copies of assets embedded in test sessions.
        path.unlink()
    reset();page.locator('#asset').select_option('met_tablet');page.wait_for_function('window.morphicStats.renderVertices>70000 && window.morphicStats.tick===0');ready()
    # A real pointer grab against the visible surface, then verify recorded events.
    box=page.locator('canvas').bounding_box();cx=box['x']+box['width']*.5;cy=box['y']+box['height']*.48
    page.mouse.move(cx,cy);page.mouse.down();page.mouse.move(cx+100,cy-70,steps=24);page.wait_for_timeout(300);page.mouse.up();page.locator('#play').click()
    with page.expect_download() as d:page.locator('#save').click()
    grab=out/'grab.morphic.json';d.value.save_as(str(grab));s=json.loads(grab.read_text());grab.unlink()
    kinds=[e['action']['type'] for e in s['events']];assert 'grab' in kinds and 'move' in kinds and 'release' in kinds,kinds
    report['checks'].append('Pointer ray-pick, drag and release generate actual physics events')
    with page.expect_download() as d:page.locator('#export').click()
    export=out/'test-export.glb';d.value.save_as(str(export));assert export.stat().st_size>100000
    page.locator('#file').set_input_files(str(export));page.wait_for_function("document.querySelector('#asset-name').textContent==='test-export'");ready();assert page.locator('#asset-name').inner_text()=='test-export';export.unlink()
    report['checks'].append('Deformed GLB exports and independently re-imports with embedded appearance')
    for surface in ['floor','ramp','sphere']:
        page.locator('#asset').select_option('lemon');page.wait_for_function('window.morphicStats.renderVertices===2231 && window.morphicStats.tick===0');ready();page.locator('#surface').select_option(surface);page.locator('#drop').click();wait_ticks(180);page.locator('#play').click()
        stats=page.evaluate('window.morphicStats');assert not stats['fault'] and stats['inverted']==0,stats
        report['checks'].append(f'{surface}: browser drop remained finite without inverted elements')
    # Matched dense-asset CPU / GPU profiles. Values are browser automation observations,
    # not hardware input-to-photon measurements.
    for mode in ['cpu','gpu']:
        page.goto(args.url+('?cpu=1' if mode=='cpu' else ''));ready();page.locator('#asset').select_option('met_tablet');page.wait_for_function('window.morphicStats.renderVertices>70000 && window.morphicStats.tick===0');ready()
        page.locator('#stretch').click();wait_ticks(180)
        samples=[]
        for _ in range(20):
            samples.append(page.evaluate('window.morphicStats'));page.wait_for_timeout(50)
        report['profiles'].append({'skinning':mode,'asset':'met_tablet','samples':samples,'medianUpdateMs':statistics.median(s['updateCPU'] for s in samples),'medianFPS':statistics.median(s['fps'] for s in samples)})
        page.locator('#play').click()
    page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(300)
    assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
    page.screenshot(path=str(media/'mobile.png'),full_page=True);report['checks'].append('390px mobile layout has no horizontal overflow')
    # Corrupted sessions must fail without replacing the working capture.
    bad=out/'bad.json';bad.write_text('{"schema":999}');page.locator('#session-file').set_input_files(str(bad));bad.unlink()
    page.wait_for_function("document.querySelector('#status').textContent.includes('Unsupported replay')")
    report['checks'].append('Incompatible session rejected explicitly')
    report['errors']=errors;assert not errors,errors
    context.close();browser.close()
(out/'browser-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'checks':report['checks'],'webgl':report['webgl'],'errors':errors},indent=2))
