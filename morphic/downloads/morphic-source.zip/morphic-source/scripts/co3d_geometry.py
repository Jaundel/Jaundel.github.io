"""CO3D metadata to the evaluator's +x-right/+y-down pinhole convention.

Source: official CO3D ViewpointAnnotation and PyTorch3D camera documentation.
No pixels, masks, depths, or point clouds are read here. Dataset world scale is
arbitrary; converting coordinates does not verify calibration accuracy.
"""
import numpy as np


def camera_from_frame(frame):
    height, width = frame['image']['size']
    if any(not isinstance(v, int) or v <= 0 for v in (height, width)):
        raise ValueError('Invalid image dimensions.')
    view = frame['viewpoint']
    rotation = np.asarray(view['R'], dtype=float)
    translation = np.asarray(view['T'], dtype=float)
    focal = np.asarray(view['focal_length'], dtype=float)
    principal = np.asarray(view['principal_point'], dtype=float)
    if (rotation.shape != (3, 3) or translation.shape != (3,)
            or focal.shape != (2,) or principal.shape != (2,)):
        raise ValueError('Invalid camera dimensions.')
    if not all(np.isfinite(v).all() for v in (rotation, translation, focal, principal)):
        raise ValueError('Nonfinite camera annotation.')
    if (not np.allclose(rotation.T @ rotation, np.eye(3), atol=1e-4)
            or not np.isclose(np.linalg.det(rotation), 1, atol=1e-4)
            or np.any(focal <= 0)):
        raise ValueError('Invalid camera rotation or focal length.')
    convention = view.get('intrinsics_format', 'ndc_norm_image_bounds')
    if convention == 'ndc_isotropic':
        scale = np.full(2, min(height, width) / 2)
    elif convention == 'ndc_norm_image_bounds':
        scale = np.array([width, height]) / 2
    else:
        raise ValueError(f'Unsupported camera convention: {convention}')
    # CO3D row vectors: X_camera = X_world @ R + T; x-left, y-up.
    flip = np.diag([-1., -1., 1.])
    world_to_camera = np.eye(4)
    world_to_camera[:3, :3] = flip @ rotation.T
    world_to_camera[:3, 3] = flip @ translation
    center = np.array([width, height]) / 2 - principal * scale
    k = np.array([[focal[0] * scale[0], 0, center[0]],
                  [0, focal[1] * scale[1], center[1]], [0, 0, 1]])
    return {'width': width, 'height': height, 'K': k.tolist(),
            'worldToCamera': world_to_camera.tolist()}
