import { readFile, writeFile } from "node:fs/promises";
import { geometryFromGLB } from "../src/io/glb.js";
import { buildCage, deform } from "../src/physics/cage.js";
import { Solver } from "../src/physics/solver.js";
const results = [];
for (const id of ["lemon", "met_tablet"]) {
  const b = await readFile(`public/assets/${id}.glb`),
    g = geometryFromGLB(
      b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength),
    ),
    c = buildCage(g.vertices, g.triangles, 8);
  for (const surface of ["floor", "ramp", "sphere"]) {
    const s = new Solver(c, { material: "rubber" });
    s.apply({ type: "surface", value: surface });
    s.apply({ type: "drop" });
    let maxPenetration = 0,
      maxInverted = 0,
      worstStepMs = 0;
    for (let i = 0; i < 360; i++) {
      const t = performance.now();
      s.step();
      worstStepMs = Math.max(worstStepMs, performance.now() - t);
      if (i % 10 === 0) {
        const p = deform(c, s.x);
        maxInverted = Math.max(maxInverted, s.diagnostics().inverted);
        for (let j = 0; j < p.length; j += 3) {
          let penetration = -p[j + 1];
          if (surface === "sphere")
            penetration = Math.max(
              penetration,
              0.5 - Math.hypot(p[j] - 0.55, p[j + 1] - 0.48, p[j + 2]),
            );
          if (surface === "ramp")
            penetration = Math.max(
              penetration,
              0.35 - (p[j] * 0.2873478856 + p[j + 1] * 0.9578262852),
            );
          maxPenetration = Math.max(maxPenetration, penetration);
        }
      }
    }
    results.push({
      id,
      surface,
      maxPenetrationMetres: maxPenetration,
      maxInverted,
      worstStepMs,
      final: s.diagnostics(),
    });
    console.log(JSON.stringify(results.at(-1)));
  }
}
await writeFile(
  "docs/evidence/contact-study.json",
  JSON.stringify(
    {
      protocol:
        "360 ticks, rubber, 8 cells, 5 iterations, drop. All visual vertices inspected every 10 ticks. Discrete surface penetration, not swept triangle collision.",
      results,
    },
    null,
    2,
  ) + "\n",
);
if (
  results.some(
    (r) => r.final.fault || r.maxInverted > 0 || r.maxPenetrationMetres > 0.025,
  )
)
  process.exitCode = 1;
