"""Pinhole geometry helpers; no dataset IO or evaluation-camera access."""
import numpy as np


def project(points, camera):
    transform = np.asarray(camera['worldToCamera'], dtype=float)
    local = np.asarray(points) @ transform[:3, :3].T + transform[:3, 3]
    projected = local @ np.asarray(camera['K'], dtype=float).T
    positive = local[:, 2] > 1e-8
    pixels = np.zeros((len(local), 2), dtype=float)
    pixels[positive] = projected[positive, :2] / projected[positive, 2, None]
    return pixels, positive


def mask_membership(points, camera, mask):
    pixels, positive = project(points, camera)
    x, y = np.rint(pixels).astype(np.int64).T
    inside = positive & (x >= 0) & (x < mask.shape[1]) & (y >= 0) & (y < mask.shape[0])
    result = np.zeros(len(points), dtype=bool)
    result[inside] = mask[y[inside], x[inside]]
    return result


def centroid_ray(camera, mask):
    y, x = np.nonzero(mask)
    if len(x) == 0:
        raise ValueError('Cannot infer a ray from an empty mask.')
    pixel = np.array([x.mean(), y.mean(), 1])
    transform = np.asarray(camera['worldToCamera'], dtype=float)
    rotation = transform[:3, :3]
    origin = -rotation.T @ transform[:3, 3]
    direction = rotation.T @ np.linalg.solve(np.asarray(camera['K']), pixel)
    return origin, direction / np.linalg.norm(direction)


def intersect_rays(rays):
    system = np.zeros((3, 3))
    right = np.zeros(3)
    for origin, direction in rays:
        normal = np.eye(3) - np.outer(direction, direction)
        system += normal
        right += normal @ origin
    if np.linalg.cond(system) > 1e6:
        raise ValueError('Input views do not constrain object depth.')
    return np.linalg.solve(system, right)


def silhouette_iou(predicted, observed):
    predicted, observed = np.asarray(predicted, bool), np.asarray(observed, bool)
    if predicted.shape != observed.shape:
        raise ValueError('Silhouette shapes differ.')
    if not observed.any():
        raise ValueError('Missing/empty observed silhouette is not a perfect match.')
    return float(np.count_nonzero(predicted & observed) / np.count_nonzero(predicted | observed))
