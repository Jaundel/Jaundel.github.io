import { readFile, mkdir, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { dirname, resolve, sep } from "node:path";

const root = resolve("public");
const manifest = JSON.parse(
  await readFile("examples-distribution.json", "utf8"),
);
const base = new URL(process.argv[2] ?? "https://jaundel.github.io/morphic/");
const sha256 = (data) => createHash("sha256").update(data).digest("hex");
for (const item of manifest.files) {
  const target = resolve(root, item.path);
  if (!target.startsWith(root + sep)) throw Error("Invalid example path.");
  const present = await readFile(target).catch(() => null);
  if (present && sha256(present) === item.sha256) continue;
  const response = await fetch(new URL(item.path, base));
  if (!response.ok)
    throw Error(`Could not download ${item.path}: ${response.status}`);
  const data = Buffer.from(await response.arrayBuffer());
  if (data.length !== item.bytes || sha256(data) !== item.sha256)
    throw Error(
      `Example changed or download incomplete: ${item.path}. Download the latest source archive.`,
    );
  await mkdir(dirname(target), { recursive: true });
  await writeFile(target, data);
  console.log(`Downloaded ${item.path}`);
}
console.log("Examples verified. Run npm run dev to open Morphic.");
