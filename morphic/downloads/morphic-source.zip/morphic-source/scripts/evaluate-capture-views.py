"""Score frozen calibrated meshes against reserved Deform360 alpha silhouettes.

Run once after reconstruction AND input-only alignment decisions are frozen.
No post-test tuning: further changes need a new, untouched evaluation capture.
The dataset masks are supplied annotations, not perfect 3D ground truth.
"""
import argparse
import importlib.util
import io
import json
import tarfile
from pathlib import Path
import numpy as np
from PIL import Image
import trimesh
from deform360_geometry import silhouette_iou

spec = importlib.util.spec_from_file_location('hull', Path(__file__).with_name('reconstruct-deform360-hull.py'))
hull = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hull)
ROOT = hull.ROOT


def main(args):
    destination = args.output.resolve()
    destination.mkdir(parents=True, exist_ok=False)
    split = json.loads((ROOT / 'split.json').read_text())
    calibration = json.loads((ROOT / 'calibration-verified.json').read_text())
    if calibration['textSha256'] != split['calibrationSha256']:
        raise ValueError('Calibration differs from frozen split.')
    methods = json.loads(args.methods.read_text())
    if not methods or len({m['name'] for m in methods}) != len(methods):
        raise ValueError('Supply distinct frozen methods.')
    meshes = {}
    for method in methods:
        path = Path(method['mesh']).resolve(strict=True)
        if hull.sha(path) != method['sha256']:
            raise ValueError('Mesh differs from frozen evaluation plan.')
        meshes[method['name']] = trimesh.load(path, force='mesh')
    plan = {'schema': 1, 'methods': methods, 'splitSha256': hull.sha(ROOT / 'split.json'),
            'calibrationSha256': hull.sha(ROOT / 'calibration-verified.json'),
            'evaluatorSha256': hull.sha(Path(__file__)),
            'rasterizerSha256': hull.sha(Path(__file__).with_name('reconstruct-deform360-hull.py')),
            'geometryHelpersSha256': hull.sha(Path(__file__).with_name('deform360_geometry.py')),
            'protocol': 'Original-size binary silhouettes, alpha > 127, all eligible test cameras; no test tuning.'}
    (destination / 'frozen-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    archive = ROOT / 'cameras.tar'
    # Validate before reading reserved observation bytes.
    import hashlib
    with archive.open('rb') as stream:
        archive_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    if archive_hash != split['archiveSha256']:
        raise ValueError('Archive differs from frozen source.')
    scores, missing = [], []
    with tarfile.open(archive, 'r:') as tar:
        names = tar.getnames()
        if len(names) != len(set(names)):
            raise ValueError('Ambiguous archive entries.')
        for camera in split['testCameras']:
            member = camera + '/segmented/000000.png'
            if member not in names:
                missing.append({'camera': camera, 'reason': 'No supplied first-frame segmented preview.'})
                continue
            observation = tar.extractfile(member).read()
            image = Image.open(io.BytesIO(observation))
            if image.mode != 'RGBA' or image.size != (1280, 720):
                raise ValueError('Unexpected evaluation observation format.')
            mask = np.asarray(image.getchannel('A')) > 127
            if not mask.any():
                missing.append({'camera': camera, 'reason': 'Empty supplied first-frame mask.'})
                continue
            record = {'camera': camera, 'observedPixels': int(mask.sum()),
                      'observationSha256': hashlib.sha256(observation).hexdigest(), 'iou': {}}
            for name, mesh in meshes.items():
                prediction = hull.render_silhouette(mesh, calibration['cameras'][camera])
                record['iou'][name] = silhouette_iou(prediction, mask)
            scores.append(record)
    if not scores:
        raise ValueError('No eligible held-out views; cannot report a score.')
    report = {'schema': 1, 'object': split['object'], 'frame': split['alignedFrameIndex'],
        'testCameraCount': len(split['testCameras']), 'eligibleCameraCount': len(scores),
        'missing': missing, 'scores': scores,
        'summary': {name: {'meanIoU': float(np.mean([r['iou'][name] for r in scores])),
                          'medianIoU': float(np.median([r['iou'][name] for r in scores]))}
                    for name in meshes},
        'limitations': ['One object/frame; cameras are correlated, not independent object trials.',
            'Supplied masks/calibration and two-view pose alignment aid both learned generators.',
            'Silhouette agreement does not establish hidden concavities, texture or physical behavior.']}
    (destination / 'scores.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'eligibleCameraCount': len(scores), 'missingCameraCount': len(missing),
                      'summary': report['summary']}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--methods', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    main(parser.parse_args())
