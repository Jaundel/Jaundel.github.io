"""Freeze method/mesh hashes, then score every reserved CO3D silhouette once.

This consumes the reserved test masks. Do not tune these methods on the scores
and present the same split as a new held-out test.
"""
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import zipfile
import numpy as np
from PIL import Image
import trimesh
from co3d_geometry import camera_from_frame
from deform360_geometry import silhouette_iou

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'work/co3d'
CASE = DATA / '190_20494_39385'
spec = importlib.util.spec_from_file_location('render', ROOT / 'scripts/reconstruct-deform360-hull.py')
renderer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(renderer)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    split_path = DATA / 'toytruck-split.json'
    split = json.loads(split_path.read_text())
    prepared = json.loads((CASE / 'evaluation-inputs/preparation.json').read_text())
    if sha(split_path) != prepared['splitSha256']:
        raise ValueError('Split changed.')
    checks = json.loads((DATA / 'checksums.json').read_text())['singlesequence']
    for path, key in [('toytruck-metadata.zip', 'toytruck_000.zip'), ('toytruck-rgb-source.zip', 'toytruck_001.zip')]:
        if sha(DATA / path) != checks[key]:
            raise ValueError('Archive checksum mismatch.')
    methods = {}
    for name, folder, report_name, output_key in [
        ('input-hull', 'input-hull', 'report.json', None),
        ('single-view', 'single-view-aligned', 'alignment.json', 'worldMeshSha256'),
        ('twelve-view', 'twelve-view-aligned', 'alignment.json', 'worldMeshSha256')]:
        path = CASE / folder / 'world-mesh.ply'
        report_path = CASE / folder / report_name
        report = json.loads(report_path.read_text())
        expected = report[output_key] if output_key else report['outputs']['world-mesh.ply']
        if sha(path) != expected or report.get('heldoutPixelsRead') is not False:
            raise ValueError('Method is changed or already used held-out observations.')
        if report['preparationSha256'] != sha(CASE / 'evaluation-inputs/preparation.json'):
            raise ValueError('Alignment inputs changed.')
        methods[name] = {'path': str(path.relative_to(ROOT)), 'sha256': sha(path),
                         'reportSha256': sha(report_path)}
    destination = CASE / 'heldout-evaluation'
    destination.mkdir(exist_ok=False)
    sources = ['co3d_geometry.py', 'deform360_geometry.py', 'reconstruct-deform360-hull.py',
               'reconstruct-co3d-hull.py', 'align-co3d-mesh.py', 'align-capture-mesh.py',
               'evaluate-co3d-views.py']
    plan = {'splitSha256': sha(split_path), 'methods': methods,
            'sourceHashes': {s: sha(ROOT / 'scripts' / s) for s in sources},
            'testFrames': split['heldout_frame_numbers'], 'maskThreshold': 127,
            'metric': 'Full-resolution binary silhouette intersection over union; no per-test alignment.',
            'alignmentAid': 'All generated meshes use the same twelve supplied INPUT masks and poses.',
            'testUse': 'Frozen before reading any test mask. This test split is spent after this run.'}
    plan_path = destination / 'frozen-plan.json'
    plan_path.write_text(json.dumps(plan, indent=2) + '\n')
    meshes = {name: trimesh.load(ROOT / m['path'], force='mesh') for name, m in methods.items()}
    with zipfile.ZipFile(DATA / 'toytruck-metadata.zip') as archive:
        frames = json.loads(gzip.decompress(archive.read('toytruck/frame_annotations.jgz')))
    frames = {f['frame_number']: f for f in frames if f['sequence_name'] == split['sequence']}
    scores, missing = [], []
    with zipfile.ZipFile(DATA / 'toytruck-rgb-source.zip') as archive:
        names = set(archive.namelist())
        for number in plan['testFrames']:
            frame = frames[number]; member = (frame.get('mask') or {}).get('path')
            if member not in names:
                missing.append({'frame': number, 'reason': 'mask absent'})
                continue
            data = archive.read(member)
            mask = np.asarray(Image.open(io.BytesIO(data)).convert('L')) > 127
            camera = camera_from_frame(frame)
            if mask.shape != (camera['height'], camera['width']) or not mask.any():
                missing.append({'frame': number, 'reason': 'empty or invalid mask'})
                continue
            row = {'frame': number, 'maskSha256': hashlib.sha256(data).hexdigest(),
                   'iou': {name: silhouette_iou(renderer.render_silhouette(mesh, camera), mask)
                           for name, mesh in meshes.items()}}
            scores.append(row)
            print(f"Scored reserved frame {number}", flush=True)
    if not scores:
        raise ValueError('No valid reserved masks.')
    summary = {name: {'meanIoU': float(np.mean([s['iou'][name] for s in scores])),
                      'medianIoU': float(np.median([s['iou'][name] for s in scores]))} for name in methods}
    report = {'frozenPlanSha256': sha(plan_path), 'summary': summary,
              'validFrames': len(scores), 'missing': missing, 'perFrame': scores,
              'limitations': ['One object, correlated frames, possible training overlap.',
                  'Supplied masks and calibration; alignment error and shape error not separated.',
                  'Silhouette agreement does not measure texture, hidden concavities, mechanics or material properties.']}
    (destination / 'scores.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
