"""Frozen comparisons on separate recordings; no fitting to test observations."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.spatial import cKDTree
from measured_graph import make_graph, rollout, score, marker_predictions, save_graph
from numpy_pickle import load_numpy_data

parser=argparse.ArgumentParser()
parser.add_argument('--final-test',action='store_true')
parser.add_argument('--output',default='docs/evidence/measured/validation-comparison.json')
args=parser.parse_args()
out=Path(args.output)
if out.exists():raise ValueError('Preserve prior evaluation evidence')
paths={'liftUniform':'work/measured-pilot-01/report.json',
       'jointUniform':'work/measured-joint-01/report.json',
       'jointRegional':'work/measured-joint-regional-01/report.json'}
models={name:json.loads(Path(p).read_text())['parameters'] for name,p in paths.items()}
models={'default':[1e-5,1e-5,1e-6,4],**models}
frozen={'preferredModel':'jointUniform','reason':'Simpler joint fit; regional capacity must show validation benefit.',
        'fitReportHashes':{n:hashlib.sha256(Path(p).read_bytes()).hexdigest() for n,p in paths.items()},
        'parameters':models,'testCases':['double_stretch_sloth'] if args.final_test else []}
out.parent.mkdir(parents=True,exist_ok=True)
out.with_suffix('.freeze.json').write_text(json.dumps(frozen,indent=2))

def kinematic(graph,radius):
    delta=graph['controller']-graph['controller'][0]
    distance2=np.sum((graph['rest'][:,None,:]-graph['controller'][0][None,:,:])**2,axis=2)
    weights=np.exp(-distance2/(2*radius*radius))
    influence=weights.max(axis=1)
    weights/=np.maximum(weights.sum(axis=1,keepdims=True),1e-30)
    return graph['rest']+np.einsum('nc,tca,n->tna',weights,delta,influence)

train=[make_graph(c) for c in ['single_lift_sloth','single_push_sloth']]
fit=minimize_scalar(lambda x:np.mean([score(g,d,kinematic(g,np.exp(x)),stride=3)**2 for g,d in train]),bounds=(np.log(.015),np.log(.5)),method='bounded')
radius=float(np.exp(fit.x))
report={'protocol':frozen,'kinematicRadiusMetres':radius,'metrics':[]}
cases=['single_lift_sloth','single_push_sloth','double_lift_sloth']
if args.final_test:cases+=['double_stretch_sloth']
for case in cases:
    graph,data=make_graph(case)
    gt=load_numpy_data(Path('work/phystwin')/case/'gt_track_3d.pkl')
    valid0=np.isfinite(gt[0]).all(axis=1)
    dd,ii=cKDTree(graph['rest']).query(gt[0,valid0],k=4)
    ww=1/np.maximum(dd,1e-5)**2;ww/=ww.sum(axis=1,keepdims=True)
    landmark_graph={**graph,'binding':ii,'weights':ww}
    trajectories={name:rollout(graph,p) for name,p in models.items()}
    trajectories['static']=np.tile(graph['rest'],(len(graph['controller']),1,1))
    trajectories['kinematic']=kinematic(graph,radius)
    for name,x in trajectories.items():
        prediction=marker_predictions(landmark_graph,gt[0,valid0],x)
        valid=np.isfinite(gt[:,valid0]).all(axis=2);valid[0]=False
        errors=np.linalg.norm(prediction-gt[:,valid0],axis=2)
        row={'case':case,'role':'test' if 'stretch' in case else 'validation' if case.startswith('double') else 'fit',
             'model':name,'filteredTrackRMSEMetres':score(graph,data,x),
             'landmarkMeanErrorMetres':float(errors[valid].mean()),'landmarkSamples':int(valid.sum())}
        report['metrics'].append(row);print(json.dumps(row),flush=True)
    if args.final_test:
        folder=Path('work/measured-evaluation')/case;folder.mkdir(parents=True,exist_ok=True)
        for name,x in trajectories.items():np.save(folder/(name+'.npy'),x)
        save_graph(folder/'asset.json',graph,models['jointUniform'],{'origin':'fitted-observations','fitCases':['single_lift_sloth','single_push_sloth'],'evaluationRole':'test' if 'stretch' in case else 'development','dataset':'PhysTwin'})
report['sourceHashes']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['scripts/measured_graph.py','scripts/evaluate-measured.py']}
out.write_text(json.dumps(report,indent=2))
