import { mkdir, writeFile, readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
const root = path.resolve("public/assets");
await mkdir(root, { recursive: true });
const manifest = [];
const headers = {
  "User-Agent": "Morphic/0.1 research workbench github.com/Jaundel/morphic",
};
async function download(url, md5) {
  const response = await fetch(url, { headers });
  if (!response.ok) throw Error(`${response.status}: ${url}`);
  const b = Buffer.from(await response.arrayBuffer());
  if (md5 && createHash("md5").update(b).digest("hex") !== md5)
    throw Error("Asset source hash mismatch");
  return b;
}
// Lossless glTF -> GLB packaging: binary positions, materials, UVs, and images unchanged.
for (const id of ["lemon", "sweet_potato"]) {
  const info = JSON.parse(
    await download(`https://api.polyhaven.com/info/${id}`),
  );
  const files = JSON.parse(
    await download(`https://api.polyhaven.com/files/${id}`),
  );
  const source = files.gltf["1k"].gltf,
    doc = JSON.parse(await download(source.url, source.md5));
  const binary = await download(
    source.include[doc.buffers[0].uri].url,
    source.include[doc.buffers[0].uri].md5,
  );
  const chunks = [binary, Buffer.alloc((4 - (binary.length % 4)) % 4)];
  let offset = chunks.reduce((s, b) => s + b.length, 0);
  for (const image of doc.images) {
    const entry = source.include[image.uri];
    if (!entry) throw Error("Missing image in source manifest");
    const bytes = await download(entry.url, entry.md5),
      padding = Buffer.alloc((4 - (bytes.length % 4)) % 4);
    image.bufferView = doc.bufferViews.length;
    image.mimeType = image.uri.endsWith(".png") ? "image/png" : "image/jpeg";
    delete image.uri;
    doc.bufferViews.push({
      buffer: 0,
      byteOffset: offset,
      byteLength: bytes.length,
    });
    chunks.push(bytes, padding);
    offset += bytes.length + padding.length;
  }
  doc.buffers = [{ byteLength: offset }];
  doc.asset.generator = "Morphic lossless packaging of Poly Haven glTF";
  const json = Buffer.from(JSON.stringify(doc)),
    jsonPad = Buffer.alloc((4 - (json.length % 4)) % 4, 32),
    jsonChunk = Buffer.concat([json, jsonPad]);
  const head = Buffer.alloc(20);
  head.writeUInt32LE(0x46546c67, 0);
  head.writeUInt32LE(2, 4);
  head.writeUInt32LE(28 + jsonChunk.length + offset, 8);
  head.writeUInt32LE(jsonChunk.length, 12);
  head.writeUInt32LE(0x4e4f534a, 16);
  const binHead = Buffer.alloc(8);
  binHead.writeUInt32LE(offset, 0);
  binHead.writeUInt32LE(0x004e4942, 4);
  const glb = Buffer.concat([head, jsonChunk, binHead, ...chunks]);
  await writeFile(path.join(root, id + ".glb"), glb);
  manifest.push({
    id,
    name: info.name,
    author: Object.keys(info.authors).join(", "),
    license: "CC0-1.0",
    source: `https://polyhaven.com/a/${id}`,
    sourceGltf: source.url,
    sourceMd5: source.md5,
    sha256: createHash("sha256").update(glb).digest("hex"),
    bytes: glb.length,
    sourceDimensionsMM: info.dimensions,
    transformation:
      "Lossless GLB packaging; 1K textures. Runtime scales longest dimension to 1.6m.",
  });
  console.log(`${id}: ${glb.length} bytes`);
}
await writeFile(
  path.join(root, "manifest.json"),
  JSON.stringify(manifest, null, 2) + "\n",
);
