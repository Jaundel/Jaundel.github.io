"""Download the pinned real-capture pilot; no GPU or account credentials required.

The archive is verified before use. Never extract its paths into the filesystem.
All-view reconstructed geometry is deliberately excluded from this download.
"""
import hashlib
from pathlib import Path
import requests

REVISION = 'e92deaf7e437e7e51ad464706ae647f522a279d9'
BASE = ('https://huggingface.co/datasets/brownu/deform360_processed/resolve/'
        f'{REVISION}/processed/057-kitchen-sponge/episode_0/')
SIZE = 529745920
SHA256 = 'eafe7ab59a271b13df6d1e210800cac6c5fb8a261c0eb9fcbe4edbc20d44721d'
ROOT = Path(__file__).resolve().parents[1] / 'work/deform360/057-kitchen-sponge'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    for remote, local in [('metadata.json', 'metadata.json'),
                          ('metric_params_refined_undistorted.txt', 'cameras.txt')]:
        response = requests.get(BASE + remote, timeout=60)
        response.raise_for_status()
        path = ROOT / local
        if path.exists() and path.read_bytes() != response.content:
            raise ValueError(f'Existing {local} differs from the pinned source.')
        path.write_bytes(response.content)
    target = ROOT / 'cameras.tar'
    if target.exists():
        if target.stat().st_size != SIZE or digest(target) != SHA256:
            raise ValueError('Existing archive does not match pinned source.')
        print('Existing archive verified.', flush=True)
        return
    partial = target.with_suffix('.partial')
    size = 0
    checksum = hashlib.sha256()
    with requests.get(BASE + 'cameras.tar?download=true', stream=True,
                      timeout=(20, 120)) as response:
        response.raise_for_status()
        with partial.open('wb') as stream:
            for chunk in response.iter_content(8 * 1024 * 1024):
                size += len(chunk)
                if size > SIZE:
                    raise ValueError('Archive exceeds the pinned size.')
                stream.write(chunk)
                checksum.update(chunk)
                print(f'Downloaded {size}/{SIZE} bytes', flush=True)
    if size != SIZE or checksum.hexdigest() != SHA256:
        raise ValueError('Archive length or SHA256 mismatch; not accepted.')
    partial.replace(target)
    print('Pinned archive verified.', flush=True)


if __name__ == '__main__':
    main()
