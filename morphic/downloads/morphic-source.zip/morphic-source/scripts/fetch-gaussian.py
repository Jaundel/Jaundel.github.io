"""Fetch a named PhysTwin first-frame appearance from the pinned public archive."""
import argparse
import hashlib
import json
from pathlib import Path
from remote_zip import open_public_archive
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('case',choices=['single_lift_sloth','double_stretch_sloth'])
args=parser.parse_args()
revision='05665bcd0edad8f069c7def9cbb58d2eb75d68d0'
folder=Path('work/gaussian')/args.case;folder.mkdir(parents=True,exist_ok=True)
remote,archive=open_public_archive('gaussian_output.zip',revision)
prefix=f'gaussian_output/{args.case}/init=hybrid_iso=True_ldepth=0.001_lnormal=0.0_laniso_0.0_lseg=1.0/'
files=[]
for name in ['cameras.json','point_cloud/iteration_10000/point_cloud.ply']:
    target=folder/Path(name).name
    if target.exists():raise ValueError('Preserve the existing download')
    data=archive.read(prefix+name);target.write_bytes(data)
    files.append({'member':prefix+name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    print(f'Fetched {name}: {len(data):,} bytes',flush=True)
(folder/'manifest.json').write_text(json.dumps({'datasetRevision':revision,'archive':'gaussian_output.zip','files':files},indent=2))
