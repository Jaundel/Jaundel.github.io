"""Fetch an explicit, reproducible subset of PhysTwin's public archive."""
import argparse
import hashlib
import json
from pathlib import Path
import requests
from remote_zip import open_public_archive

parser = argparse.ArgumentParser()
parser.add_argument("--cases", nargs="+", default=["single_lift_sloth", "single_push_sloth", "double_stretch_sloth", "single_lift_zebra", "double_stretch_zebra"])
parser.add_argument("--video", action="store_true")
args = parser.parse_args()
root = Path("work/phystwin")
root.mkdir(parents=True, exist_ok=True)
manifest_path = root / "manifest.json"
if manifest_path.exists():
    manifest = json.loads(manifest_path.read_text())
else:
    response = requests.get("https://huggingface.co/api/datasets/Jianghanxiao/PhysTwin", timeout=30)
    response.raise_for_status()
    manifest = {"source": "https://huggingface.co/datasets/Jianghanxiao/PhysTwin", "revision": response.json()["sha"], "licenseLabel": "mit", "files": {}}
remote, archive = open_public_archive(revision=manifest["revision"])
suffixes = ["metadata.json", "split.json", "calibrate.pkl", "final_data.pkl", "gt_track_3d.pkl", "shape/matching/final_mesh.glb", "color/0/0.png"]
if args.video:
    suffixes.append("color/0.mp4")
for case in args.cases:
    if not case.replace("_", "").isalnum():
        raise ValueError("Invalid case name")
    for suffix in suffixes:
        key = f"data/different_types/{case}/{suffix}"
        out = root / case / suffix
        old = manifest["files"].get(key)
        if out.exists() and old and hashlib.sha256(out.read_bytes()).hexdigest() == old["sha256"]:
            continue
        data = archive.read(key)  # zipfile validates the archive's CRC.
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        manifest["files"][key] = {"local": out.as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        manifest_path.write_text(json.dumps(manifest, indent=2))
        print(f"Fetched {case}/{suffix}: {len(data):,} bytes", flush=True)
print(f"Transferred {remote.transferred:,} bytes; pinned revision {manifest['revision']}")
