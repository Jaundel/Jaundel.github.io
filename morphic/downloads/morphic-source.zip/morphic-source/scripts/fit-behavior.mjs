import fs from "node:fs";
import crypto from "node:crypto";
import { readDataset } from "../src/behavior/dataset.js";
import {
  fitResponse,
  evaluate,
  makePhysicalAsset,
} from "../src/behavior/experiment.js";

const [input, output] = process.argv.slice(2);
if (!input || !output)
  throw Error("Usage: node scripts/fit-behavior.mjs dataset.json output.json");
if (fs.existsSync(output))
  throw Error("Output exists; choose a new path to preserve the earlier fit.");
const bytes = fs.readFileSync(input),
  data = JSON.parse(bytes);
const { cage, fit, test, settings } = readDataset(data);
const uniform = fitResponse(cage, settings, fit, data.initial, { rounds: 13 });
const regional = fitResponse(cage, settings, fit, uniform.field, {
  regional: true,
  rounds: 16,
});
const provenance = {
  kind: `fitted-to-${data.origin}-observations`,
  ...data.provenance,
  inputSha256: crypto.createHash("sha256").update(bytes).digest("hex"),
  fittingTrials: fit.map((t) => t.id),
};
const result = {
  uniform: makePhysicalAsset(cage, settings, uniform, provenance),
  regional: makePhysicalAsset(cage, settings, regional, provenance),
  fitting: { uniform, regional },
  heldout: test.map((t) => ({
    id: t.id,
    preset: evaluate(cage, settings, data.initial, t),
    uniform: evaluate(cage, settings, uniform.field, t),
    regional: evaluate(cage, settings, regional.field, t),
  })),
};
fs.writeFileSync(output, JSON.stringify(result, null, 2));
console.log(JSON.stringify(result.heldout, null, 2));
