import { createWriteStream } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { pipeline } from "node:stream/promises";
import { Transform } from "node:stream";

// Opt-in local authoring helper. No endpoint is included in a deployed build.
export function localArtifacts() {
  const enabled = process.env.MORPHIC_LOCAL_ARTIFACTS === "1";
  function configure(server) {
    if (!enabled) return;
    server.middlewares.use("/__morphic_artifacts", async (req, res) => {
      const host = req.headers.host;
      const local = /^(127\.0\.0\.1|localhost):\d+$/.test(host ?? "");
      const sameOrigin =
        !req.headers.origin || req.headers.origin === `http://${host}`;
      res.setHeader("Content-Type", "application/json");
      if (!local || !sameOrigin) {
        res.writeHead(403).end("{}");
        return;
      }
      if (req.method === "GET") {
        res.end('{"enabled":true}');
        return;
      }
      const name = req.headers["x-artifact-name"];
      if (
        req.method !== "POST" ||
        !/^[a-z0-9_.-]{1,100}\.(webm|json|glb|png)$/.test(name ?? "") ||
        name.includes("..")
      ) {
        res.writeHead(400).end("{}");
        return;
      }
      const folder = resolve("work/video-exports");
      const file = `${Date.now()}-${name}`;
      let bytes = 0;
      const limit = new Transform({
        transform(chunk, _encoding, callback) {
          bytes += chunk.length;
          callback(
            bytes > 100 * 1024 * 1024
              ? new Error("Video exceeds 100 MB")
              : null,
            chunk,
          );
        },
      });
      try {
        await mkdir(folder, { recursive: true });
        await pipeline(
          req,
          limit,
          createWriteStream(resolve(folder, file), { flags: "wx" }),
        );
        const metadata = JSON.parse(req.headers["x-artifact-metadata"] ?? "{}");
        await writeFile(
          resolve(folder, file + ".metadata.json"),
          JSON.stringify(metadata, null, 2),
          { flag: "wx" },
        );
        res.end(JSON.stringify({ path: `work/video-exports/${file}`, bytes }));
      } catch (error) {
        res.writeHead(500).end(JSON.stringify({ error: error.message }));
      }
    });
  }
  return {
    name: "morphic-local-artifacts",
    configureServer: configure,
    configurePreviewServer: configure,
  };
}
