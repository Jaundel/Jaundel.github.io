import { readFileSync } from "node:fs";
import { MeasuredGraphSolver } from "../src/physics/measured-graph.js";
const asset = JSON.parse(readFileSync(0, "utf8"));
const solver = new MeasuredGraphSolver(asset),
  trajectory = new Float64Array(asset.controller.length * solver.rest.length),
  times = [];
trajectory.set(solver.rest);
for (let frame = 1; frame < asset.controller.length; frame++) {
  const start = performance.now();
  for (let sub = 0; sub < asset.settings.substeps; sub++) solver.stepRecorded();
  times.push(performance.now() - start);
  trajectory.set(
    solver.x.subarray(0, solver.n * 3),
    frame * solver.rest.length,
  );
}
const warm = times.slice(10).sort((a, b) => a - b);
process.stderr.write(
  JSON.stringify({
    frames: asset.controller.length,
    medianMillisecondsPerRecordedFrame: warm[Math.floor(warm.length * 0.5)],
    p95MillisecondsPerRecordedFrame: warm[Math.floor(warm.length * 0.95)],
    scope: "Node.js CPU simulation only; excludes rendering and encoding",
  }),
);
process.stdout.write(Buffer.from(trajectory.buffer));
