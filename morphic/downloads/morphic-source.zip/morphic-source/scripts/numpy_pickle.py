"""Read upstream data-only NumPy pickles without permitting arbitrary globals."""
import pickle
import numpy as np


class NumpyDataUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        allowed = {
            ("numpy", "ndarray"): np.ndarray,
            ("numpy", "dtype"): np.dtype,
            ("numpy.core.multiarray", "_reconstruct"): np._core.multiarray._reconstruct,
            ("numpy._core.multiarray", "_reconstruct"): np._core.multiarray._reconstruct,
            ("numpy.core.multiarray", "scalar"): np._core.multiarray.scalar,
            ("numpy._core.multiarray", "scalar"): np._core.multiarray.scalar,
        }
        if (module, name) not in allowed:
            raise pickle.UnpicklingError(f"Data pickle requested unsupported global {module}.{name}")
        return allowed[module, name]


def load_numpy_data(path):
    with open(path, "rb") as source:
        return NumpyDataUnpickler(source).load()
