"""Package the frozen CO3D input interval without reading held-out pixels.

Requires the verified archives and toytruck-split.json in work/co3d.
Output is a derived video of real captured frames, not the native camera video.
"""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

import imageio_ffmpeg


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    root = Path(__file__).resolve().parents[1] / 'work/co3d'
    plan = json.loads((root / 'toytruck-split.json').read_text())
    checks = json.loads((root / 'checksums.json').read_text())['singlesequence']
    metadata = root / 'toytruck-metadata.zip'
    archive = root / 'toytruck-rgb-source.zip'
    assert sha(metadata) == checks['toytruck_000.zip']
    assert sha(archive) == checks['toytruck_001.zip'] == plan['archive_sha256']
    inputs, withheld = plan['input_frame_numbers'], plan['heldout_frame_numbers']
    assert inputs and not set(inputs).intersection(withheld)
    assert inputs == list(range(inputs[0], inputs[-1] + 1))
    with zipfile.ZipFile(metadata) as source:
        frames = json.loads(gzip.decompress(source.read('toytruck/frame_annotations.jgz')))
    frames = sorted((f for f in frames if f['sequence_name'] == plan['sequence']
                     and f['frame_number'] in inputs), key=lambda f: f['frame_number'])
    assert [f['frame_number'] for f in frames] == inputs
    dt = (frames[-1]['frame_timestamp'] - frames[0]['frame_timestamp']) / (len(frames) - 1)
    assert dt > 0
    assert all(abs((b['frame_timestamp'] - a['frame_timestamp']) - dt) < 1e-5
               for a, b in zip(frames, frames[1:]))
    folder = root / plan['sequence']
    rgb = folder / 'input-rgb'
    rgb.mkdir(parents=True, exist_ok=True)
    provenance = []
    with zipfile.ZipFile(archive) as source:
        for frame in frames:
            member = frame['image']['path']
            target = rgb / f"frame{frame['frame_number']:06d}.jpg"
            data = source.read(member)
            target.write_bytes(data)
            provenance.append({'frame': frame['frame_number'],
                               'timestamp': frame['frame_timestamp'], 'member': member,
                               'sha256': hashlib.sha256(data).hexdigest()})
    video = folder / 'toytruck-real-capture-reencoded.mp4'
    subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), '-v', 'error', '-y',
                    '-framerate', str(1 / dt), '-start_number', str(inputs[0]),
                    '-i', str(rgb / 'frame%06d.jpg'), '-frames:v', str(len(inputs)),
                    '-vf', 'pad=ceil(iw/2)*2:ceil(ih/2)*2', '-c:v', 'libx264',
                    '-crf', '18', '-pix_fmt', 'yuv420p', '-an',
                    '-movflags', '+faststart', str(video)], check=True)
    manifest = {'source': plan, 'splitSha256': sha(root / 'toytruck-split.json'),
                'frames': provenance, 'fps': 1 / dt, 'durationSeconds': len(inputs) * dt,
                'encoding': 'H.264, CRF 18; pad odd dimension by at most one pixel',
                'video': {'name': video.name, 'sha256': sha(video), 'bytes': video.stat().st_size},
                'evaluation': 'Not evaluated. No held-out images, masks, depth or point cloud read.'}
    (folder / 'capture-provenance.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({k: manifest[k] for k in ('fps', 'durationSeconds', 'video')}, indent=2))


if __name__ == '__main__':
    main()
