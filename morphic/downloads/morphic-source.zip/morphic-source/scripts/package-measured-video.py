"""Create article media from explicitly selected, verified browser exports."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import imageio.v2 as imageio
import imageio_ffmpeg
import numpy as np
from PIL import Image, ImageDraw, ImageFont

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--gaussian',required=True)
parser.add_argument('--mesh',required=True)
parser.add_argument('--edited')
parser.add_argument('--stretch')
args=parser.parse_args()
folder=Path('public/media/measured');folder.mkdir(parents=True,exist_ok=True)
ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
manifest={'inputs':{},'outputs':{},'encoding':'30 fps; original 85 frames; no temporal interpolation'}
for name,source in [('sloth-gaussian-camera',args.gaussian),('sloth-mesh-camera',args.mesh),('sloth-edited-camera',args.edited)]:
    if not source:continue
    path=Path(source);reader=imageio.get_reader(path);meta=reader.get_meta_data();count=reader.count_frames();reader.close()
    assert count==85 and meta['fps']==30 and meta['size']==(1280,720),(source,meta,count)
    target=folder/(name+'.mp4')
    subprocess.run([ffmpeg,'-v','error','-y','-i',str(path),'-c:v','libx264','-crf','19','-pix_fmt','yuv420p','-an','-movflags','+faststart',str(target)],check=True)
    manifest['inputs'][name]={'path':path.as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'frames':count,'fps':30,'size':[1280,720]}

source=imageio.get_reader('work/phystwin/single_lift_sloth/color/0.mp4')
prediction=imageio.get_reader(folder/'sloth-gaussian-camera.mp4')
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',21)
writer=imageio.get_writer(folder/'sloth-response.mp4',fps=30,codec='libx264',quality=8,macro_block_size=1,ffmpeg_params=['-movflags','+faststart'])
for f in range(85):
    # Same calibrated image plane. Scale source 1.5x and pad four pixels each side.
    input_frame=Image.new('RGB',(1280,720),'white')
    input_frame.paste(Image.fromarray(source.get_data(f)).resize((1272,720),Image.Resampling.LANCZOS),(4,0))
    output_frame=Image.fromarray(prediction.get_data(f))
    canvas=Image.new('RGB',(1200,686),'white');draw=ImageDraw.Draw(canvas)
    for left,frame,title in [(0,input_frame,'Observed lift'),(600,output_frame,'Fitted response')]:
        canvas.paste(frame.crop((430,0,1030,640)),(left,42));draw.text((left+22,10),title,font=font,fill='#222222')
    writer.append_data(np.asarray(canvas))
    if f==42:canvas.save(folder/'sloth-response.jpg',quality=95)
writer.close();source.close();prediction.close()

def paired_video(inputs, titles, output, crop, frames, source_scaled=False):
    readers=[imageio.get_reader(p) for p in inputs]
    w,h=crop[2]-crop[0],crop[3]-crop[1]
    writer=imageio.get_writer(folder/(output+'.mp4'),fps=30,codec='libx264',quality=8,macro_block_size=1,ffmpeg_params=['-movflags','+faststart'])
    for f in range(frames):
        canvas=Image.new('RGB',(w*2,h+46),'white');draw=ImageDraw.Draw(canvas)
        for panel,(reader,title) in enumerate(zip(readers,titles)):
            image=Image.fromarray(reader.get_data(f))
            if source_scaled and panel==0:
                scaled=Image.new('RGB',(1280,720),'white');scaled.paste(image.resize((1272,720),Image.Resampling.LANCZOS),(4,0));image=scaled
            canvas.paste(image.crop(crop),(panel*w,42));draw.text((panel*w+16,10),title,font=font,fill='#222222')
        writer.append_data(np.asarray(canvas))
        if f==frames//2:canvas.save(folder/(output+'.jpg'),quality=95)
    writer.close()
    for reader in readers:reader.close()

if args.edited:
    paired_video([folder/'sloth-gaussian-camera.mp4',folder/'sloth-edited-camera.mp4'],['Fitted response','Lower-X half: 3.98x compliance'],'sloth-material-edit',(430,0,1030,640),85)
    manifest['edit']={'region':'initial world-X lower half','complianceMultiplier':10**.6,'loading':'identical recorded lift; hypothetical material change'}
if args.stretch:
    path=Path(args.stretch);reader=imageio.get_reader(path);meta=reader.get_meta_data();count=reader.count_frames();reader.close()
    assert count==192 and meta['fps']==30 and meta['size']==(1280,720)
    manifest['inputs']['stretch']={'path':path.as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'frames':count,'fps':30,'size':[1280,720],
                                 'renderMetadata':json.loads(Path(str(path)+'.metadata.json').read_text())}
    paired_video(['work/phystwin/double_stretch_sloth/color/0.mp4',path],['Observed stretch / test','Prediction / fitted on lift + push'],'sloth-stretch-response',(360,0,1004,606),192,source_scaled=True)

# Looping article comparisons retain the three synchronized evidence panels while
# making the recording selector the only control in that figure.
for case in (
    'single_lift_sloth',
    'single_push_sloth',
    'double_lift_sloth',
    'double_stretch_sloth',
):
    subprocess.run([
        ffmpeg, '-v', 'error', '-y', '-i', str(folder/(case+'-landmarks.mp4')),
        '-filter_complex',
        '[0:v]fps=12,scale=1040:-2:flags=lanczos,split[a][b];'
        '[a]palettegen=max_colors=128:stats_mode=diff[p];'
        '[b][p]paletteuse=dither=bayer:bayer_scale=3:diff_mode=rectangle',
        '-loop', '0', str(folder/(case+'-landmarks.gif')),
    ], check=True)

for name in ('sloth-response', 'sloth-stretch-response', 'sloth-material-edit'):
    subprocess.run([
        ffmpeg, '-v', 'error', '-y', '-i', str(folder/(name+'.mp4')),
        '-filter_complex',
        '[0:v]fps=12,scale=1040:-2:flags=lanczos,split[a][b];'
        '[a]palettegen=max_colors=128:stats_mode=diff[p];'
        '[b][p]paletteuse=dither=bayer:bayer_scale=3:diff_mode=rectangle',
        '-loop', '0', str(folder/(name+'.gif')),
    ], check=True)

appearance_filter = (
    '[0:v]scale=1040:-2:flags=lanczos[m];'
    '[1:v]scale=1040:-2:flags=lanczos[g];'
    '[m][g]hstack=inputs=2,fps=12,split[a][b];'
    '[a]palettegen=max_colors=128:stats_mode=diff[p];'
    '[b][p]paletteuse=dither=bayer:bayer_scale=3:diff_mode=rectangle'
)
subprocess.run([
    ffmpeg, '-v', 'error', '-y',
    '-i', str(folder/'sloth-mesh-camera.mp4'),
    '-i', str(folder/'sloth-gaussian-camera.mp4'),
    '-filter_complex', appearance_filter,
    '-loop', '0', str(folder/'sloth-appearance-comparison.gif'),
], check=True)
subprocess.run([
    ffmpeg, '-v', 'error', '-y',
    '-ss', '1.4', '-i', str(folder/'sloth-mesh-camera.mp4'),
    '-ss', '1.4', '-i', str(folder/'sloth-gaussian-camera.mp4'),
    '-filter_complex',
    '[0:v]scale=1040:-2:flags=lanczos[m];'
    '[1:v]scale=1040:-2:flags=lanczos[g];[m][g]hstack=inputs=2',
    '-frames:v', '1', str(folder/'sloth-appearance-comparison.jpg'),
], check=True)

# A small forward-playing excerpt of the actual simulation, suitable for a project card.
subprocess.run([ffmpeg,'-v','error','-y','-i',str(folder/'sloth-gaussian-camera.mp4'),'-filter_complex',
    '[0:v]crop=720:720:400:0,fps=15,scale=360:360:flags=lanczos,split[a][b];[a]palettegen=max_colors=128[p];[b][p]paletteuse=dither=bayer:bayer_scale=3',
    '-loop','0',str(folder/'morphic-thumbnail.gif')],check=True)
for path in folder.glob('*'):
    if path.suffix not in {'.mp4','.jpg','.gif'}:continue
    manifest['outputs'][path.name]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}
manifest['sourceVideoSHA256']=hashlib.sha256(Path('work/phystwin/single_lift_sloth/color/0.mp4').read_bytes()).hexdigest()
manifest['scriptSHA256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
Path('docs/evidence/measured/presentation-media.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest['inputs'],indent=2))
