"""Build an explicit source distribution, without working data or credentials."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FILES = [
    'README.md', 'LICENSE', 'THIRD_PARTY_NOTICES.md', 'package.json',
    'package-lock.json', 'vite.config.js', 'index.html', 'article.html',
    'guide.html', 'synthetic.html', 'requirements-research.txt', '.gitignore',
]
DIRECTORIES = ['src', 'scripts', 'tests', 'docs']
EXCLUDED = {'AGENTS.md', 'EXECUTION_STATE.md', 'CLAUDE.md', 'GEMINI.md', 'SKILL.md', 'RUNPOD_PILOT.md'}

def allowed(path):
    return (path.name not in EXCLUDED and '__pycache__' not in path.parts
            and not path.name.endswith(('.pyc', '.log', '.morphic.json')))

def main():
    public = ROOT / 'public'
    assets = []
    for path in sorted(public.rglob('*')):
        if not path.is_file() or 'downloads' in path.relative_to(public).parts:
            continue
        data = path.read_bytes()
        assets.append({'path': path.relative_to(public).as_posix(),
                       'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    manifest = ROOT / 'examples-distribution.json'
    manifest.write_text(json.dumps({'schema': 1, 'files': assets}, indent=2) + '\n', encoding='utf-8')
    selected = [ROOT / name for name in FILES] + [manifest]
    for directory in DIRECTORIES:
        selected.extend(path for path in (ROOT / directory).rglob('*') if path.is_file() and allowed(path))
    output = public / 'downloads/morphic-source.zip'
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(selected):
            archive.write(path, 'morphic-source/' + path.relative_to(ROOT).as_posix())
    print(json.dumps({'archive': str(output), 'sourceFiles': len(selected),
                      'archiveBytes': output.stat().st_size,
                      'exampleFiles': len(assets), 'exampleBytes': sum(a['bytes'] for a in assets)}))

if __name__ == '__main__':
    main()
