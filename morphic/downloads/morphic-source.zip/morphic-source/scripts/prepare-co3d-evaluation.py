"""Match submitted input frames and prepare INPUT-ONLY evaluation aids.

Supplied masks and calibration are alignment aids, not reconstruction inputs.
Does not read reserved image/mask/depth/point-cloud contents.
"""
import gzip
import hashlib
import io
import json
from pathlib import Path
import zipfile
import cv2
import numpy as np
from PIL import Image
from co3d_geometry import camera_from_frame
from deform360_geometry import project

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'work/co3d'
JOB = ROOT / 'work/reconstruction-jobs/50a254ac-8fc8-454a-b4e9-36f0a1c01dcb'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    split = json.loads((DATA / 'toytruck-split.json').read_text())
    checks = json.loads((DATA / 'checksums.json').read_text())['singlesequence']
    for path, key in [('toytruck-metadata.zip', 'toytruck_000.zip'),
                      ('toytruck-rgb-source.zip', 'toytruck_001.zip')]:
        if sha(DATA / path) != checks[key]:
            raise ValueError('Source archive checksum mismatch.')
    folder = DATA / split['sequence']
    provenance = json.loads((folder / 'capture-provenance.json').read_text())
    video = folder / provenance['video']['name']
    if sha(video) != provenance['video']['sha256'] or sha(DATA / 'toytruck-split.json') != provenance['splitSha256']:
        raise ValueError('Video or split changed.')
    numbers = [f['frame'] for f in provenance['frames']]
    if numbers != split['input_frame_numbers'] or set(numbers) & set(split['heldout_frame_numbers']):
        raise ValueError('Input interval is inconsistent.')
    capture = cv2.VideoCapture(str(video))
    decoded = []
    while True:
        ok, frame = capture.read()
        if not ok:
            break
        decoded.append(cv2.resize(frame, (192, 108), interpolation=cv2.INTER_AREA).astype(np.float32))
    capture.release()
    if len(decoded) != len(numbers):
        raise ValueError('Decoded frame count differs from input provenance.')
    decoded = np.stack(decoded)
    with zipfile.ZipFile(DATA / 'toytruck-metadata.zip') as archive:
        annotations = json.loads(gzip.decompress(archive.read('toytruck/frame_annotations.jgz')))
    frames = {f['frame_number']: f for f in annotations if f['sequence_name'] == split['sequence']}
    result = json.loads((JOB / 'result.json').read_text())
    matches = []
    for i, record in enumerate(result['inputs']):
        path = JOB / f'view-{i}.png'
        if sha(path) != record['sha256']:
            raise ValueError('Submitted input hash mismatch.')
        sample = cv2.resize(cv2.imread(str(path)), (192, 108), interpolation=cv2.INTER_AREA).astype(np.float32)
        errors = np.mean((decoded - sample) ** 2, axis=(1, 2, 3))
        order = np.argsort(errors)
        # Timing supplies an independent expected frame; appearance must agree.
        expected = min(len(numbers) - 1, int(len(numbers) * (i + .5) / 12))
        if order[0] != expected or errors[order[1]] <= 2 * errors[order[0]]:
            raise ValueError('Ambiguous browser frame match; do not guess a pose.')
        matches.append({'view': i, 'frame': numbers[order[0]], 'inputSha256': sha(path),
                        'matchMSE': float(errors[order[0]]), 'nextBestMSE': float(errors[order[1]])})
    if len(matches) != 12 or len({m['frame'] for m in matches}) != 12:
        raise ValueError('Expected twelve distinct submitted frames.')
    destination = folder / 'evaluation-inputs'
    destination.mkdir(exist_ok=False)
    with zipfile.ZipFile(DATA / 'toytruck-rgb-source.zip') as archive:
        for match in matches:
            frame = frames[match['frame']]
            camera = camera_from_frame(frame)
            member = frame['mask']['path']
            data = archive.read(member)
            mask = np.asarray(Image.open(io.BytesIO(data)).convert('L')) > 127
            if mask.shape != (camera['height'], camera['width']) or not mask.any():
                raise ValueError('Invalid input alignment mask.')
            name = f"frame{match['frame']:06d}-mask.png"
            Image.fromarray(mask.astype(np.uint8) * 255).save(destination / name)
            match.update(camera=camera, mask=name, maskSha256=sha(destination / name),
                         sourceMaskMember=member, sourceMaskSha256=hashlib.sha256(data).hexdigest())
    # Cross-check matrix conversion against the documented NDC formula for all
    # metadata cameras. This reads no held-out observations and is not a claim
    # about dataset calibration quality.
    error = 0.
    for frame in frames.values():
        v = frame['viewpoint']; c = camera_from_frame(frame)
        local = np.random.default_rng(frame['frame_number']).uniform(-.5, .5, (100, 3))
        local[:, 2] += 2
        world = (local - v['T']) @ np.asarray(v['R']).T
        actual, valid = project(world, c)
        scale = (np.full(2, min(c['height'], c['width']) / 2)
                 if v['intrinsics_format'] == 'ndc_isotropic' else np.array([c['width'], c['height']]) / 2)
        expected = np.array([c['width'], c['height']]) / 2 - (
            local[:, :2] / local[:, 2:] * v['focal_length'] + v['principal_point']) * scale
        if not valid.all():
            raise ValueError('Converted positive depths became negative.')
        error = max(error, float(np.max(np.abs(actual - expected))))
    if error > 1e-3:
        raise ValueError('Camera conversion disagrees with direct NDC projection.')
    report = {'sequence': split['sequence'], 'splitSha256': sha(DATA / 'toytruck-split.json'),
              'videoSha256': sha(video), 'jobReportSha256': sha(JOB / 'result.json'),
              'cameraSourceSha256': sha(ROOT / 'scripts/co3d_geometry.py'),
              'cameraCount': len(frames), 'maxProjectionDifferencePixels': error,
              'inputs': matches, 'heldoutFrames': split['heldout_frame_numbers'],
              'role': 'Supplied input masks and calibration for evaluation alignment only. Neither generator received these aids.',
              'heldoutPixelsRead': False}
    (destination / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'inputFrames': [m['frame'] for m in matches],
                      'cameraCount': len(frames), 'projectionDifferencePixels': error,
                      'heldoutPixelsRead': False}, indent=2))


if __name__ == '__main__':
    main()
