"""Prepare twelve unmasked photos from a new CO3D category, reserving its tail.

Uses the locally retained official link/checksum manifests. Selection is frozen
from metadata before extracting RGB. Supplied masks/depth/point clouds are unused.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import zipfile
import requests

ROOT = Path(__file__).resolve().parents[1] / 'work/co3d'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def fetch(url, path, expected):
    if not path.exists():
        response = requests.get(url, stream=True, timeout=(20, 60))
        response.raise_for_status()
        size = 0
        pending = path.with_suffix('.partial')
        with pending.open('wb') as stream:
            for chunk in response.iter_content(1024 * 1024):
                size += len(chunk)
                if size > 500_000_000:
                    raise ValueError('Archive exceeds the 500 MB preparation limit.')
                stream.write(chunk)
        if sha(pending) != expected:
            raise ValueError('Official archive checksum mismatch.')
        pending.replace(path)
    if sha(path) != expected:
        raise ValueError('Retained archive checksum mismatch.')


def main(category):
    links = json.loads((ROOT / 'links.json').read_text())['singlesequence'][category]
    checks = json.loads((ROOT / 'checksums.json').read_text())['singlesequence']
    if len(links) != 2 or not category.isalnum():
        raise ValueError('Expected a category with one metadata and one data archive.')
    folder = ROOT / category
    folder.mkdir(exist_ok=True)
    metadata, data = folder / 'metadata.zip', folder / 'data.zip'
    fetch(links[0], metadata, checks[f'{category}_000.zip'])
    with zipfile.ZipFile(metadata) as archive:
        frames = json.loads(gzip.decompress(archive.read(f'{category}/frame_annotations.jgz')))
        sequences = json.loads(gzip.decompress(archive.read(f'{category}/sequence_annotations.jgz')))
        (folder / 'LICENSE.txt').write_bytes(archive.read(f'{category}/LICENSE'))
    sequence = sorted(s['sequence_name'] for s in sequences)[0]
    frames = sorted((f for f in frames if f['sequence_name'] == sequence), key=lambda f: f['frame_number'])
    boundary = int(len(frames) * .7)
    if boundary < 12 or len(frames) - boundary < 1:
        raise ValueError('Too few frames for the fixed split.')
    selected = [frames[int((boundary - 1) * i / 11)] for i in range(12)]
    plan = {'dataset': 'CO3D v2', 'category': category, 'sequence': sequence,
            'repositoryRevision': 'eb51d7583c56ff23dc918d9deafee50f4d8178c3',
            'selection': 'Lexicographically first sequence; 12 evenly spaced photos from first70 percent, chosen before RGB inspection.',
            'inputFrameNumbers': [f['frame_number'] for f in selected],
            'reservedFrameNumbers': [f['frame_number'] for f in frames[boundary:]],
            'unusedInputIntervalFrames': [f['frame_number'] for f in frames[:boundary] if f not in selected],
            'metadataSha256': sha(metadata), 'dataSha256': checks[f'{category}_001.zip'],
            'license': 'CC-BY-NC-4.0', 'inputType': 'Unmasked RGB photographs; supplied masks, depth and point cloud unused.'}
    plan_path = folder / 'split.json'
    if plan_path.exists():
        if json.loads(plan_path.read_text()) != plan:
            raise ValueError('Refusing to change an existing frozen split.')
    else:
        plan_path.write_text(json.dumps(plan, indent=2) + '\n')
    print(f"Frozen {category}/{sequence}: 12 photos, {len(plan['reservedFrameNumbers'])} reserved frames.", flush=True)
    fetch(links[1], data, plan['dataSha256'])
    inputs = folder / 'inputs'; inputs.mkdir(exist_ok=True)
    records = []
    with zipfile.ZipFile(data) as archive:
        for frame in selected:
            path = inputs / f"frame{frame['frame_number']:06d}.jpg"
            path.write_bytes(archive.read(frame['image']['path']))
            records.append({'frame': frame['frame_number'], 'timestamp': frame['frame_timestamp'],
                            'member': frame['image']['path'], 'name': path.name, 'sha256': sha(path)})
    (folder / 'preparation.json').write_text(json.dumps({'splitSha256': sha(plan_path), 'inputs': records,
                                                       'heldoutPixelsRead': False}, indent=2) + '\n')
    print('Verified archive; extracted only the twelve selected RGB photos.', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('category')
    main(parser.parse_args().category)
