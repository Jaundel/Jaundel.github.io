"""Freeze camera partitions before image inspection; export only reconstruction inputs.

First aligned frame, not metadata.start_frame (a later interaction window).
Uses supplied per-camera segmentation, not Morphic's automatic segmentation.
The other cameras stay in the verified archive until an evaluator reads them.
"""
import hashlib
import importlib.util
import io
import json
import tarfile
from pathlib import Path
from PIL import Image

spec = importlib.util.spec_from_file_location('fetch', Path(__file__).with_name('fetch-deform360-pilot.py'))
fetch = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fetch)


def seal(path, document):
    value = json.dumps(document, indent=2, sort_keys=True) + '\n'
    if path.exists():
        if path.read_text(encoding='utf-8') != value:
            raise ValueError(f'Refusing to change existing evidence: {path}')
    else:
        path.write_text(value, encoding='utf-8')


def main():
    root = fetch.ROOT
    archive = root / 'cameras.tar'
    if archive.stat().st_size != fetch.SIZE or fetch.digest(archive) != fetch.SHA256:
        raise ValueError('Run fetch-deform360-pilot.py; archive is not verified.')
    metadata = json.loads((root / 'metadata.json').read_text())
    cameras = sorted(metadata['cameras'])
    if len(cameras) != 32 or len(set(cameras)) != 32:
        raise ValueError('Unexpected camera roster for pinned pilot.')
    inputs = [cameras[i] for i in (0, 10, 21)]
    validation = [cameras[i] for i in (5, 16, 26)]
    heldout = [c for c in cameras if c not in inputs + validation]
    split = {
        'schema': 1, 'dataset': 'brownu/deform360_processed',
        'revision': fetch.REVISION, 'object': '057-kitchen-sponge', 'episode': 0,
        'alignedFrameIndex': 0, 'archiveSha256': fetch.SHA256,
        'selection': 'Fixed sorted-camera indices before image inspection; not optimized for coverage.',
        'inputCameras': inputs, 'validationCameras': validation, 'testCameras': heldout,
        'inputSegmentation': 'Supplied dataset masks; automated user-capture segmentation is a separate test.',
        'excluded': ['all-view point clouds', 'Gaussian splats', 'rendered depth', 'tracking'],
        'metadataSha256': fetch.digest(root / 'metadata.json'),
        'calibrationSha256': fetch.digest(root / 'cameras.txt'),
        'status': 'Prepared inputs only; no reconstruction or accuracy result.'
    }
    seal(root / 'split.json', split)  # Written BEFORE reading any image bytes.
    output = root / 'inputs'
    output.mkdir(exist_ok=True)
    report = {'splitSha256': fetch.digest(root / 'split.json'), 'inputs': [], 'unavailableInputs': []}
    with tarfile.open(archive, 'r:') as tar:
        names = [m.name for m in tar.getmembers()]
        if len(names) != len(set(names)):
            raise ValueError('Archive has ambiguous duplicate entries.')
        for camera in inputs:
            image_member = camera + '/segmented/000000.png'
            if image_member not in names:
                report['unavailableInputs'].append({'camera': camera,
                    'reason': 'Supplied segmented preview absent; camera not replaced from evaluation partitions.'})
                continue
            member = tar.getmember(image_member)
            if not member.isfile() or member.size > 10 * 1024 * 1024:
                raise ValueError('Unexpected image member.')
            data = tar.extractfile(member).read()
            image = Image.open(io.BytesIO(data))
            if image.size != (1280, 720) or image.mode != 'RGBA':
                raise ValueError('Unexpected first-frame image format.')
            image.load()
            alpha = image.getchannel('A')
            bbox = alpha.getbbox()
            if bbox is None or alpha.getextrema() != (0, 255):
                raise ValueError('Empty or invalid supplied mask.')
            destination = output / (camera + '.png')
            if destination.exists() and destination.read_bytes() != data:
                raise ValueError('Existing input differs from the archive.')
            destination.write_bytes(data)
            timestamps = tar.extractfile(camera + '/aligned_timestamps.txt').read().decode().splitlines()
            report['inputs'].append({'camera': camera, 'member': member.name,
                'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
                'alphaBoundingBox': bbox, 'firstTimestampLine': timestamps[0],
                'timestampLineCount': len(timestamps)})
    seal(root / 'preparation.json', report)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
