"""Prepare an attributed SH0/isotropic appearance comparison, with fixed binding."""
from pathlib import Path
import argparse
import json
import hashlib
import numpy as np
from scipy.spatial import cKDTree

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--case',default='single_lift_sloth')
parser.add_argument('--source',default='work/gaussian-pilot/point_cloud.ply')
args=parser.parse_args()
source=Path(args.source)
data=source.read_bytes(); offset=data.index(b'end_header\n')+11
header=data[:offset].decode('ascii')
properties=[line.split()[-1] for line in header.splitlines() if line.startswith('property float')]
a=np.frombuffer(data,dtype='<f4',offset=offset).reshape(-1,len(properties))
columns={p:a[:,i] for i,p in enumerate(properties)}
sigma=np.exp(columns['scale_0'])
opacity=1/(1+np.exp(-columns['opacity']))
mask=(opacity>=.015)&(sigma>=.00004)
points=a[mask,:3].astype(float)
rest=np.asarray(json.loads((Path('public/measured')/args.case/'asset.json').read_text())['rest'])
dist,indices=cKDTree(rest).query(points,k=4)
weights=1/np.maximum(dist,1e-5)**2; weights/=weights.sum(axis=1,keepdims=True)
rgb=np.clip(.5+.28209479177387814*np.stack([columns['f_dc_'+str(i)][mask] for i in range(3)],axis=1),0,1)
packed=np.concatenate([points,sigma[mask,None],rgb,opacity[mask,None],indices,weights],axis=1).astype('<f4')
out=Path('public/measured')/args.case;(out/'gaussians.bin').write_bytes(packed.tobytes())
report={'source':'PhysTwin pretrained appearance; not trained by Morphic','sourceSHA256':hashlib.sha256(data).hexdigest(),
        'sourceCount':len(a),'count':len(packed),'columns':'xyz, sigma, rgb, opacity, 4 node indices, 4 weights',
        'approximation':'SH0 only; original isotropic covariance. Alpha < .015 and sigma < .04 mm removed.',
        'binding':'4 nearest nodes, inverse squared rest distance; identical displacement rule to mesh/track interpolation',
        'bytes':packed.nbytes,'sha256':hashlib.sha256(packed.tobytes()).hexdigest()}
(out/'gaussians.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
