"""Package frozen response assets and camera-aligned landmark comparisons.

This script never fits parameters. Videos use the publisher's frame order, camera,
and 30 fps clock. Crops depend on the initial geometry and prescribed hand loading.
"""
from pathlib import Path
import hashlib
import json
import shutil
import numpy as np
from scipy.spatial import cKDTree
from PIL import Image, ImageDraw, ImageFont
import imageio.v2 as imageio
from measured_graph import make_graph, marker_predictions
from numpy_pickle import load_numpy_data

ROOT = Path('public/measured')
MEDIA = Path('public/media/measured')
MEDIA.mkdir(parents=True, exist_ok=True)
report_path = Path('docs/evidence/measured/final-comparison-01.json')
report = json.loads(report_path.read_text())
cases = list(dict.fromkeys(row['case'] for row in report['metrics']))
font = ImageFont.truetype('C:/Windows/Fonts/arial.ttf', 20)
small = ImageFont.truetype('C:/Windows/Fonts/arial.ttf', 16)
media = []

def project(points, projection):
    p = np.concatenate([points, np.ones((*points.shape[:-1], 1))], axis=-1) @ projection.T
    return p[..., :2] / p[..., 2:3]

for case in cases:
    source = Path('work/phystwin') / case
    package = ROOT / case
    package.mkdir(parents=True, exist_ok=True)
    graph, data = make_graph(case)
    metadata = json.loads((source / 'metadata.json').read_text())
    c2w = load_numpy_data(source / 'calibrate.pkl')[0]
    K = np.asarray(metadata['intrinsics'][0])
    projection = K @ np.linalg.inv(c2w)[:3]
    gt = load_numpy_data(source / 'gt_track_3d.pkl')
    valid0 = np.isfinite(gt[0]).all(axis=1)
    gt = gt[:, valid0]
    dd, ii = cKDTree(graph['rest']).query(gt[0], k=4)
    ww = 1 / np.maximum(dd, 1e-5)**2
    ww /= ww.sum(axis=1, keepdims=True)
    bound = {**graph, 'binding': ii, 'weights': ww}
    predictions = {name: marker_predictions(bound, gt[0], np.load(Path('work/measured-evaluation') / case / (name+'.npy')))
                   for name in ['default', 'jointUniform']}
    uv = {name: project(value, projection) for name, value in predictions.items()}
    observed = project(gt, projection)
    # Presentation only, after scoring: include all finite landmarks to avoid
    # hiding motion outside the first-frame crop. This never affects a rollout.
    extent = project(np.concatenate([graph['rest'], graph['controller'].reshape(-1, 3), gt[np.isfinite(gt).all(axis=2)]]), projection)
    lo = np.maximum(0, np.floor(np.nanmin(extent, axis=0) - 45)).astype(int)
    hi = np.minimum(metadata['WH'], np.ceil(np.nanmax(extent, axis=0) + 45)).astype(int)
    crop = [int(lo[0]), int(lo[1]), int(hi[0]), int(hi[1])]
    crop_width, crop_height = hi-lo
    panel_width, panel_height = 560, 430
    scale = min(panel_width/crop_width, panel_height/crop_height)
    size = (int(crop_width*scale), int(crop_height*scale))
    offset = ((panel_width-size[0])//2, (panel_height-size[1])//2 + 46)
    role = next(row['role'] for row in report['metrics'] if row['case']==case)
    filename = case+'-landmarks.mp4'
    reader = imageio.get_reader(source / 'color/0.mp4')
    writer = imageio.get_writer(MEDIA / filename, fps=metadata['fps'], codec='libx264',
                                quality=8, macro_block_size=1, ffmpeg_params=['-pix_fmt', 'yuv420p', '-movflags', '+faststart'])
    count = 0
    for f, frame in enumerate(reader):
        if f >= len(gt): break
        output = Image.new('RGB', (panel_width*3, 544), 'white')
        draw = ImageDraw.Draw(output)
        base = Image.fromarray(frame).crop(crop).resize(size, Image.Resampling.LANCZOS)
        for panel, name in enumerate(['observation', 'default', 'jointUniform']):
            left = panel*panel_width
            output.paste(base, (left+offset[0], offset[1]))
            title = {'observation':'Recorded observation', 'default':'Default response', 'jointUniform':'Fitted: lift + push'}[name]
            draw.text((left+18, 14), title, fill='#222222', font=font)
            valid = np.isfinite(gt[f]).all(axis=1)
            for marker in np.flatnonzero(valid):
                p = (observed[f, marker]-lo)*scale + np.asarray(offset) + [left, 0]
                if not np.isfinite(p).all(): continue
                draw.ellipse((p[0]-4,p[1]-4,p[0]+4,p[1]+4), outline='#18886c', width=2)
                if name != 'observation':
                    q = (uv[name][f, marker]-lo)*scale + np.asarray(offset) + [left, 0]
                    draw.line((*p,*q), fill='#1d63b7', width=2)
                    draw.line((q[0]-4,q[1]-4,q[0]+4,q[1]+4), fill='#1d63b7', width=2)
                    draw.line((q[0]-4,q[1]+4,q[0]+4,q[1]-4), fill='#1d63b7', width=2)
            if name != 'observation' and valid.any():
                error = np.linalg.norm(predictions[name][f, valid]-gt[f, valid],axis=1).mean()*1000
                draw.text((left+18,488),f'Visible landmark error: {error:.1f} mm',font=small,fill='#555555')
            else:
                draw.text((left+18,488),'Green rings: publisher landmarks',font=small,fill='#555555')
        draw.text((18,518),f'{case.replace("_"," ")} / {role} / {f/metadata["fps"]:.2f} s · PhysTwin observations; Morphic predictions',font=small,fill='#555555')
        if f in {0,len(gt)//2,len(gt)-2}:
            output.save(MEDIA / f'{case}-frame-{f:03}.jpg', quality=93)
        writer.append_data(np.asarray(output)); count += 1
    writer.close(); reader.close()
    if count != len(gt): raise ValueError(f'Frame mismatch for {case}: {count} != {len(gt)}')
    shutil.copyfile(Path('work/measured-evaluation')/case/'asset.json',package/'asset.json')
    shutil.copyfile(source/'shape/matching/final_mesh.glb',package/'appearance.glb')
    shutil.copyfile(source/'color/0/0.png',package/'source.png')
    evaluation={'role':role,'K':K.tolist(),'c2w':c2w.tolist(),'width':metadata['WH'][0],
                'height':metadata['WH'][1],'crop':crop,'fps':metadata['fps'],
                'landmarks':np.where(np.isfinite(gt),gt,0).tolist(),'visible':np.isfinite(gt).all(axis=2).tolist(),
                'binding':ii.tolist(),'weights':ww.tolist(),
                'metrics':[row for row in report['metrics'] if row['case']==case]}
    (package/'observations.json').write_text(json.dumps(evaluation,separators=(',',':')))
    path=MEDIA/filename
    media.append({'case':case,'path':path.as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                  'sourceSHA256':hashlib.sha256((source/'color/0.mp4').read_bytes()).hexdigest(),
                  'frames':count,'fps':metadata['fps'],'width':1680,'height':544,'crop':crop})
    print(f'{case}: {count} synchronized frames',flush=True)

(ROOT/'experiment.json').write_text(json.dumps({**report,'media':media},indent=2))
Path('docs/evidence/measured/media.json').write_text(json.dumps({'videos':media,'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))
