import { NodeIO } from "@gltf-transform/core";
import { KHRDracoMeshCompression } from "@gltf-transform/extensions";
import draco3d from "draco3dgltf";
import { readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
const assets = [
  {
    id: "met_tablet",
    name: "Clay tablet",
    objectId: 329081,
    url: "https://api.vntana.com/assets/products/4a352a3a-ed6b-4256-8c7d-23d6d440398f/organizations/The-Metropolitan-Museum-of-Art/clients/masters/610d93b6-af03-40e2-baf6-c30036210349.glb",
  },
  {
    id: "met_bottle",
    name: "Moche bottle",
    objectId: 308558,
    url: "https://api.vntana.com/assets/products/b00f2702-8ace-4b92-9fc0-884951ba34d6/organizations/The-Metropolitan-Museum-of-Art/clients/masters/cfe5afa9-64bc-4715-b75b-d6a110d78365.glb",
  },
];
const io = new NodeIO()
  .registerExtensions([KHRDracoMeshCompression])
  .registerDependencies({
    "draco3d.decoder": await draco3d.createDecoderModule(),
  });
let manifest = JSON.parse(
  await readFile("public/assets/manifest.json", "utf8"),
).filter((a) => !assets.some((b) => a.id === b.id));
for (const a of assets) {
  const r = await fetch(a.url, {
    headers: {
      "User-Agent": "Mozilla/5.0",
      Referer: "https://www.metmuseum.org/",
    },
  });
  if (!r.ok) throw Error(`Museum asset unavailable: ${r.status}`);
  const original = new Uint8Array(await r.arrayBuffer()),
    doc = await io.readBinary(original);
  for (const e of doc.getRoot().listExtensionsUsed())
    if (e.extensionName === "KHR_draco_mesh_compression") e.dispose();
  const bytes = await io.writeBinary(doc);
  await writeFile(`public/assets/${a.id}.glb`, bytes);
  manifest.push({
    id: a.id,
    name: a.name,
    author: "The Metropolitan Museum of Art",
    license: "CC0-1.0",
    source: `https://www.metmuseum.org/art/collection/search/${a.objectId}`,
    sourceGltf: a.url,
    sourceSha256: createHash("sha256").update(original).digest("hex"),
    sha256: createHash("sha256").update(bytes).digest("hex"),
    bytes: bytes.length,
    transformation:
      "Decoded existing Draco compression using glTF Transform 4.2.1. No simplification. Textures retained. Runtime scale: longest dimension 1.6m.",
    provenance:
      "Met Imaging 2026 real-object scan release; public-domain artwork and downloadable GLB.",
  });
  console.log(a.id, bytes.length);
}
await writeFile(
  "public/assets/manifest.json",
  JSON.stringify(manifest, null, 2) + "\n",
);
