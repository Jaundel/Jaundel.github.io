"""Official TRELLIS baseline. Supports one or multiple actual input photos.

This is a separately attributed baseline, not TRELLIS.2 or measured physics.
Run from the installed GPU environment with --source pointing to official TRELLIS.
"""
import argparse
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import time

spec = importlib.util.spec_from_file_location('reconstruction_common', Path(__file__).with_name('reconstruct-trellis.py'))
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)


def run(args):
    directory = args.output.resolve()
    directory.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    report = {'schema': 1, 'state': 'running', 'stage': 'preflight',
              'method': 'trellis-multi-image' if len(args.images) > 1 else 'trellis-single-image',
              'behavior': 'assigned', 'hiddenSurfaces': 'generated-unverified',
              'seed': args.seed, 'pipeline': 'trellis-image-large', 'inputs': []}
    common.write_report(directory, report)
    try:
        source = args.source.resolve(strict=True)
        report['sourceCommit'] = subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
        if subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no'],text=True).strip():
            raise ValueError('Use a clean official TRELLIS checkout.')
        for image in args.images:
            report['inputs'].append({'name': image.name, 'sha256': common.sha256(image), 'bytes': image.stat().st_size})
        report['input'] = report['inputs'][0]
        sys.path.insert(0,str(source))
        os.environ['ATTN_BACKEND'] = 'xformers'
        os.environ['SPCONV_ALGO'] = 'native'
        import torch
        torch.set_num_threads(4)
        from PIL import Image, ImageOps
        from huggingface_hub import snapshot_download
        from trellis.pipelines import TrellisImageTo3DPipeline
        from trellis.utils import postprocessing_utils
        if not torch.cuda.is_available():
            raise RuntimeError('CUDA GPU unavailable.')
        torch.cuda.reset_peak_memory_stats()
        revision = args.checkpoint_revision
        if len(revision) != 40 or any(c not in '0123456789abcdef' for c in revision):
            raise ValueError('Specify an immutable 40-character checkpoint revision.')
        report.update(checkpointRevision=revision, gpu=torch.cuda.get_device_name(),
                      torchVersion=torch.__version__, stage='loading-model')
        common.write_report(directory,report)
        model = snapshot_download('microsoft/TRELLIS-image-large', revision=revision)
        pipeline = TrellisImageTo3DPipeline.from_pretrained(model)
        pipeline.cuda()
        images = []
        for index, path in enumerate(args.images):
            with Image.open(path) as opened:
                prepared = pipeline.preprocess_image(ImageOps.exif_transpose(opened))
            prepared.save(directory / f'conditioning-{index:02d}.png')
            images.append(prepared)
        report.update(loadSeconds=time.monotonic()-start,stage='inference')
        common.write_report(directory,report)
        inference_start = time.monotonic()
        kwargs = dict(seed=args.seed, formats=['gaussian','mesh'], preprocess_image=False)
        result = pipeline.run(images[0],**kwargs) if len(images)==1 else pipeline.run_multi_image(images,**kwargs)
        torch.cuda.synchronize()
        report.update(inferenceSeconds=time.monotonic()-inference_start,stage='export')
        common.write_report(directory,report)
        export_start = time.monotonic()
        asset = postprocessing_utils.to_glb(result['gaussian'][0], result['mesh'][0], simplify=0.95, texture_size=1024)
        output = directory / 'asset.pending.glb'
        asset.export(str(output))
        common.validate_glb(output)
        output.replace(directory / 'asset.glb')
        report.update(state='completed',stage='completed',exportSeconds=time.monotonic()-export_start,
                      peakMemoryBytes=torch.cuda.max_memory_allocated(),elapsedSeconds=time.monotonic()-start,
                      output={'name':'asset.glb','bytes':(directory/'asset.glb').stat().st_size,
                              'sha256':common.sha256(directory/'asset.glb')})
        common.write_report(directory,report)
        return 0
    except Exception as error:
        report.update(state='failed',error=f'{type(error).__name__}: {error}',elapsedSeconds=time.monotonic()-start)
        common.write_report(directory,report)
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--images',type=Path,nargs='+',required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--checkpoint-revision',
                        default='25e0d31ffbebe4b5a97464dd851910efc3002d96')
    sys.exit(run(parser.parse_args()))
