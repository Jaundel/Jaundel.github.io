"""Input-only CO3D silhouette hull: evaluation alignment aid, not ground truth."""
import hashlib
import importlib.util
import json
from pathlib import Path
import time
import numpy as np
from PIL import Image
from skimage.measure import marching_cubes
import trimesh
from deform360_geometry import centroid_ray, intersect_rays, mask_membership, silhouette_iou

spec = importlib.util.spec_from_file_location('hull_render', Path(__file__).with_name('reconstruct-deform360-hull.py'))
renderer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(renderer)
ROOT = Path(__file__).resolve().parents[1] / 'work/co3d/190_20494_39385'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    started = time.monotonic()
    preparation = ROOT / 'evaluation-inputs/preparation.json'
    plan = json.loads(preparation.read_text())
    if sha(ROOT.parent / 'toytruck-split.json') != plan['splitSha256']:
        raise ValueError('Frozen split changed.')
    inputs = []
    for item in plan['inputs']:
        if item['frame'] in plan['heldoutFrames']:
            raise ValueError('Held-out frame cannot enter alignment.')
        path = preparation.parent / item['mask']
        if sha(path) != item['maskSha256']:
            raise ValueError('Input alignment mask changed.')
        inputs.append((item['frame'], item['camera'], np.asarray(Image.open(path)) > 127))
    rays = [centroid_ray(c, m) for _, c, m in inputs]
    center = intersect_rays(rays)
    radii = []
    for (_, camera, mask), (origin, _) in zip(inputs, rays):
        y, x = np.nonzero(mask)
        radii.append(np.linalg.norm(center - origin) * max(np.ptp(x), np.ptp(y)) /
                     min(camera['K'][0][0], camera['K'][1][1]))
    half_extent = max(radii) * 2
    grid = 128
    for _ in range(4):
        axes = [np.linspace(v - half_extent, v + half_extent, grid) for v in center]
        points = np.stack(np.meshgrid(*axes, indexing='ij'), axis=-1).reshape(-1, 3)
        occupied = np.ones(len(points), bool)
        for _, camera, mask in inputs:
            occupied &= mask_membership(points, camera, mask)
        volume = occupied.reshape((grid,) * 3)
        if not volume.any():
            raise ValueError('Input silhouettes have no common hull at this resolution.')
        if not any(np.take(volume, edge, axis=axis).any() for axis in range(3) for edge in (0, -1)):
            break
        half_extent *= 2
    else:
        raise ValueError('Hull remains clipped by grid bounds.')
    spacing = 2 * half_extent / (grid - 1)
    vertices, faces, _, _ = marching_cubes(volume.astype(np.float32), .5, spacing=(spacing,) * 3)
    vertices += center - half_extent
    mesh = trimesh.Trimesh(vertices, faces, process=True)
    mesh.fix_normals()
    if not mesh.is_watertight or not np.isfinite(mesh.vertices).all():
        raise ValueError('Invalid hull geometry.')
    destination = ROOT / 'input-hull'
    destination.mkdir(exist_ok=False)
    mesh.export(destination / 'world-mesh.ply')
    mesh.export(destination / 'asset.glb')
    scores = {}
    for number, camera, mask in inputs:
        prediction = renderer.render_silhouette(mesh, camera)
        scores[number] = silhouette_iou(prediction, mask)
        Image.fromarray(prediction.astype(np.uint8) * 255).save(destination / f'frame{number:06d}-projection.png')
    report = {'method': 'calibrated-input-silhouette-intersection',
              'role': 'Evaluation alignment aid; supplied masks/calibration; no learned completion or physical inference.',
              'preparationSha256': sha(preparation), 'sourceSha256': sha(Path(__file__)),
              'gridResolution': grid, 'gridSpacing': spacing, 'center': center.tolist(),
              'halfExtent': half_extent, 'vertices': len(mesh.vertices), 'faces': len(mesh.faces),
              'watertight': bool(mesh.is_watertight), 'inputIoU': scores,
              'meanInputIoU': float(np.mean(list(scores.values()))),
              'elapsedSeconds': time.monotonic() - started, 'heldoutPixelsRead': False,
              'outputs': {name: sha(destination / name) for name in ('world-mesh.ply', 'asset.glb')}}
    (destination / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
