"""CPU visual hull from frozen input masks and verified camera calibration only.

Standard silhouette intersection; not a learned or novel reconstruction method.
Never reads validation/test camera observations. Produces a geometric comparison,
not measured material behavior or completed unseen surface evidence.
"""
import hashlib
import json
import time
from pathlib import Path
import cv2
import numpy as np
from PIL import Image
from skimage.measure import marching_cubes
import trimesh
from deform360_geometry import centroid_ray, intersect_rays, mask_membership, project, silhouette_iou

ROOT = Path(__file__).resolve().parents[1] / 'work/deform360/057-kitchen-sponge'
GRID = 128


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def render_silhouette(mesh, camera):
    pixels, positive = project(mesh.vertices, camera)
    canvas = np.zeros((camera['height'], camera['width']), dtype=np.uint8)
    for face in mesh.faces:
        if positive[face].all():
            polygon = np.rint(pixels[face]).astype(np.int32)
            cv2.fillConvexPoly(canvas, polygon, 1)
    return canvas.astype(bool)


def main():
    started = time.monotonic()
    destination = ROOT / 'hull-baseline'
    destination.mkdir(exist_ok=False)
    split = json.loads((ROOT / 'split.json').read_text())
    prepared = json.loads((ROOT / 'preparation.json').read_text())
    calibration = json.loads((ROOT / 'calibration-verified.json').read_text())
    if sha(ROOT / 'split.json') != prepared['splitSha256']:
        raise ValueError('Split changed since input preparation.')
    if sha(ROOT / 'cameras.txt') != calibration['textSha256']:
        raise ValueError('Calibration changed since verification.')
    inputs = []
    for record in prepared['inputs']:
        name = record['camera']
        if name not in split['inputCameras'] or name in split['testCameras'] + split['validationCameras']:
            raise ValueError('Only frozen reconstruction cameras are permitted.')
        path = ROOT / 'inputs' / (name + '.png')
        if sha(path) != record['sha256']:
            raise ValueError('Input image changed.')
        mask = np.asarray(Image.open(path).getchannel('A')) > 127
        inputs.append((name, calibration['cameras'][name], mask))
    rays = [centroid_ray(c, m) for _, c, m in inputs]
    center = intersect_rays(rays)
    radii = []
    for (_, camera, mask), (origin, _) in zip(inputs, rays):
        y, x = np.nonzero(mask)
        focal = min(camera['K'][0][0], camera['K'][1][1])
        radii.append(np.linalg.norm(center - origin) * max(np.ptp(x), np.ptp(y)) / focal)
    half_extent = max(radii) * 2
    for attempt in range(4):
        axes = [np.linspace(v - half_extent, v + half_extent, GRID) for v in center]
        points = np.stack(np.meshgrid(*axes, indexing='ij'), axis=-1).reshape(-1, 3)
        occupied = np.ones(len(points), dtype=bool)
        for _, camera, mask in inputs:
            occupied &= mask_membership(points, camera, mask)
        volume = occupied.reshape((GRID,) * 3)
        if not volume.any():
            raise ValueError('Input silhouettes have no intersection at this resolution.')
        boundary = any(np.take(volume, edge, axis=axis).any() for axis in range(3) for edge in (0, -1))
        if not boundary:
            break
        half_extent *= 2
    else:
        raise ValueError('Silhouette intersection remains clipped; refusing an artificial closed hull.')
    spacing = 2 * half_extent / (GRID - 1)
    vertices, faces, _, _ = marching_cubes(volume.astype(np.float32), 0.5, spacing=(spacing,) * 3)
    vertices += center - half_extent
    mesh = trimesh.Trimesh(vertices, faces, process=True)
    mesh.fix_normals()
    if not mesh.is_watertight or not np.isfinite(mesh.vertices).all():
        raise ValueError('Hull is not a finite watertight comparison mesh.')
    mesh.export(destination / 'asset.glb')
    mesh.export(destination / 'world-mesh.ply')
    scores = {}
    for name, camera, mask in inputs:
        prediction = render_silhouette(mesh, camera)
        scores[name] = silhouette_iou(prediction, mask)
        Image.fromarray((prediction * 255).astype(np.uint8)).save(destination / (name + '-projection.png'))
    report = {'schema': 1, 'method': 'calibrated-two-view-visual-hull',
        'behavior': 'unassigned', 'appearance': 'untextured',
        'splitSha256': sha(ROOT / 'split.json'), 'preparationSha256': sha(ROOT / 'preparation.json'),
        'calibrationSha256': sha(ROOT / 'calibration-verified.json'),
        'sourceSha256': sha(Path(__file__)),
        'inputCameras': [name for name, _, _ in inputs], 'gridResolution': GRID,
        'gridSpacing': spacing, 'center': center.tolist(), 'halfExtent': half_extent,
        'occupiedVoxels': int(volume.sum()), 'vertices': len(mesh.vertices), 'faces': len(mesh.faces),
        'watertight': bool(mesh.is_watertight), 'inputSilhouetteIoU': scores,
        'heldOutEvaluation': 'not run', 'elapsedSeconds': time.monotonic() - started,
        'outputs': {name: sha(destination / name) for name in ('asset.glb', 'world-mesh.ply')},
        'limitations': ['Supplied masks and known camera calibration.',
            'Silhouette intersection cannot recover hidden concavities.',
            'Two views may underconstrain shape; no physical parameters inferred.']}
    (destination / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
