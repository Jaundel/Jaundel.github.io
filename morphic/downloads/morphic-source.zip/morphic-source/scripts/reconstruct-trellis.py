"""Run inside an installed official TRELLIS.2 environment; never provisions compute.

The output is generated appearance/geometry with assigned downstream behavior.
API reference: https://github.com/microsoft/TRELLIS.2/blob/main/example.py
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import time


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_report(directory, report):
    temporary = directory / 'result.pending.json'
    temporary.write_text(json.dumps(report, indent=2), encoding='utf-8')
    temporary.replace(directory / 'result.json')


def validate_glb(path):
    data = path.read_bytes()
    if len(data) < 28 or len(data) > 50 * 1024 * 1024:
        raise ValueError('Generated GLB must be nonempty and below the studio 50 MB limit.')
    magic, version, length = struct.unpack_from('<III', data)
    if (magic, version, length) != (0x46546C67, 2, len(data)):
        raise ValueError('Invalid generated GLB header.')
    offset, document, binary = 12, None, False
    while offset < len(data):
        if offset + 8 > len(data):
            raise ValueError('Truncated GLB chunk.')
        size, kind = struct.unpack_from('<II', data, offset)
        offset += 8
        if offset + size > len(data):
            raise ValueError('Truncated GLB payload.')
        if kind == 0x4E4F534A:
            document = json.loads(data[offset:offset + size])
        if kind == 0x004E4942:
            binary = True
        offset += size
    if not document or not binary or not document.get('meshes'):
        raise ValueError('Generated GLB has no embedded mesh.')
    if any(item.get('uri') for item in document.get('buffers', []) + document.get('images', [])):
        raise ValueError('Generated asset must embed all buffers and textures.')
    allowed = {'KHR_materials_unlit', 'KHR_texture_transform'}
    if set(document.get('extensionsRequired', [])) - allowed:
        raise ValueError('Generated asset requires extensions unsupported by Morphic.')
    if document.get('skins') or document.get('animations'):
        raise ValueError('Generated asset must be a static mesh before physics binding.')


def run(args):
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)  # Never overwrite a previous run.
    start = time.monotonic()
    report = {'schema': 1, 'state': 'running', 'stage': 'preflight',
              'method': 'trellis2-single-image', 'behavior': 'assigned',
              'hiddenSurfaces': 'generated-unverified', 'seed': args.seed,
              'pipeline': '512', 'textureSize': 1024, 'decimationTarget': 50000}
    write_report(output, report)
    try:
        source = args.source.resolve(strict=True)
        image_path = args.image.resolve(strict=True)
        if not image_path.is_file() or image_path.stat().st_size > 50 * 1024 * 1024:
            raise ValueError('Input must be one image file smaller than 50 MB.')
        if not re.fullmatch(r'[a-f0-9]{40}', args.checkpoint_revision):
            raise ValueError('Specify an immutable 40-character checkpoint commit revision.')
        commit = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
        dirty = subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain', '--untracked-files=no'], text=True).strip()
        if dirty:
            raise ValueError('Use a clean official TRELLIS.2 source checkout.')
        report.update(sourceCommit=commit, checkpointRevision=args.checkpoint_revision,
                      input={'name': image_path.name, 'sha256': sha256(image_path),
                             'bytes': image_path.stat().st_size})
        sys.path.insert(0, str(source))
        os.environ.setdefault('PYTORCH_CUDA_ALLOC_CONF', 'expandable_segments:True')
        os.environ.setdefault('OPENCV_IO_ENABLE_OPENEXR', '1')
        import torch
        from PIL import Image, ImageOps
        from huggingface_hub import snapshot_download
        from trellis2.pipelines import Trellis2ImageTo3DPipeline
        import o_voxel
        if not torch.cuda.is_available():
            raise RuntimeError('A compatible CUDA GPU is required; no substitute asset will be generated.')
        torch.cuda.reset_peak_memory_stats()
        report.update(gpu=torch.cuda.get_device_name(), torchVersion=torch.__version__, stage='loading-model')
        write_report(output, report)
        checkpoint = snapshot_download('microsoft/TRELLIS.2-4B', revision=args.checkpoint_revision)
        pipeline = Trellis2ImageTo3DPipeline.from_pretrained(checkpoint)
        pipeline.cuda()
        report['loadSeconds'] = time.monotonic() - start
        with Image.open(image_path) as opened:
            image = ImageOps.exif_transpose(opened).convert('RGBA' if 'A' in opened.getbands() else 'RGB')
        # Preserve the actual conditioning image to audit cropping/background removal.
        conditioned = pipeline.preprocess_image(image)
        conditioned.save(output / 'conditioning.png')
        report['stage'] = 'inference'
        write_report(output, report)
        infer_start = time.monotonic()
        mesh = pipeline.run(conditioned, seed=args.seed, pipeline_type='512', preprocess_image=False)[0]
        torch.cuda.synchronize()
        report['inferenceSeconds'] = time.monotonic() - infer_start
        report['stage'] = 'export'
        write_report(output, report)
        mesh.simplify(16777216)
        export_start = time.monotonic()
        asset = o_voxel.postprocess.to_glb(
            vertices=mesh.vertices, faces=mesh.faces, attr_volume=mesh.attrs,
            coords=mesh.coords, attr_layout=mesh.layout, voxel_size=mesh.voxel_size,
            aabb=[[-0.5, -0.5, -0.5], [0.5, 0.5, 0.5]],
            decimation_target=50000, texture_size=1024, remesh=True,
            remesh_band=1, remesh_project=0, verbose=True)
        temporary = output / 'asset.pending.glb'
        asset.export(str(temporary), extension_webp=False)
        validate_glb(temporary)
        temporary.replace(output / 'asset.glb')
        report.update(state='completed', stage='completed',
                      exportSeconds=time.monotonic() - export_start,
                      peakMemoryBytes=torch.cuda.max_memory_allocated(),
                      elapsedSeconds=time.monotonic() - start,
                      output={'name': 'asset.glb', 'sha256': sha256(output / 'asset.glb'),
                              'bytes': (output / 'asset.glb').stat().st_size})
        write_report(output, report)
        return 0
    except Exception as error:
        report.update(state='failed', error=f'{type(error).__name__}: {error}',
                      elapsedSeconds=time.monotonic() - start)
        write_report(output, report)
        print(report['error'], file=sys.stderr)
        return 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True, help='Clean official TRELLIS.2 checkout')
    parser.add_argument('--image', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True, help='New directory; cannot already exist')
    parser.add_argument('--checkpoint-revision', required=True)
    parser.add_argument('--seed', type=int, default=42)
    sys.exit(run(parser.parse_args()))
