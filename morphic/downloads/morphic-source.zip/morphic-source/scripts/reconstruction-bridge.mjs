import { randomUUID, createHash } from "node:crypto";
import {
  restoreJobs,
  persistJob,
  verifyStoredOutput,
} from "./reconstruction-store.mjs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { resolve, join } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { workerHealth, workerProbe, workerProbeTimeout } from "./worker-health.mjs";

const execute = promisify(execFile);
const limit = 24 * 1024 * 1024;

export function validateSubmission(body) {
  if (
    !Array.isArray(body?.images) ||
    body.images.length < 1 ||
    body.images.length > 12
  )
    throw Error("Choose between 1 and 12 reconstruction views.");
  return body.images.map((image) => {
    if (
      typeof image !== "string" ||
      !/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(image)
    )
      throw Error("Reconstruction views must be PNG images.");
    const bytes = Buffer.from(image.split(",")[1], "base64");
    if (
      bytes.length > 2 * 1024 * 1024 ||
      bytes.length < 24 ||
      bytes.subarray(0, 8).toString("hex") !== "89504e470d0a1a0a" ||
      bytes.readUInt32BE(16) > 1024 ||
      bytes.readUInt32BE(20) > 1024
    )
      throw Error("Use images no larger than 1024 pixels and 2 MB each.");
    return bytes;
  });
}

// Explicitly enabled, loopback-only development service. SSH credentials never
// enter the browser or production bundle. One job runs at a time, within a
// configured deadline and count; stopping the pod remains the operator's duty.
export function reconstructionBridge({
  jobRoot = resolve("work/reconstruction-jobs"),
  executeCommand = execute,
  env = process.env,
} = {}) {
  const execute = executeCommand;
  const host = env.MORPHIC_GPU_HOST;
  const port = env.MORPHIC_GPU_PORT;
  const key = env.MORPHIC_GPU_KEY;
  const deadline = Date.parse(env.MORPHIC_GPU_DEADLINE ?? "");
  const maxJobs = Number(env.MORPHIC_GPU_MAX_JOBS ?? 0);
  const configured = Boolean(
    host &&
      /^[a-zA-Z0-9.-]+$/.test(host) &&
      /^\d{1,5}$/.test(port ?? "") &&
      key &&
      Number.isFinite(deadline) &&
      Number.isInteger(maxJobs) &&
      maxJobs > 0 &&
      maxJobs <= 10,
  );
  let jobs = new Map();
  const allocation = createHash("sha256")
    .update(`${host}:${port}:${deadline}`)
    .digest("hex");
  const initialized = restoreJobs(jobRoot).then((restored) => {
    jobs = restored;
  });
  let active = false;
  const used = () =>
    [...jobs.values()].filter((job) => job.allocation === allocation).length;
  const uncertain = () =>
    [...jobs.values()].some(
      (job) =>
        job.stage === "interrupted" &&
        (!job.allocation || job.allocation === allocation),
    );
  const remote = `root@${host}`;
  const sshArgs = [
    "-o",
    "BatchMode=yes",
    "-o",
    "ConnectTimeout=15",
    "-p",
    port,
    "-i",
    key,
  ];
  const scpArgs = [
    "-o",
    "BatchMode=yes",
    "-o",
    "ConnectTimeout=15",
    "-P",
    port,
    "-i",
    key,
  ];
  const available = () =>
    configured &&
    Date.now() + 16 * 60_000 < deadline &&
    used() < maxJobs &&
    !uncertain();
  const health = workerHealth(() =>
    execute("ssh", [...sshArgs, remote, workerProbe], { timeout: workerProbeTimeout }),
  );
  function unavailableReason() {
    if (!configured)
      return "No GPU connected. You can review and save locally.";
    if (active)
      return "The GPU is working on an object. Your capture stays local until you submit it.";
    if (uncertain())
      return "An earlier job needs checking. Open Saved captures to check it before creating another object.";
    if (Date.now() + 16 * 60_000 >= deadline)
      return "This GPU session has ended. You can still open saved objects.";
    if (used() >= maxJobs)
      return "This GPU session has reached its object limit. You can still open saved objects.";
    return null;
  }
  async function transition(job, stage) {
    job.stage = stage;
    await persistJob(job);
  }
  async function run(job, images) {
    try {
      await mkdir(job.local, { recursive: true });
      const names = images.map((_, i) => `view-${i}.png`);
      await Promise.all(
        images.map((bytes, i) =>
          writeFile(join(job.local, names[i]), bytes, { flag: "wx" }),
        ),
      );
      await execute(
        "ssh",
        [...sshArgs, remote, `mkdir -p ${job.remote}/inputs`],
        { timeout: 30_000 },
      );
      await transition(job, "uploading");
      await execute(
        "scp",
        [
          ...scpArgs,
          ...names.map((n) => join(job.local, n)),
          `${remote}:${job.remote}/inputs/`,
        ],
        { timeout: 120_000 },
      );
      await transition(job, "reconstructing");
      const command = `cd /workspace/TRELLIS && PATH=/usr/local/cuda/bin:$PATH CUDA_HOME=/usr/local/cuda timeout 900 /workspace/morphic-venv311/bin/python /workspace/reconstruct-baseline.py --source /workspace/TRELLIS --images ${names.map((n) => `${job.remote}/inputs/${n}`).join(" ")} --output ${job.remote}/output > ${job.remote}/run.log 2>&1`;
      await execute("ssh", [...sshArgs, remote, command], { timeout: 930_000 });
      await transition(job, "downloading");
      await execute(
        "scp",
        [
          ...scpArgs,
          `${remote}:${job.remote}/output/asset.glb`,
          `${remote}:${job.remote}/output/result.json`,
          job.local,
        ],
        { timeout: 120_000 },
      );
      await verifyStoredOutput(job.local);
      await transition(job, "completed");
    } catch {
      job.stage = "interrupted";
      job.error =
        "Connection interrupted or reconstruction failed. Remote completion is unknown; check the existing job before retrying.";
      await persistJob(job).catch(() => {});
    } finally {
      try {
        await execute(
          "scp",
          [
            ...scpArgs,
            `${remote}:${job.remote}/run.log`,
            join(job.local, "run.log"),
          ],
          { timeout: 30_000 },
        );
      } catch {
        /* A connection failure may prevent log retrieval. */
      }
      active = false;
    }
  }
  function configure(server) {
    server.middlewares.use("/__morphic_reconstruction", async (req, res) => {
      const localHost = req.headers.host;
      const json = (code, value) => {
        res.writeHead(code, {
          "Content-Type": "application/json",
          "Cache-Control": "no-store",
        });
        res.end(JSON.stringify(value));
      };
      if (
        !/^(127\.0\.0\.1|localhost):\d+$/.test(localHost ?? "") ||
        (req.headers.origin && req.headers.origin !== `http://${localHost}`) ||
        req.headers["sec-fetch-site"] === "cross-site"
      )
        return json(403, { error: "Local requests only." });
      const path = (req.url ?? "/").split("?")[0];
      try {
        await initialized;
      } catch {
        return json(503, {
          error: "Local reconstruction history could not be opened.",
        });
      }
      if (req.method === "GET" && path === "/jobs")
        return json(
          200,
          [...jobs.values()]
            .sort((a, b) => b.createdAt - a.createdAt)
            .map(({ id, stage, error, createdAt }) => ({
              id,
              stage,
              error,
              createdAt,
            })),
        );
      if (req.method === "GET" && path === "/") {
        const status = !unavailableReason() && (await health.check());
        const reason = unavailableReason();
        const ready = !reason && Boolean(status?.ready);
        return json(200, {
          available: ready,
          busy: active,
          message:
            reason ??
            (ready
              ? "GPU ready. Create sends these views to Runpod."
              : "The GPU could not be reached or is still setting up. You can review and save locally."),
          destination: "Runpod",
          remainingJobs: configured ? Math.max(0, maxJobs - used()) : 0,
        });
      }
      if (req.method === "POST" && path === "/") {
        if (
          req.headers.origin !== `http://${localHost}` ||
          req.headers["content-type"] !== "application/json"
        )
          return json(403, { error: "Same-origin JSON required." });
        if (!available() || active)
          return json(409, {
            error: "GPU unavailable or busy. Your capture is still local.",
          });
        active = true;
        try {
          if (!(await health.check({ fresh: true })).ready)
            throw Error(
              "The GPU is not ready. No reconstruction was started; your capture is saved locally.",
            );
          const chunks = [];
          let size = 0;
          for await (const chunk of req) {
            size += chunk.length;
            if (size > limit) throw Error("Capture upload is too large.");
            chunks.push(chunk);
          }
          const images = validateSubmission(
            JSON.parse(Buffer.concat(chunks).toString("utf8")),
          );
          // Recheck after upload: the deadline may have expired while reading.
          if (!available()) throw Error("GPU budget window has ended.");
          const id = randomUUID();
          const job = {
            id,
            stage: "queued",
            local: join(jobRoot, id),
            remote: `/workspace/morphic-jobs/${id}`,
            allocation,
            createdAt: Date.now(),
          };
          await persistJob(job);
          jobs.set(id, job);
          void run(job, images);
          return json(202, { id, stage: job.stage });
        } catch (error) {
          active = false;
          return json(400, { error: error.message });
        }
      }
      const match = /^\/([a-f0-9-]{36})(?:\/(asset|report|recover))?$/.exec(
        path,
      );
      const job = match && jobs.get(match[1]);
      if (req.method === "POST" && job && match[2] === "recover") {
        if (
          req.headers.origin !== `http://${localHost}` ||
          req.headers["content-type"] !== "application/json"
        )
          return json(403, { error: "Same-origin JSON required." });
        if (
          !configured ||
          job.allocation !== allocation ||
          active ||
          job.stage !== "interrupted"
        )
          return json(409, {
            error:
              "The original GPU connection is unavailable or busy. Saved results remain available locally.",
          });
        active = true;
        try {
          const { stdout } = await execute(
            "ssh",
            [...sshArgs, remote, `cat ${job.remote}/output/result.json`],
            { timeout: 30_000 },
          );
          const report = JSON.parse(stdout);
          if (report.state === "completed") {
            await execute(
              "scp",
              [
                ...scpArgs,
                `${remote}:${job.remote}/output/asset.glb`,
                `${remote}:${job.remote}/output/result.json`,
                job.local,
              ],
              { timeout: 120_000 },
            );
            await verifyStoredOutput(job.local);
            delete job.error;
            await transition(job, "completed");
          } else if (report.state === "failed") {
            job.error =
              "The remote worker reported failure. The original capture is still local.";
            await transition(job, "failed");
          } else {
            return json(200, {
              stage: "interrupted",
              error:
                "The existing job is still running. Check again later; do not resubmit.",
            });
          }
          return json(200, { stage: job.stage, error: job.error });
        } catch {
          return json(503, {
            error:
              "Could not verify the existing remote job. No new reconstruction was started.",
          });
        } finally {
          active = false;
        }
      }
      if (req.method !== "GET" || !job)
        return json(404, { error: "Job not found." });
      if (!match[2])
        return json(200, { id: job.id, stage: job.stage, error: job.error });
      if (job.stage !== "completed")
        return json(409, { error: "Output is not ready." });
      try {
        const bytes = await readFile(
          join(job.local, match[2] === "asset" ? "asset.glb" : "result.json"),
        );
        res.writeHead(200, {
          "Content-Type":
            match[2] === "asset" ? "model/gltf-binary" : "application/json",
          "Cache-Control": "no-store",
        });
        res.end(bytes);
      } catch {
        json(500, { error: "Output could not be read." });
      }
    });
  }
  return {
    name: "morphic-reconstruction",
    configureServer: configure,
    configurePreviewServer: configure,
  };
}
