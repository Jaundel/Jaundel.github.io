import { mkdir, readFile, writeFile, rename, readdir } from "node:fs/promises";
import { join } from "node:path";
import { validateReconstructionResult } from "../src/io/reconstruction-result.js";

export const jobIdPattern =
  /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;

export async function verifyStoredOutput(directory) {
  const report = JSON.parse(
    await readFile(join(directory, "result.json"), "utf8"),
  );
  const bytes = await readFile(join(directory, "asset.glb"));
  await validateReconstructionResult(
    report,
    bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
  );
}

export async function persistJob(job) {
  await mkdir(job.local, { recursive: true });
  const record = {
    id: job.id,
    stage: job.stage,
    error: job.error,
    allocation: job.allocation,
    createdAt: job.createdAt,
  };
  await writeFile(
    join(job.local, "job.pending.json"),
    JSON.stringify(record, null, 2),
  );
  await rename(
    join(job.local, "job.pending.json"),
    join(job.local, "job.json"),
  );
}

// Never rerun a job on startup. A lost connection does not prove remote failure.
// Completed artifacts can be used without reconnecting to or starting a GPU.
export async function restoreJobs(root) {
  await mkdir(root, { recursive: true });
  const jobs = new Map();
  for (const entry of await readdir(root, { withFileTypes: true })) {
    if (!entry.isDirectory() || !jobIdPattern.test(entry.name)) continue;
    const local = join(root, entry.name);
    let record;
    try {
      record = JSON.parse(await readFile(join(local, "job.json"), "utf8"));
    } catch {
      record = {};
    }
    const job = {
      id: entry.name,
      local,
      remote: `/workspace/morphic-jobs/${entry.name}`,
      allocation:
        typeof record.allocation === "string" ? record.allocation : undefined,
      createdAt: Number.isFinite(record.createdAt) ? record.createdAt : 0,
      stage: "interrupted",
      error:
        "Connection interrupted. Remote completion is unknown; do not resubmit this capture until the existing job is checked.",
    };
    try {
      await verifyStoredOutput(local);
      job.stage = "completed";
      delete job.error;
    } catch {
      if (record.stage === "failed") {
        job.stage = "failed";
        job.error =
          "The previous reconstruction failed. Your original capture is still saved locally.";
      } else if (record.stage === "completed") {
        job.stage = "invalid";
        job.error =
          "Saved output is missing or failed validation. It cannot be opened as a completed reconstruction.";
      }
    }
    jobs.set(job.id, job);
  }
  return jobs;
}
