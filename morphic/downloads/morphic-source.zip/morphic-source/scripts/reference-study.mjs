import { readFile, writeFile } from "node:fs/promises";
import { geometryFromGLB } from "../src/io/glb.js";
import { buildCage } from "../src/physics/cage.js";
import { Solver } from "../src/physics/solver.js";
const bytes = await readFile("public/assets/lemon.glb"),
  g = geometryFromGLB(
    bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
  );
const result = {
  protocol:
    "Lemon. Start from rest, gravity -9.81 for 2 simulated seconds. No handles. Same material jelly. Ablation removes volume constraints but retains the same volumetric cage and edge constraints; this is not a surface-only solver.",
  rows: [],
};
for (const resolution of [6, 8, 12])
  for (const hz of [60, 120, 240])
    for (const bulk of [true, false]) {
      const c = buildCage(g.vertices, g.triangles, resolution),
        s = new Solver(c, { dt: 1 / hz, gravity: -9.81 });
      if (!bulk) s.solveVolumes = () => {};
      let worstVolumeError = 0;
      const start = performance.now();
      for (let i = 0; i < hz * 2; i++) {
        s.step();
        worstVolumeError = Math.max(
          worstVolumeError,
          s.diagnostics().meanVolumeError,
        );
      }
      result.rows.push({
        resolution,
        hz,
        volumeConstraints: bulk,
        elapsedMs: performance.now() - start,
        worstVolumeError,
        final: s.diagnostics(),
      });
    }
await writeFile(
  "docs/evidence/reference-study.json",
  JSON.stringify(result, null, 2) + "\n",
);
console.log(
  JSON.stringify(
    result.rows.map(
      ({ resolution, hz, volumeConstraints, worstVolumeError, final }) => ({
        resolution,
        hz,
        volumeConstraints,
        worstVolumeError,
        volume: final.volumeRatio,
        inverted: final.inverted,
      }),
    ),
    null,
    2,
  ),
);
