"""Read selected entries of a public ZIP over HTTP ranges; never extract paths blindly."""
import io
import json
import struct
import zipfile
from pathlib import Path
import requests


class HttpFile(io.RawIOBase):
    def __init__(self, url, size):
        self.url, self.size, self.pos = url, size, 0
        self.session = requests.Session()
        self.transferred = 0
        self.cache = {}

    def readable(self):
        return True

    def seekable(self):
        return True

    def seek(self, offset, whence=0):
        self.pos = offset if whence == 0 else self.pos + offset if whence == 1 else self.size + offset
        return self.pos

    def tell(self):
        return self.pos

    def read(self, n=-1):
        n = self.size - self.pos if n < 0 else min(n, self.size - self.pos)
        if n <= 0:
            return b""
        start, end = self.pos, self.pos + n - 1
        key = (start, end)
        if key not in self.cache:
            response = self.session.get(self.url, headers={"Range": f"bytes={start}-{end}"}, timeout=60)
            response.raise_for_status()
            if response.status_code != 206 or len(response.content) != n:
                raise IOError(f"Server did not honor range: status {response.status_code}, bytes {len(response.content)}, requested {n}")
            self.transferred += n
            self.cache[key] = response.content
        self.pos += n
        return self.cache[key]


def open_public_archive(name="data.zip", revision="main"):
    base = f"https://huggingface.co/datasets/Jianghanxiao/PhysTwin/resolve/{revision}/"
    response = requests.get(f"https://huggingface.co/api/datasets/Jianghanxiao/PhysTwin/tree/{revision}", timeout=30)
    response.raise_for_status()
    entries = response.json()
    size = next(x["size"] for x in entries if x["path"] == name)
    remote = HttpFile(base + name + "?download=true", size)
    return remote, zipfile.ZipFile(remote)


if __name__ == "__main__":
    remote, archive = open_public_archive()
    files = [{"name": x.filename, "bytes": x.file_size, "compressed": x.compress_size} for x in archive.infolist()]
    target = Path("work/phystwin-index.json")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(files, indent=2))
    print(json.dumps({"entries": len(files), "indexBytesTransferred": remote.transferred,
                      "topLevel": sorted(set(x["name"].split("/")[1] for x in files if "/" in x["name"])),
                      "processed": [x for x in files if x["name"].endswith((".pkl", ".glb", ".obj", ".json"))][:60]}, indent=2))
