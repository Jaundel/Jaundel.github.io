#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/cuda/bin:$PATH
export CUDA_HOME=/usr/local/cuda
cd /workspace/TRELLIS
mkdir /workspace/sponge-comparison
python=/workspace/morphic-venv311/bin/python
first=/workspace/sponge-inputs/brics-odroid-001_cam0.png
second=/workspace/sponge-inputs/brics-odroid-021_cam1.png
for variant in single-first single-second two-view; do
  case "$variant" in
    single-first) inputs=("$first");;
    single-second) inputs=("$second");;
    two-view) inputs=("$first" "$second");;
  esac
  printf 'START %s\n' "$variant"
  timeout 900 "$python" /workspace/reconstruct-baseline.py \
    --source /workspace/TRELLIS --seed 42 \
    --checkpoint-revision 25e0d31ffbebe4b5a97464dd851910efc3002d96 \
    --images "${inputs[@]}" --output "/workspace/sponge-comparison/$variant" \
    > "/workspace/sponge-comparison/$variant.log" 2>&1
  printf 'COMPLETE %s\n' "$variant"
done
printf 'MORPHIC_SPONGE_BATCH_COMPLETE\n'
