"""Record or verify the delivered source and evidence, without modifying results."""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "docs/evidence/manifest.json"
TEXT = {".js", ".mjs", ".py", ".json", ".md", ".css", ".html", ".txt", ".yml", ".svg"}


def digest(path):
    data = path.read_bytes()
    if path.suffix in TEXT or path.name in {"LICENSE", ".gitignore", ".prettierignore"}:
        data = data.replace(b"\r\n", b"\n")
        encoding = "utf8-lf"
    else:
        encoding = "raw"
    return {"sha256": hashlib.sha256(data).hexdigest(), "encoding": encoding}


def files():
    found = []
    for folder in ("src", "tests", "scripts", "docs", "public", ".github"):
        found.extend(p for p in (ROOT / folder).rglob("*") if p.is_file()
                     and "__pycache__" not in p.parts and p != MANIFEST)
    found.extend(ROOT / name for name in (
        "package.json", "package-lock.json", "index.html", "README.md", "LICENSE",
        "THIRD_PARTY_NOTICES.md", "requirements-browser.txt", ".gitignore", ".prettierignore",
        "article.html", "synthetic.html", "requirements-research.txt", "vite.config.js", "AGENTS.md", "EXECUTION_STATE.md"))
    return sorted(found)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--verify", action="store_true")
args = parser.parse_args()
current = {p.relative_to(ROOT).as_posix(): digest(p) for p in files()}
if args.verify:
    recorded = json.loads(MANIFEST.read_text(encoding="utf8"))["files"]
    changed = [p for p in sorted(current.keys() | recorded.keys())
               if current.get(p) != recorded.get(p)]
    if changed:
        raise SystemExit("Evidence snapshot differs: " + ", ".join(changed))
    print(f"Verified {len(current)} source, asset, and evidence hashes.")
else:
    snapshot = {
        "createdUTC": datetime.now(timezone.utc).isoformat(),
        "engine": "morphic-xpbd-3",
        "scope": "Delivery snapshot of source, assets, and recorded experiments. Text hashes normalize CRLF to LF for cross-platform Git checkout. This records file identity, not independent experimental attestation. The manifest excludes itself and generated dist/node_modules.",
        "historicalEvidence": "before-* and rejected-* are retained pre-fix failures, not current validation results.",
        "files": current,
    }
    MANIFEST.write_text(json.dumps(snapshot, indent=2) + "\n", encoding="utf8")
    print(f"Sealed {len(current)} source, asset, and evidence hashes.")
