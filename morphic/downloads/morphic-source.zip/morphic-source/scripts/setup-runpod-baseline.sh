#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/cuda/bin:$PATH
export CUDA_HOME=/usr/local/cuda
export MAX_JOBS=8
export TORCH_CUDA_ARCH_LIST=8.0
python3 -m venv /workspace/morphic-venv
source /workspace/morphic-venv/bin/activate
python -m pip install uv
uv python install 3.11
uv venv --seed --python 3.11 /workspace/morphic-venv311
source /workspace/morphic-venv311/bin/activate
python -m pip install --no-cache-dir torch==2.6.0 torchvision==0.21.0 xformers==0.0.29.post3 --index-url https://download.pytorch.org/whl/cu124
python -m pip install --no-cache-dir 'numpy<2' pillow imageio imageio-ffmpeg tqdm easydict 'opencv-python-headless<4.12' scipy ninja rembg onnxruntime trimesh open3d xatlas pyvista pymeshfix igraph 'transformers<5' spconv-cu120 plyfile
python -m pip install --no-cache-dir git+https://github.com/EasternJournalist/utils3d.git@9a4eb15e4021b67b12c460c7057d642626897ec8
python -m pip install kaolin==0.18.0 -f https://nvidia-kaolin.s3.us-east-2.amazonaws.com/torch-2.6.0_cu124.html
git clone --branch v0.4.0 https://github.com/NVlabs/nvdiffrast.git /workspace/nvdiffrast
python -m pip install /workspace/nvdiffrast --no-build-isolation
git clone --recursive https://github.com/autonomousvision/mip-splatting.git /workspace/mip-splatting
python -m pip install /workspace/mip-splatting/submodules/diff-gaussian-rasterization --no-build-isolation
python -m pip freeze > /workspace/morphic-packages.txt
printf 'MORPHIC_SETUP_COMPLETE\n'
