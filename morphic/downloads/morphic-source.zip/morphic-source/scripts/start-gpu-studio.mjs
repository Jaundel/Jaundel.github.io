import { parseArgs, promisify } from "node:util";
import { execFile } from "node:child_process";
import { mkdir, readFile, stat, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { workerHealth, workerProbe, workerProbeTimeout } from "./worker-health.mjs";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const savedPath = resolve(root, "work/gpu-connection.json");
const execute = promisify(execFile);

export function validateConnection(value, now = Date.now()) {
  if (!value || typeof value !== "object")
    throw Error("GPU connection is missing.");
  const { host, key, until } = value;
  const sshPort = Number(value.sshPort),
    jobs = Number(value.jobs);
  if (typeof host !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9.-]*$/.test(host))
    throw Error("Use the SSH host shown by your Runpod worker.");
  if (!Number.isInteger(sshPort) || sshPort < 1 || sshPort > 65535)
    throw Error("SSH port must be between 1 and 65535.");
  if (typeof key !== "string" || !key.trim())
    throw Error("Specify your existing SSH key file.");
  if (
    typeof until !== "string" ||
    !/(Z|[+-]\d{2}:\d{2})$/.test(until) ||
    !Number.isFinite(Date.parse(until))
  )
    throw Error(
      "Use an ISO deadline with a timezone, for example 2026-09-17T15:00:00Z.",
    );
  if (Date.parse(until) <= now + 16 * 60_000)
    throw Error(
      "The saved session has too little time left. Set an explicit new --until deadline after checking your budget and existing jobs.",
    );
  if (!Number.isInteger(jobs) || jobs < 1 || jobs > 10)
    throw Error("Set --jobs between 1 and 10.");
  return {
    host,
    sshPort,
    key: resolve(key),
    until: new Date(until).toISOString(),
    jobs,
  };
}

export function connectionEnvironment(connection) {
  return {
    MORPHIC_GPU_HOST: connection.host,
    MORPHIC_GPU_PORT: String(connection.sshPort),
    MORPHIC_GPU_KEY: connection.key,
    MORPHIC_GPU_DEADLINE: connection.until,
    MORPHIC_GPU_MAX_JOBS: String(connection.jobs),
  };
}

export async function main(args = process.argv.slice(2)) {
  const { values } = parseArgs({
    args,
    options: {
      host: { type: "string" },
      "ssh-port": { type: "string" },
      key: { type: "string" },
      until: { type: "string" },
      jobs: { type: "string" },
      port: { type: "string", default: "4181" },
      check: { type: "boolean" },
      help: { type: "boolean" },
    },
  });
  if (values.help) {
    console.log(`Connect Morphic to an existing, prepared GPU worker.

First connection:
  npm run studio:gpu -- --host HOST --ssh-port PORT --key KEY_FILE --until ISO_DATE --jobs 2
Reconnect with the same deadline and remaining job allowance:
  npm run studio:gpu
Read-only connection check (no server and no saved-setting changes):
  npm run studio:gpu -- --check

Add --port 4182 if another local studio is running. The default is 4181.
Use an explicit timezone in --until, such as 2026-09-17T15:00:00Z.
This does not provision or stop a Runpod worker. Stop it in Runpod after saving
your outputs: the deadline limits submissions, not cloud billing.
Verified connections are saved locally in ignored work/gpu-connection.json.
See docs/GPU_SETUP.md for worker installation and evidence limits.`);
    return;
  }
  const configuring = ["host", "ssh-port", "key", "until", "jobs"].some(
    (k) => values[k] !== undefined,
  );
  let input;
  if (configuring) {
    input = {
      host: values.host,
      sshPort: values["ssh-port"],
      key: values.key,
      until: values.until,
      jobs: values.jobs ?? "2",
    };
  } else {
    try {
      input = JSON.parse(await readFile(savedPath, "utf8"));
    } catch {
      throw Error(
        "No readable saved GPU connection. Run npm run studio:gpu -- --help for first-time setup.",
      );
    }
  }
  const connection = validateConnection(input);
  const port = Number(values.port);
  if (!Number.isInteger(port) || port < 1024 || port > 65535)
    throw Error("Local port must be between 1024 and 65535.");
  if (!(await stat(connection.key)).isFile())
    throw Error("SSH key path must name a file.");
  console.log("Checking the worker; no reconstruction is being started…");
  const health = workerHealth(() =>
    execute(
      "ssh",
      [
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=15",
        "-p",
        String(connection.sshPort),
        "-i",
        connection.key,
        `root@${connection.host}`,
        workerProbe,
      ],
      { timeout: workerProbeTimeout },
    ),
  );
  if (!(await health.check()).ready)
    throw Error(
      "Worker is unavailable or setup is incomplete. Verify its current SSH address, host identity and setup. No job was started and no connection settings were changed.",
    );
  if (values.check) {
    console.log(
      "Worker preflight passed. No job started; saved settings unchanged.",
    );
    return;
  }
  Object.assign(process.env, connectionEnvironment(connection));
  const { createServer } = await import("vite");
  const server = await createServer({
    root,
    server: { host: "127.0.0.1", port, strictPort: true },
  });
  try {
    await server.listen();
    await mkdir(dirname(savedPath), { recursive: true });
    await writeFile(savedPath, JSON.stringify(connection, null, 2) + "\n", {
      mode: 0o600,
    });
  } catch (error) {
    await server.close();
    throw error;
  }
  console.log(
    `Morphic: http://127.0.0.1:${port}/\nSession deadline: ${connection.until}\nJob allowance: ${connection.jobs} total for this saved session (completed attempts count).\nStop the Runpod worker separately when finished.`,
  );
  for (const signal of ["SIGINT", "SIGTERM"])
    process.once(signal, async () => {
      await server.close();
      process.exit(0);
    });
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(resolve(process.argv[1])).href
) {
  main().catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  });
}
