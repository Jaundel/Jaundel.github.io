import fs from "node:fs";
import crypto from "node:crypto";
import assert from "node:assert/strict";
import { readDataset } from "../src/behavior/dataset.js";
import {
  deployAsset,
  evaluate,
  predict,
  verifyReplay,
} from "../src/behavior/experiment.js";

const hashes = JSON.parse(
  fs.readFileSync("docs/evidence/behavior/hashes.json", "utf8"),
);
for (const [path, hash] of Object.entries(hashes)) {
  const current = crypto
    .createHash("sha256")
    .update(fs.readFileSync(path, "utf8").replaceAll("\r\n", "\n"))
    .digest("hex");
  assert.equal(current, hash, "Experiment source or evidence changed: " + path);
}
const bundle = JSON.parse(
  fs.readFileSync("public/behavior/study.json", "utf8"),
);
const dataset = JSON.parse(
  fs.readFileSync("public/behavior/dataset.json", "utf8"),
);
const { cage, settings, test } = readDataset(dataset);
const field = deployAsset(cage, settings, bundle.asset);
const row = bundle.report.rows.find(
  (r) => r.case === "two-region" && r.seed === 1,
);
assert.deepEqual(evaluate(cage, settings, field, test[0]), row.test.regional);
assert.deepEqual(
  evaluate(cage, settings, field, test[1]),
  row.testOther.regional,
);
const predicted = predict(
  cage,
  settings,
  field,
  test[0],
  test[0].observations.map((f) => f.tick),
);
assert.deepEqual(predicted.frames, bundle.curves.regional);
assert.equal(verifyReplay(cage, predicted), 0);
console.log(
  "Hashes, serialized geometry, held-out scores, deployed trajectories and exact replay verified.",
);
