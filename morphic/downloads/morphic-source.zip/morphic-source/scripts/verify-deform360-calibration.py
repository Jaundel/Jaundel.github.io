"""Compare released text poses against official camera-to-world calibration.

Only the pinned official NumPy calibration is loaded with pickle enabled. Never
use this loader on user uploads. No RGB, masks or reconstructed geometry is read.
"""
import hashlib
import json
from pathlib import Path
import numpy as np
import requests
from scipy.spatial.transform import Rotation

ROOT = Path(__file__).resolve().parents[1] / 'work/deform360/057-kitchen-sponge'
REVISION = '5ea8c5d3fc7b4a7b4f9f921f2ceb1de24610f6a4'
URL = ('https://huggingface.co/datasets/brownu/deform360/resolve/'
       f'{REVISION}/raw/057-kitchen-sponge/calibration_refined/extrinsics.npy')


def main():
    path = ROOT / 'official-extrinsics.npy'
    response = requests.get(URL, timeout=60)
    response.raise_for_status()
    if len(response.content) != 10502:
        raise ValueError('Unexpected pinned calibration size.')
    if path.exists() and path.read_bytes() != response.content:
        raise ValueError('Local calibration differs from pinned source.')
    path.write_bytes(response.content)
    official = np.load(path, allow_pickle=True).item()
    records = []
    cameras = {}
    excluded = []
    for line in (ROOT / 'cameras.txt').read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        row = line.split()
        name = row[11]
        if name not in official:
            excluded.append(name)
            continue
        wxyz = np.array(row[12:16], dtype=float)
        transform = np.eye(4)
        transform[:3, :3] = Rotation.from_quat(wxyz[[1, 2, 3, 0]]).as_matrix()
        transform[:3, 3] = np.array(row[16:19], dtype=float)
        expected = np.asarray(official[name], dtype=float)
        if expected.shape != (4, 4) or not np.isfinite(expected).all():
            raise ValueError('Invalid official pose.')
        inverse_error = float(np.max(np.abs(transform - np.linalg.inv(expected))))
        direct_error = float(np.max(np.abs(transform - expected)))
        records.append({'camera': name, 'worldToCameraMaxError': inverse_error,
                        'cameraToWorldMaxError': direct_error})
        fx, fy, cx, cy = map(float, row[3:7])
        if any(float(v) != 0 for v in row[7:11]):
            raise ValueError('Expected undistorted pinhole calibration.')
        cameras[name] = {'width': int(row[1]), 'height': int(row[2]),
            'K': [[fx, 0, cx], [0, fy, cy], [0, 0, 1]],
            'worldToCamera': transform.tolist()}
    maximum = max(r['worldToCameraMaxError'] for r in records)
    roster = set(json.loads((ROOT / 'metadata.json').read_text())['cameras'])
    if set(cameras) != roster:
        raise ValueError('Verified calibration does not cover the episode camera roster.')
    if maximum > 1e-7:
        raise ValueError(f'Text poses do not match official world-to-camera: {maximum}')
    report = {'schema': 1, 'source': URL, 'rawDatasetRevision': REVISION,
        'officialExtrinsicsSha256': hashlib.sha256(response.content).hexdigest(),
        'textSha256': hashlib.sha256((ROOT / 'cameras.txt').read_bytes()).hexdigest(),
        'convention': 'world-to-camera; OpenCV +x right, +y down, +z forward',
        'maximumAbsolutePoseError': maximum, 'comparisons': records,
        'textOnlyCamerasExcluded': excluded,
        'cameras': cameras}
    (ROOT / 'calibration-verified.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'cameraCount': len(cameras), 'maximumAbsolutePoseError': maximum,
                      'convention': report['convention']}))


if __name__ == '__main__':
    main()
