"""Recompute frozen scores and compare Python/JavaScript deployment trajectories."""
from pathlib import Path
import hashlib
import json
import platform
import subprocess
import numpy as np
from scipy.spatial import cKDTree
from measured_graph import make_graph, rollout, score, marker_predictions
from numpy_pickle import load_numpy_data

report=json.loads(Path('docs/evidence/measured/final-comparison-01.json').read_text())
models=report['protocol']['parameters']
results=[]
for case in dict.fromkeys(row['case'] for row in report['metrics']):
    graph,data=make_graph(case)
    asset_path=Path('public/measured')/case/'asset.json'
    asset=json.loads(asset_path.read_text())
    np.testing.assert_array_equal(asset['rest'],graph['rest'])
    np.testing.assert_array_equal(asset['controller'],graph['controller'])
    np.testing.assert_array_equal(asset['edges'],graph['edges'])
    np.testing.assert_array_equal(asset['parameters'],models['jointUniform'][:4])
    assert asset['settings']['friction']==models['jointUniform'][4]
    frozen=rollout(graph,models['jointUniform'])
    js=subprocess.run(['node','scripts/measured-runtime.mjs'],input=asset_path.read_bytes(),capture_output=True,check=True)
    deployed=np.frombuffer(js.stdout,dtype=np.float64).reshape(frozen.shape)
    drift=float(np.max(np.abs(frozen-deployed)))
    assert drift<1e-12,(case,drift)
    gt=load_numpy_data(Path('work/phystwin')/case/'gt_track_3d.pkl')
    valid0=np.isfinite(gt[0]).all(axis=1);gt=gt[:,valid0]
    dd,ii=cKDTree(graph['rest']).query(gt[0],k=4)
    ww=1/np.maximum(dd,1e-5)**2;ww/=ww.sum(axis=1,keepdims=True)
    landmark_graph={**graph,'binding':ii,'weights':ww}
    for name in [*models,'static','kinematic']:
        if name=='static':x=np.tile(graph['rest'],(len(graph['controller']),1,1))
        elif name=='kinematic':
            distance2=np.sum((graph['rest'][:,None,:]-graph['controller'][0][None,:,:])**2,axis=2)
            weights=np.exp(-distance2/(2*report['kinematicRadiusMetres']**2))
            influence=weights.max(axis=1);weights/=np.maximum(weights.sum(axis=1,keepdims=True),1e-30)
            x=graph['rest']+np.einsum('nc,tca,n->tna',weights,graph['controller']-graph['controller'][0],influence)
        else:x=rollout(graph,models[name])
        actual=score(graph,data,x)
        expected=next(row for row in report['metrics'] if row['case']==case and row['model']==name)
        assert abs(actual-expected['filteredTrackRMSEMetres'])<1e-12,(case,name,actual)
        prediction=marker_predictions(landmark_graph,gt[0],x)
        mask=np.isfinite(gt).all(axis=2);mask[0]=False
        error=float(np.linalg.norm(prediction-gt,axis=2)[mask].mean())
        assert abs(error-expected['landmarkMeanErrorMetres'])<1e-12,(case,name,error)
    result={'case':case,'maximumCoordinateDriftMetres':drift,'verifiedModels':6,'timing':json.loads(js.stderr),
            'assetSHA256':hashlib.sha256(asset_path.read_bytes()).hexdigest()}
    results.append(result);print(json.dumps(result),flush=True)

verification={'environment':{'python':platform.python_version(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'processor':platform.processor()},'cases':results,
              'reportSHA256':hashlib.sha256(Path('docs/evidence/measured/final-comparison-01.json').read_bytes()).hexdigest(),
              'sources':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['scripts/verify-measured.py','scripts/measured-runtime.mjs','scripts/measured_graph.py','src/physics/measured-graph.js']}}
Path('docs/evidence/measured/verification.json').write_text(json.dumps(verification,indent=2))
print('Verified 24 model/recording scores, 24 landmark scores, and four full deployment trajectories.')
