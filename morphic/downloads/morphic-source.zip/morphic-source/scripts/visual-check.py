"""Rest-pose CPU/GPU appearance parity and capture of a short real studio video."""
import pathlib, json, math
from PIL import Image, ImageChops, ImageStat
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1];media=root/'docs'/'media';evidence=root/'docs'/'evidence'
with sync_playwright() as p:
    browser=p.chromium.launch(channel='chrome',headless=True)
    for mode in ['gpu','cpu']:
        page=browser.new_page(viewport={'width':1440,'height':960},device_scale_factor=1)
        page.goto('http://127.0.0.1:5173/'+('?cpu=1' if mode=='cpu' else ''))
        page.wait_for_function('window.morphicStats');page.locator('#asset').select_option('met_tablet')
        page.wait_for_function('window.morphicStats.renderVertices>70000 && window.morphicStats.tick===0');page.wait_for_timeout(800)
        page.locator('canvas').screenshot(path=str(evidence/f'rest-{mode}.png'));page.close()
    a=Image.open(evidence/'rest-gpu.png').convert('RGB');b=Image.open(evidence/'rest-cpu.png').convert('RGB')
    difference=ImageChops.difference(a,b);stats=ImageStat.Stat(difference)
    result={'protocol':'Same browser, fixed camera, resting Met tablet, CPU vs GPU skinning, canvas screenshot at 1440x960 viewport. All channels in 8-bit display RGB. Not a comparison with source photography.','meanAbsoluteError255':sum(stats.mean)/3,'rmsError255':math.sqrt(sum(x*x for x in stats.rms)/3),'dimensions':a.size}
    (evidence/'visual-parity.json').write_text(json.dumps(result,indent=2)+'\n');assert result['meanAbsoluteError255']<2,result
    context=browser.new_context(viewport={'width':1440,'height':960},record_video_dir=str(media/'video-work'),record_video_size={'width':1440,'height':960})
    page=context.new_page();page.goto('http://127.0.0.1:5173/');page.wait_for_function('window.morphicStats');page.locator('#asset').select_option('met_tablet');page.wait_for_function('window.morphicStats.renderVertices>70000 && window.morphicStats.tick===0');page.wait_for_timeout(600)
    page.locator('#squash').click();page.wait_for_function('window.morphicStats.tick>=175');page.locator('#stretch').click();page.wait_for_function('window.morphicStats.tick>=350');page.locator('#play').click();page.wait_for_timeout(400)
    page.screenshot(path=str(media/'tablet-final.png'));video=page.video;context.close();video.save_as(str(media/'morphic-demo.webm'));video.delete();browser.close()
print(json.dumps(result,indent=2))
