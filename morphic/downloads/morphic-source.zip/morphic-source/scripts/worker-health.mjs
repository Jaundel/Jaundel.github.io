// Read-only preflight: no model download, inference, or worker provisioning.
// A fresh A100 worker needed 26 seconds to import rembg and its dependencies.
// Leave bounded startup time instead of rejecting a correctly installed worker.
export const workerProbeTimeout = 55_000;
export const workerProbe =
  "test -f /workspace/reconstruct-baseline.py && " +
  "test -f /workspace/reconstruct-trellis.py && " +
  "test -d /workspace/TRELLIS/trellis && " +
  "timeout 45 /workspace/morphic-venv311/bin/python -c " +
  '"import torch, xformers, spconv, rembg, kaolin, nvdiffrast; ' +
  "assert torch.cuda.is_available(); print('MORPHIC_WORKER_READY')\"";

export function workerHealth(probe, { now = Date.now, ttl = 20_000 } = {}) {
  let cached;
  let pending;
  return {
    async check({ fresh = false } = {}) {
      if (pending) return pending;
      if (!fresh && cached && now() - cached.checkedAt < ttl) return cached;
      pending = (async () => {
        let ready = false;
        try {
          const { stdout } = await probe();
          ready = stdout.split(/\r?\n/).includes("MORPHIC_WORKER_READY");
        } catch {
          // Do not expose SSH details or classify an observation failure as a
          // completed/failed inference. This probe only gates new submissions.
        }
        cached = { ready, checkedAt: now() };
        return cached;
      })();
      try {
        return await pending;
      } finally {
        pending = undefined;
      }
    },
  };
}
