import "./article.css";
import * as THREE from "three";
import { specimen, SETTINGS, INITIAL } from "./behavior/fixture.js";
import {
  predict,
  deployAsset,
  makePhysicalAsset,
  score,
} from "./behavior/experiment.js";

const $ = (id) => document.getElementById(id);
const mm = (v) => (v * 1000).toFixed(2);
const { cage } = specimen();
const host = $("comparison");
let bundle;
try {
  const response = await fetch("./behavior/study.json");
  if (!response.ok)
    throw Error("Run npm run behavior:study to generate the experiment.");
  bundle = await response.json();
} catch (error) {
  $("comparison-note").textContent = error.message;
  throw error;
}
const { report } = bundle;
const originalProvenance = structuredClone(bundle.asset.provenance);
let fitted = deployAsset(cage, SETTINGS, bundle.asset);
const hero = report.rows.find((r) => r.case === "two-region" && r.seed === 1);
let curves = bundle.curves,
  running = false,
  elapsed = 0,
  last = 0;
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setScissorTest(true);
host.append(renderer.domElement);

// Extract the actual tetrahedral boundary; display vertices remain attached to node IDs.
const faceMap = new Map();
for (let t = 0; t < cage.tets.length; t += 4) {
  const ids = Array.from(cage.tets.slice(t, t + 4));
  for (const face of [
    [0, 2, 1],
    [0, 1, 3],
    [0, 3, 2],
    [1, 2, 3],
  ]) {
    const nodes = face.map((i) => ids[i]),
      key = nodes
        .slice()
        .sort((a, b) => a - b)
        .join(",");
    const previous = faceMap.get(key);
    faceMap.set(
      key,
      previous
        ? { ...previous, count: previous.count + 1 }
        : { nodes, count: 1 },
    );
  }
}
const surface = [...faceMap.values()]
  .filter((f) => f.count === 1)
  .flatMap((f) => f.nodes);
const panels = [0xbc643c, 0x687c91, 0x225cc2].map((color) => {
  const scene = new THREE.Scene(),
    camera = new THREE.PerspectiveCamera(31, 1, 0.01, 50);
  camera.position.set(1.12, 1.8, 1.5);
  camera.lookAt(0, 1.37, 0);
  scene.add(new THREE.HemisphereLight(0xffffff, 0x9099aa, 2.3));
  const light = new THREE.DirectionalLight(0xffffff, 2);
  light.position.set(2, 4, 3);
  scene.add(light);
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute(
    "position",
    new THREE.Float32BufferAttribute(new Float32Array(surface.length * 3), 3),
  );
  const colors = surface.flatMap((node) => {
    const stripe = Math.floor((cage.rest[node * 3 + 1] - 1) / 0.12) % 2;
    return new THREE.Color(stripe ? color : 0xe1e6ed).toArray();
  });
  geometry.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  const mesh = new THREE.Mesh(
    geometry,
    new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.75,
      side: THREE.DoubleSide,
    }),
  );
  scene.add(mesh);
  const handle = new THREE.Mesh(
    new THREE.SphereGeometry(0.015, 12, 8),
    new THREE.MeshStandardMaterial({ color: 0x172330 }),
  );
  scene.add(handle);
  const eg = new THREE.BufferGeometry();
  eg.setAttribute(
    "position",
    new THREE.Float32BufferAttribute(
      new Float32Array(cage.edges.length * 3),
      3,
    ),
  );
  const edges = new THREE.LineSegments(
    eg,
    new THREE.LineBasicMaterial({
      color: 0x23354c,
      transparent: true,
      opacity: 0.35,
    }),
  );
  scene.add(edges);
  const base = new THREE.Mesh(
    new THREE.BoxGeometry(0.38, 0.035, 0.38),
    new THREE.MeshStandardMaterial({ color: 0x465566 }),
  );
  base.position.set(0, 0.985, 0);
  scene.add(base);
  return { scene, camera, geometry, edges, handle };
});
function draw(index) {
  const width = host.clientWidth,
    height = host.clientHeight;
  if (
    renderer.domElement.width !==
      Math.round(width * renderer.getPixelRatio()) ||
    renderer.domElement.height !== Math.round(height * renderer.getPixelRatio())
  )
    renderer.setSize(width, height, false);
  const keys = ["reference", "preset", $("model").value];
  for (let i = 0; i < 3; i++) {
    const p = panels[i],
      frame = curves[keys[i]][index],
      x = frame.x;
    const actions = bundle[$("trial").value].events.filter(
      (e) => e.tick <= frame.tick,
    );
    const target = actions
      .filter((e) => ["grab", "move"].includes(e.action.type))
      .at(-1)?.action.target;
    p.handle.visible =
      !!target && !actions.some((e) => e.action.type === "release");
    if (target) p.handle.position.set(...target);
    surface.forEach((node, v) =>
      p.geometry.attributes.position.setXYZ(
        v,
        ...x.slice(node * 3, node * 3 + 3),
      ),
    );
    p.geometry.attributes.position.needsUpdate = true;
    p.geometry.computeVertexNormals();
    p.geometry.computeBoundingSphere();
    cage.edges.forEach((node, v) =>
      p.edges.geometry.attributes.position.setXYZ(
        v,
        ...x.slice(node * 3, node * 3 + 3),
      ),
    );
    p.edges.geometry.attributes.position.needsUpdate = true;
    p.edges.geometry.computeBoundingSphere();
    p.edges.visible = $("wire").checked;
    p.camera.aspect = width / 3 / height;
    p.camera.updateProjectionMatrix();
    renderer.setViewport((i * width) / 3, 0, width / 3, height);
    renderer.setScissor((i * width) / 3, 0, width / 3, height);
    renderer.render(p.scene, p.camera);
  }
  $("clock").textContent =
    (curves.reference[index].tick * SETTINGS.dt).toFixed(2) + " s";
  window.morphicBehavior = {
    frame: index,
    trial: $("trial").value,
    model: $("model").value,
    engine: bundle.asset.engine,
    source: bundle.asset.provenance.kind,
    replayError: report.replayMaxErrorM,
  };
  const cursor = $("plot-cursor");
  if (cursor) {
    const px = 45 + (index / 29) * 690;
    cursor.setAttribute("x1", px);
    cursor.setAttribute("x2", px);
  }
}
function refresh() {
  draw(Number($("time").value));
}
function updateCurves() {
  const trial = bundle[$("trial").value],
    ticks = trial.observations.map((f) => f.tick);
  const truth = { ...INITIAL, edge: [2e-5, 8e-4], damping: 3.2 };
  const factor = 10 ** Number($("edit").value);
  const edited = {
    ...fitted,
    edge: [fitted.edge[0], (fitted.edge[1] ?? fitted.edge[0]) / factor],
  };
  curves = Object.fromEntries(
    [
      ["reference", truth],
      ["preset", INITIAL],
      ["uniform", hero.uniform.field],
      ["regional", fitted],
      ["recorded", hero.regional.field],
      ["edited", edited],
    ].map(([name, field]) => [
      name,
      predict(
        cage,
        SETTINGS,
        field,
        { endTick: trial.endTick, events: trial.events },
        ticks,
      ).frames,
    ]),
  );
  $("edit-value").textContent = factor.toFixed(1) + "×";
  $("comparison-note").textContent =
    $("trial").value !== "train"
      ? "Held-out interaction: only its action enters the predictor. The clean synthetic reference is shown for comparison; noisy sparse points are used for scoring."
      : "Fitting interaction: agreement here is reconstruction. Switch to the held-out action to inspect prediction.";
  updatePlot();
  refresh();
}

function updatePlot() {
  const trial = bundle[$("trial").value];
  const values = ["preset", "uniform", "recorded"].map((key) =>
    trial.observations.map(
      (f, i) => score({ frames: [curves[key][i]] }, [f], cage).rmseM * 1000,
    ),
  );
  const max = Math.max(1, ...values.flat()) * 1.1;
  const paths = values
    .map(
      (v, i) =>
        `<polyline fill="none" stroke="${["#687c91", "#ae3674", "#225cc2"][i]}" stroke-width="2.5" points="${v.map((y, j) => `${45 + (j / 29) * 690},${140 - (y / max) * 110}`).join(" ")}"/>`,
    )
    .join("");
  $("error-plot").innerHTML =
    `<svg viewBox="0 0 780 180" role="img" aria-label="Point error over time in millimetres"><path d="M45 25V140H735" fill="none" stroke="#8795a6"/><text x="4" y="32">${max.toFixed(1)}</text><text x="23" y="145">0</text><text x="45" y="165">0.05 s</text><text x="692" y="165">1.50 s</text>${paths}<line id="plot-cursor" x1="45" x2="45" y1="25" y2="140" stroke="#202a34" stroke-dasharray="3 4"/></svg>`;
}
$("time").oninput = () => {
  running = false;
  $("play").textContent = "Play comparison";
  refresh();
};
$("play").onclick = () => {
  running = !running;
  elapsed = Number($("time").value) * 0.05;
  $("play").textContent = running ? "Pause comparison" : "Play comparison";
};
$("model").onchange = () => {
  $("model-label").textContent = {
    regional: "Fitted regional response",
    uniform: "Fitted uniform response",
    edited: "Intentional material edit",
  }[$("model").value];
  $("edit-control").hidden = $("model").value !== "edited";
  refresh();
};
$("trial").onchange = updateCurves;
$("edit").onchange = updateCurves;
$("wire").onchange = refresh;
new ResizeObserver(refresh).observe(host);
function animate(now) {
  if (running) {
    elapsed += Math.min((now - last) / 1000, 0.1);
    $("time").value = Math.floor((elapsed % 1.5) / 0.05);
    refresh();
  }
  last = now;
  requestAnimationFrame(animate);
}
requestAnimationFrame(animate);
function selectedAsset() {
  if ($("model").value === "edited")
    return makePhysicalAsset(
      cage,
      SETTINGS,
      {
        field: {
          ...fitted,
          edge: [
            fitted.edge[0],
            (fitted.edge[1] ?? fitted.edge[0]) / 10 ** Number($("edit").value),
          ],
        },
      },
      {
        kind: "intentional-material-edit",
        basedOn: bundle.asset.provenance,
        stiffnessMultiplier: 10 ** Number($("edit").value),
      },
    );
  return makePhysicalAsset(
    cage,
    SETTINGS,
    { field: $("model").value === "uniform" ? hero.uniform.field : fitted },
    $("model").value === "uniform"
      ? originalProvenance
      : bundle.asset.provenance,
  );
}
$("export").onclick = () => {
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(selectedAsset(), null, 2)], {
      type: "application/json",
    }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = "morphic-response.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  $("asset-status").textContent =
    "Physical asset exported with geometry, settings, and provenance.";
};
$("import").onclick = () => $("asset-file").click();
$("asset-file").onchange = async (e) => {
  try {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5e6) throw Error("Physical asset exceeds 5 MB.");
    const asset = JSON.parse(await file.text());
    fitted = deployAsset(cage, SETTINGS, asset);
    bundle.asset = asset;
    $("model").value = "regional";
    $("model").onchange();
    updateCurves();
    $("model-label").textContent = "Imported response";
    $("asset-status").textContent =
      "Loaded " +
      (asset.provenance?.kind ?? "unclassified response") +
      ". Recorded result tables remain the original experiment.";
  } catch (error) {
    $("asset-status").textContent = error.message;
  }
  e.target.value = "";
};
for (const row of report.rows) {
  const tr = document.createElement("tr");
  for (const value of [
    row.case,
    row.seed,
    mm(row.test.preset.rmseM),
    mm(row.test.uniform.rmseM),
    mm(row.test.regional.rmseM),
  ]) {
    const td = document.createElement("td");
    td.textContent = value;
    tr.append(td);
  }
  $("results").append(tr);
  if (row.testOther) {
    const other = document.createElement("tr");
    for (const value of [
      row.case,
      row.seed,
      mm(row.testOther.preset.rmseM),
      mm(row.testOther.uniform.rmseM),
      mm(row.testOther.regional.rmseM),
    ]) {
      const td = document.createElement("td");
      td.textContent = value;
      other.append(td);
    }
    $("other-results").append(other);
  }
}
const mean = (caseName, model) => {
  const values = report.rows
    .filter((r) => r.case === caseName)
    .map((r) => r.test[model].rmseM);
  return values.reduce((a, b) => a + b, 0) / values.length;
};
$("finding").textContent =
  `On the two-region specimen, mean held-out error falls from ${mm(mean("two-region", "preset"))} mm with the preset to ${mm(mean("two-region", "uniform"))} mm after uniform fitting, then ${mm(mean("two-region", "regional"))} mm after regional fitting. The uniform specimen reaches approximately the observation noise floor without needing a regional model.`;
const totalTimes = report.rows.map(
  (r) => (r.uniform.elapsedMs + r.regional.elapsedMs) / 1000,
);
$("timings").textContent =
  `Combined fitting time ranged from ${Math.min(...totalTimes).toFixed(1)} to ${Math.max(...totalTimes).toFixed(1)} seconds per case on ${report.environment.cpu}. This includes both optimization stages; it is not frame rate. Same-runtime exported action replay had ${report.replayMaxErrorM} m maximum position drift.`;
$("ablations").textContent =
  `Using only one marker per fitting frame leaves ${mm((report.sparseAblation.regionalTest ?? report.sparseAblation.test).rmseM)} mm held-out error. Changing the hidden bulk response alone produces ${mm(report.mismatch.rmseM)} mm error: this bending trial is a weak probe of bulk response, so it does not establish bulk identifiability.`;
if (report.wrongMass)
  $("ablations").textContent +=
    ` Doubling the hidden mass while retaining the fitted model gives ${mm(report.wrongMass.rmseM)} mm error, exposing sensitivity to the assumed mass.`;
$("sensitivity").textContent =
  `Keeping the fitted coefficients fixed while changing the solve budget gives ${report.sensitivity.map((s) => mm(s.rmseM) + " mm at " + s.iterations + " iterations").join(", ")}. More iterations do not preserve the fit automatically. These coefficients explain a particular discrete simulator; they are not resolution-independent material constants.`;
if (report.timestepSensitivity)
  $("sensitivity").textContent +=
    ` Halving the timestep with the same physical action times gives ${mm(report.timestepSensitivity.rmseM)} mm error.`;
updateCurves();
