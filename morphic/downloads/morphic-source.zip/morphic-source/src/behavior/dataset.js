import { buildCage } from "../physics/cage.js";
import { validateTrial } from "./experiment.js";
import { knownCage } from "./known-cage.js";

export function readDataset(data) {
  if (
    data?.schema !== 1 ||
    data.units !== "m-kg-s" ||
    !["measured", "synthetic"].includes(data.origin) ||
    !data.provenance?.source ||
    !data.provenance?.loading ||
    !data.provenance?.scale ||
    !data.settings ||
    !Array.isArray(data.trials)
  )
    throw Error(
      "Dataset requires SI units, origin, and source/scale/loading provenance.",
    );
  const { vertices, triangles, resolution, tetrahedra, h } =
    data.geometry ?? {};
  if (!Array.isArray(vertices) || !Array.isArray(triangles))
    throw Error("Missing known geometry.");
  // Validate original values before integer conversion can silently truncate them.
  if (
    !triangles.every(
      (v) => Number.isInteger(v) && v >= 0 && v < vertices.length / 3,
    )
  )
    throw Error("Invalid geometry indices.");
  const cage = tetrahedra
    ? knownCage(vertices, tetrahedra, h)
    : buildCage(
        Float64Array.from(vertices),
        Uint32Array.from(triangles),
        resolution,
      );
  data.trials.forEach((t) => validateTrial(cage, t));
  const fit = data.trials.filter((t) => t.role === "fit"),
    test = data.trials.filter((t) => t.role === "test");
  if (!fit.length || !test.length)
    throw Error("Separate fitting and test trials are required.");
  const ids = data.trials.map((t) => t.id);
  if (
    ids.some((v) => typeof v !== "string" || !v) ||
    new Set(ids).size !== ids.length
  )
    throw Error("Trial IDs must be unique.");
  return { cage, fit, test, settings: data.settings };
}
