import { Solver } from "../physics/solver.js";
import { record, makeSession, replay } from "../physics/session.js";
import { validateField } from "../physics/material-field.js";

export const RESPONSE_ENGINE = "morphic-response-1";

export function validateTrial(cage, trial) {
  const n = cage.rest.length / 3;
  if (
    !trial ||
    !["fit", "test"].includes(trial.role) ||
    !Number.isInteger(trial.endTick) ||
    trial.endTick < 1 ||
    trial.endTick > 3600 ||
    !Array.isArray(trial.events) ||
    trial.events.length > 10000 ||
    !Array.isArray(trial.observations) ||
    !trial.observations.length
  )
    throw Error("Invalid observation trial.");
  let tick = -1;
  for (const e of trial.events) {
    if (
      !Number.isInteger(e.tick) ||
      e.tick < tick ||
      e.tick >= trial.endTick ||
      !["pin", "unpin", "grab", "move", "release"].includes(e.action?.type)
    )
      throw Error(
        "Trial actions must be ordered loading inputs, not material changes.",
      );
    tick = e.tick;
  }
  tick = -1;
  for (const f of trial.observations) {
    if (
      !Number.isInteger(f.tick) ||
      f.tick <= tick ||
      f.tick > trial.endTick ||
      !Array.isArray(f.points) ||
      !f.points.length
    )
      throw Error("Observations must have strictly increasing frame ticks.");
    tick = f.tick;
    const ids = new Set();
    for (const p of f.points) {
      const key = p.vertex === undefined ? `n${p.node}` : `v${p.vertex}`;
      const validNode =
        p.vertex === undefined &&
        Number.isInteger(p.node) &&
        p.node >= 0 &&
        p.node < n;
      const validVertex =
        p.node === undefined &&
        Number.isInteger(p.vertex) &&
        p.vertex >= 0 &&
        p.vertex < cage.bindNodes.length / 4;
      if (
        !(validNode || validVertex) ||
        ids.has(key) ||
        !Array.isArray(p.position) ||
        p.position.length !== 3 ||
        !p.position.every(Number.isFinite) ||
        (p.weight !== undefined &&
          (!Number.isFinite(p.weight) || p.weight <= 0))
      )
        throw Error("Invalid or duplicate observed point.");
      ids.add(key);
    }
  }
  return trial;
}

// Prediction consumes loading and initial rest geometry only. It never reads motion.
export function predict(cage, settings, field, loading, sampleTicks) {
  const solver = new Solver(cage, settings);
  record(solver, { type: "response", field: validateField(field) });
  const frames = [],
    wanted = new Set(sampleTicks);
  let ei = 0;
  for (let tick = 0; tick <= loading.endTick; tick++) {
    while (ei < loading.events.length && loading.events[ei].tick === tick)
      record(solver, loading.events[ei++].action);
    if (wanted.has(tick)) frames.push({ tick, x: Array.from(solver.x) });
    if (tick < loading.endTick) solver.step();
    if (solver.fault) throw Error(solver.fault);
  }
  return {
    frames,
    limitedSteps: solver.limitedSteps,
    session: makeSession(solver),
  };
}

export function score(prediction, observations, cage) {
  const frames = new Map(prediction.frames.map((f) => [f.tick, f.x]));
  let sum = 0,
    weight = 0,
    max = 0;
  for (const f of observations) {
    const x = frames.get(f.tick);
    if (!x) throw Error("Missing predicted observation time.");
    for (const p of f.points) {
      const position =
        p.vertex === undefined
          ? x.slice(p.node * 3, p.node * 3 + 3)
          : [0, 1, 2].map((axis) =>
              [0, 1, 2, 3].reduce(
                (sum, j) =>
                  sum +
                  cage.weights[p.vertex * 4 + j] *
                    x[cage.bindNodes[p.vertex * 4 + j] * 3 + axis],
                0,
              ),
            );
      const d2 = p.position.reduce((s, q, a) => s + (q - position[a]) ** 2, 0);
      sum += d2 * (p.weight ?? 1);
      weight += p.weight ?? 1;
      max = Math.max(max, Math.sqrt(d2));
    }
  }
  if (!weight) throw Error("No observed points.");
  return { rmseM: Math.sqrt(sum / weight), maxM: max, pointCount: weight };
}

export function evaluate(cage, settings, field, trial) {
  validateTrial(cage, trial);
  const prediction = predict(
    cage,
    settings,
    field,
    { endTick: trial.endTick, events: trial.events },
    trial.observations.map((f) => f.tick),
  );
  return {
    ...score(prediction, trial.observations, cage),
    limitedSteps: prediction.limitedSteps,
  };
}

// Bounded pattern search in log compliance and log damping. No autodiff or upstream code.
// The API deliberately accepts training trials only; test motion cannot select a model.
export function fitResponse(
  cage,
  settings,
  training,
  initial,
  { regional = false, rounds = 9 } = {},
) {
  if (!training.length || training.some((t) => t.role !== "fit"))
    throw Error(
      "Fitting accepts fit trials only; held-out motion is forbidden.",
    );
  training.forEach((t) => validateTrial(cage, t));
  validateField(initial);
  const start = performance.now(),
    history = [];
  const decode = (p) => ({
    ...initial,
    edge: regional ? [10 ** p[0], 10 ** p[1]] : [10 ** p[0]],
    damping: 10 ** p.at(-1),
  });
  const loss = (p) => {
    const field = decode(p);
    const scores = training.map((t) => evaluate(cage, settings, field, t));
    // Reject clipped dynamics: a limiter is not an explanation of an observation.
    const value = scores.some((s) => s.limitedSteps)
      ? Infinity
      : scores.reduce((v, s) => v + s.rmseM ** 2, 0) / scores.length;
    history.push({
      parameters: p.slice(),
      mse: Number.isFinite(value) ? value : null,
    });
    return value;
  };
  let p = regional
    ? [
        Math.log10(initial.edge[0]),
        Math.log10(initial.edge[1] ?? initial.edge[0]),
        Math.log10(Math.max(initial.damping, 0.05)),
      ]
    : [
        Math.log10(initial.edge[0]),
        Math.log10(Math.max(initial.damping, 0.05)),
      ];
  let best = loss(p),
    step = 0.8;
  for (let round = 0; round < rounds; round++) {
    let improved = false;
    for (let axis = 0; axis < p.length; axis++) {
      let next = p;
      for (const sign of [-1, 1]) {
        const q = p.slice();
        q[axis] = Math.max(
          axis === p.length - 1 ? -1.3 : -8,
          Math.min(
            axis === p.length - 1 ? Math.log10(30) : -1,
            q[axis] + sign * step,
          ),
        );
        const value = loss(q);
        if (value < best) {
          best = value;
          next = q;
          improved = true;
        }
      }
      p = next;
    }
    if (!improved) step *= 0.5;
  }
  if (!Number.isFinite(best))
    throw Error("All candidate rollouts clipped or failed.");
  return {
    field: decode(p),
    trainRmseM: Math.sqrt(best),
    evaluations: history.length,
    elapsedMs: performance.now() - start,
    history,
  };
}

export function makePhysicalAsset(cage, settings, fit, provenance) {
  return {
    schema: 1,
    engine: RESPONSE_ENGINE,
    units: "m-kg-s",
    geometry: {
      rest: Array.from(cage.rest),
      tets: Array.from(cage.tets),
      edges: Array.from(cage.edges),
      h: cage.h,
    },
    settings: structuredClone(settings),
    field: validateField(fit.field),
    provenance: structuredClone(provenance),
  };
}

export function deployAsset(cage, settings, asset) {
  if (
    asset?.schema !== 1 ||
    asset.engine !== RESPONSE_ENGINE ||
    asset.units !== "m-kg-s"
  )
    throw Error("Unsupported physical asset.");
  const expected = makePhysicalAsset(
    cage,
    settings,
    { field: asset.field },
    {},
  ).geometry;
  if (
    JSON.stringify(expected) !== JSON.stringify(asset.geometry) ||
    JSON.stringify(settings) !== JSON.stringify(asset.settings)
  )
    throw Error(
      "Physical asset geometry or solver settings differ; refit is required.",
    );
  return validateField(asset.field);
}

export function verifyReplay(cage, prediction) {
  const result = replay(cage, prediction.session);
  return Math.max(
    ...result.x.map((x, i) =>
      Math.abs(x - prediction.session.finalPositions[i]),
    ),
  );
}
