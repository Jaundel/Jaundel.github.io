import { volume } from "../physics/math.js";
import { predict } from "./experiment.js";

export function specimen() {
  // Exact known geometry removes scan-envelope uncertainty from identification.
  const h = 0.12,
    vertices = [],
    tets = [];
  const index = (x, y, z) => (x * 7 + y) * 3 + z;
  for (let x = 0; x <= 2; x++)
    for (let y = 0; y <= 6; y++)
      for (let z = 0; z <= 2; z++)
        vertices.push(-0.12 + x * h, 1 + y * h, -0.12 + z * h);
  const permutations = [
    [0, 1, 2],
    [0, 2, 1],
    [1, 0, 2],
    [1, 2, 0],
    [2, 0, 1],
    [2, 1, 0],
  ];
  for (let x = 0; x < 2; x++)
    for (let y = 0; y < 6; y++)
      for (let z = 0; z < 2; z++)
        for (const p of permutations) {
          const c = [x, y, z],
            tet = [index(...c)];
          for (const a of p) {
            c[a]++;
            tet.push(index(...c));
          }
          if (volume(vertices, ...tet) < 0) [tet[1], tet[2]] = [tet[2], tet[1]];
          tets.push(...tet);
        }
  const edges = new Map(),
    faces = new Map();
  for (let t = 0; t < tets.length; t += 4) {
    const ids = tets.slice(t, t + 4);
    for (let i = 0; i < 4; i++)
      for (let j = i + 1; j < 4; j++) {
        const e = [ids[i], ids[j]].sort((a, b) => a - b);
        edges.set(e.join(","), e);
      }
    for (const f of [
      [0, 2, 1],
      [0, 1, 3],
      [0, 3, 2],
      [1, 2, 3],
    ]) {
      const nodes = f.map((i) => ids[i]),
        key = nodes
          .slice()
          .sort((a, b) => a - b)
          .join(",");
      if (faces.has(key)) faces.get(key).count++;
      else faces.set(key, { nodes, count: 1 });
    }
  }
  const triangles = Uint32Array.from(
    [...faces.values()].filter((f) => f.count === 1).flatMap((f) => f.nodes),
  );
  const rest = Float64Array.from(vertices);
  const bindNodes = Uint32Array.from(
    { length: (rest.length / 3) * 4 },
    (_, i) => Math.floor(i / 4),
  );
  const weights = Float64Array.from(bindNodes, (_, i) => (i % 4 === 0 ? 1 : 0));
  const cage = {
    rest,
    tets: Uint32Array.from(tets),
    edges: Uint32Array.from([...edges.values()].flat()),
    bindNodes,
    weights,
    h,
    volume: 0.24 * 0.72 * 0.24,
    cellCount: 24,
  };
  return { vertices: rest, triangles, cage };
}

export const SETTINGS = {
  dt: 1 / 120,
  iterations: 12,
  density: 100,
  gravity: 0,
};
export const INITIAL = {
  edge: [2e-4],
  bulk: 2e-7,
  damping: 1.5,
  friction: 0,
  axis: 1,
  split: 1.36,
};

export function loading(
  cage,
  { axis = 0, amplitude = 0.055, endTick = 180, node } = {},
) {
  if (node === undefined) {
    node = 0;
    for (let i = 1; i < cage.rest.length / 3; i++)
      if (cage.rest[i * 3 + 1] > cage.rest[node * 3 + 1]) node = i;
  }
  const origin = Array.from(cage.rest.slice(node * 3, node * 3 + 3));
  const events = [
    { tick: 0, action: { type: "pin" } },
    { tick: 0, action: { type: "grab", node, target: origin.slice() } },
  ];
  for (let tick = 1; tick <= 65; tick++) {
    const target = origin.slice();
    target[axis] +=
      amplitude * Math.sin((Math.min(tick / 40, 1) * Math.PI) / 2);
    events.push({ tick, action: { type: "move", target } });
  }
  events.push({ tick: 66, action: { type: "release" } });
  return { endTick, events };
}

// Synthetic fixtures are isolated from fitting. Their hidden coefficients never enter fitResponse.
export function observe(
  cage,
  settings,
  field,
  input,
  { role = "fit", noiseM = 0, seed = 1, stride = 3 } = {},
) {
  let state = seed >>> 0;
  const random = () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state / 2 ** 32;
  };
  const ticks = Array.from(
    { length: Math.floor(input.endTick / 6) },
    (_, i) => (i + 1) * 6,
  );
  const sim = predict(cage, settings, field, input, ticks);
  const controlled = input.events.find((e) => e.action.type === "grab")?.action
    .node;
  const minY = Math.min(...Array.from(cage.rest).filter((_, i) => i % 3 === 1));
  const observations = sim.frames.map((f) => ({
    tick: f.tick,
    points: Array.from({ length: cage.rest.length / 3 }, (_, node) => node)
      .filter(
        (node) =>
          node % stride === 0 &&
          node !== controlled &&
          cage.rest[node * 3 + 1] > minY + cage.h * 0.6,
      )
      .map((node) => ({
        node,
        position: f.x
          .slice(node * 3, node * 3 + 3)
          .map((q) => q + (random() * 2 - 1) * Math.sqrt(3) * noiseM),
      })),
  }));
  return {
    id: `${role}-axis${input.events[2].action.target[0] !== input.events[1].action.target[0] ? 0 : 2}-seed${seed}`,
    role,
    origin: "synthetic XPBD observations",
    noiseM,
    ...input,
    observations,
  };
}
