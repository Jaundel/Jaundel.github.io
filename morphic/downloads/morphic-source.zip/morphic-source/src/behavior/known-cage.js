import { volume } from "../physics/math.js";

export function knownCage(vertices, tetrahedra, h) {
  if (
    !Array.isArray(vertices) ||
    vertices.length < 12 ||
    vertices.length > 15000 ||
    vertices.length % 3 ||
    !vertices.every(Number.isFinite) ||
    !Array.isArray(tetrahedra) ||
    !tetrahedra.length ||
    tetrahedra.length > 120000 ||
    tetrahedra.length % 4 ||
    !tetrahedra.every(
      (i) => Number.isInteger(i) && i >= 0 && i < vertices.length / 3,
    ) ||
    !Number.isFinite(h) ||
    h <= 0
  )
    throw Error("Invalid known tetrahedral geometry.");
  const rest = Float64Array.from(vertices),
    tets = Uint32Array.from(tetrahedra),
    edges = new Map();
  let total = 0;
  const used = new Set();
  for (let t = 0; t < tets.length; t += 4) {
    const ids = Array.from(tets.slice(t, t + 4)),
      v = volume(rest, ...ids);
    if (!(v > 1e-14))
      throw Error("Known tetrahedra must have positive volume.");
    total += v;
    ids.forEach((id) => used.add(id));
    for (let i = 0; i < 4; i++)
      for (let j = i + 1; j < 4; j++) {
        const e = [ids[i], ids[j]].sort((a, b) => a - b);
        edges.set(e.join(","), e);
      }
  }
  if (used.size !== rest.length / 3)
    throw Error("Known mesh has unconnected nodes.");
  const bindNodes = Uint32Array.from(
    { length: (rest.length / 3) * 4 },
    (_, i) => Math.floor(i / 4),
  );
  const weights = Float64Array.from(bindNodes, (_, i) => (i % 4 === 0 ? 1 : 0));
  return {
    rest,
    tets,
    edges: Uint32Array.from([...edges.values()].flat()),
    bindNodes,
    weights,
    h,
    volume: total,
  };
}
