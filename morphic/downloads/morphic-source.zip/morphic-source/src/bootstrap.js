const params = new URLSearchParams(location.search);
if (
  params.get("mode") === "measured" ||
  (params.get("mode") !== "capture" && !params.has("asset"))
) {
  await import("./measured-studio.js");
} else {
  await import("./main.js");
}
