import {
  validateCaptureFiles,
  prepareCaptureProject,
  saveCaptureProject,
  listCaptureProjects,
  loadCaptureFiles,
  validateCaptureReview,
} from "./io/capture-project.js";
import { validateReconstructionResult } from "./io/reconstruction-result.js";
// Capture review is local. Reconstruction must explicitly supply a real asset.
export function mountCaptureFlow(onReconstructed) {
  const dialog = document.getElementById("capture-dialog");
  const input = document.getElementById("capture-files");
  const feedback = document.getElementById("capture-feedback");
  const previews = document.getElementById("capture-previews");
  const selection = document.getElementById("capture-selection");
  let candidates = [];
  let urls = [];
  let revision = 0;
  let reviewedFiles = [];
  let views = [];
  let computing = false;
  let saving = false;
  let gpuAvailable = false;
  const create = document.getElementById("capture-create");
  const computeStatus = document.getElementById("capture-compute");
  const endpoint = "/__morphic_reconstruction/";
  const localStudio = ["127.0.0.1", "localhost"].includes(location.hostname);
  async function refreshCompute() {
    gpuAvailable = false;
    if (!computing && !saving) {
      create.disabled = true;
      computeStatus.textContent = "Checking GPU connection…";
    }
    let message =
      "No personal GPU connected. Review and save your capture here, or follow the setup guide to create a new object.";
    if (!localStudio) {
      computeStatus.textContent = message;
      return;
    }
    try {
      const response = await fetch(endpoint);
      const state = await response.json();
      gpuAvailable = response.ok && state.available && !state.busy;
      if (response.ok && typeof state.message === "string")
        message = state.message;
    } catch {
      gpuAvailable = false;
    }
    if (!computing && !saving) {
      create.disabled = !gpuAvailable || !views.length;
      computeStatus.textContent = message;
    }
  }
  async function openJob(id) {
    const started = Date.now();
    for (;;) {
      if (Date.now() - started > 20 * 60_000)
        throw Error(
          "Still waiting for the GPU. Do not resubmit; check the existing job.",
        );
      const response = await fetch(endpoint + id);
      const state = await response.json();
      if (
        !response.ok ||
        ["failed", "interrupted", "invalid"].includes(state.stage)
      )
        throw Error(state.error ?? "Reconstruction failed.");
      if (state.stage === "completed") break;
      computeStatus.textContent = `Creating your object: ${state.stage}. You can keep this window open while it works.`;
      await new Promise((resolve) => setTimeout(resolve, 2000));
    }
    const [assetResponse, reportResponse] = await Promise.all([
      fetch(endpoint + id + "/asset"),
      fetch(endpoint + id + "/report"),
    ]);
    if (!assetResponse.ok || !reportResponse.ok)
      throw Error("Could not retrieve the completed object.");
    const buffer = await assetResponse.arrayBuffer();
    const provenance = await validateReconstructionResult(
      await reportResponse.json(),
      buffer,
    );
    await onReconstructed(buffer, provenance);
    computeStatus.textContent =
      "Object reconstructed. Its hidden surfaces and physical behavior remain unverified.";
    dialog.close();
  }
  create.onclick = async () => {
    if (computing || saving || !views.length) return;
    computing = true;
    create.disabled = save.disabled = input.disabled = true;
    try {
      await saveCaptureProject(
        await prepareCaptureProject(reviewedFiles, currentReview()),
      );
      computeStatus.textContent = "Sending selected views to your GPU worker…";
      const submitted = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ images: views }),
      });
      const job = await submitted.json();
      if (!submitted.ok)
        throw Error(job.error ?? "Could not submit reconstruction.");
      await openJob(job.id);
    } catch (error) {
      computeStatus.textContent = error.message;
    } finally {
      computing = false;
      input.disabled = false;
      save.disabled = !reviewedFiles.length;
      // Explicit reopening refreshes availability without erasing the outcome.
    }
  };
  const save = document.getElementById("capture-save");
  const saved = document.getElementById("capture-saved");
  const storageStatus = document.getElementById("capture-storage-status");
  async function refreshJobs() {
    const history = document.getElementById("capture-jobs");
    history.replaceChildren();
    if (!localStudio) {
      history.textContent =
        "Created objects are saved by your local studio. Open a downloaded session to use it here.";
      return;
    }
    try {
      const response = await fetch(endpoint + "jobs");
      if (!response.ok) throw Error("Reconstruction history is unavailable.");
      const jobs = await response.json();
      for (const [index, job] of jobs.entries()) {
        const row = document.createElement("div");
        const button = document.createElement("button");
        button.textContent = `${job.stage === "completed" ? "Open" : "Check"} object ${index + 1}`;
        button.disabled = ["invalid", "failed"].includes(job.stage);
        const status = document.createElement("span");
        status.textContent = ` (${job.stage})`;
        row.append(button, status);
        if (job.error) {
          const note = document.createElement("p");
          note.textContent = job.error;
          row.append(note);
        }
        button.onclick = async () => {
          if (computing || saving) return;
          computing = true;
          create.disabled = input.disabled = save.disabled = true;
          try {
            if (job.stage === "interrupted") {
              const checked = await fetch(endpoint + job.id + "/recover", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: "{}",
              });
              const result = await checked.json();
              if (!checked.ok || result.stage !== "completed")
                throw Error(
                  result.error ??
                    "The existing job is still running. Check again later; do not resubmit.",
                );
            }
            await openJob(job.id);
          } catch (error) {
            computeStatus.textContent = error.message;
          } finally {
            computing = false;
            input.disabled = false;
            save.disabled = !reviewedFiles.length;
            await refreshJobs();
          }
        };
        history.append(row);
      }
      if (!jobs.length)
        history.textContent =
          "No reconstructed objects saved by this local server yet.";
    } catch (error) {
      history.textContent = error.message;
    }
  }

  async function refreshSaved() {
    saved.replaceChildren();
    try {
      for (const project of await listCaptureProjects()) {
        const button = document.createElement("button");
        button.textContent = `${project.name} — ${project.sources.length} source(s)`;
        button.onclick = async () => {
          if (computing || saving) return;
          try {
            await review(await loadCaptureFiles(project.id), project.review);
          } catch (error) {
            storageStatus.textContent = error.message;
          }
        };
        saved.append(button);
      }
    } catch {
      storageStatus.textContent =
        "Browser storage is unavailable. You can still review files.";
    }
  }
  save.onclick = async () => {
    if (saving || computing) return;
    const files = [...reviewedFiles];
    if (!files.length) return;
    save.disabled = true;
    input.disabled = true;
    saving = true;
    create.disabled = true;
    previews
      .querySelectorAll("button")
      .forEach((button) => (button.disabled = true));
    storageStatus.textContent = "Saving original files on this device…";
    try {
      await saveCaptureProject(
        await prepareCaptureProject(files, currentReview()),
      );
      storageStatus.textContent =
        "Capture and selected views saved in this browser. Keep your originals; clearing browser data removes saved captures.";
      await refreshSaved();
    } catch (error) {
      storageStatus.textContent = `Could not save capture: ${error.message}. Keep the original files and try again.`;
      save.disabled = false;
    } finally {
      input.disabled = false;
      saving = false;
      create.disabled = computing || !gpuAvailable || !views.length;
      previews
        .querySelectorAll("button")
        .forEach((button) => (button.disabled = false));
    }
  };
  const clear = () => {
    urls.forEach(URL.revokeObjectURL);
    urls = [];
    previews.replaceChildren();
    candidates = [];
    selection.textContent = "";
  };
  function updateSelection() {
    views = candidates
      .filter((item) => item.selected)
      .map((item) => {
        if (!item.data) {
          const canvas = document.createElement("canvas");
          const scale = Math.min(
            1,
            768 / Math.max(item.image.naturalWidth, item.image.naturalHeight),
          );
          canvas.width = Math.max(
            1,
            Math.round(item.image.naturalWidth * scale),
          );
          canvas.height = Math.max(
            1,
            Math.round(item.image.naturalHeight * scale),
          );
          canvas
            .getContext("2d")
            .drawImage(item.image, 0, 0, canvas.width, canvas.height);
          item.data = canvas.toDataURL("image/png");
        }
        return item.data;
      });
    for (const item of candidates)
      item.button.setAttribute("aria-pressed", String(item.selected));
    selection.textContent = `${views.length} of ${candidates.length} views selected. Tap a view to include or exclude it. Choose up to 12 clear, overlapping views.`;
    create.disabled = computing || !gpuAvailable || !views.length;
  }
  function currentReview() {
    return {
      recipe: reviewedFiles[0].type.startsWith("video/")
        ? "video-midpoints-12-v1"
        : "photos-source-order-v1",
      selectedIndices: candidates.flatMap((item, index) =>
        item.selected ? [index] : [],
      ),
    };
  }
  function showCandidates(savedReview) {
    const count = Math.min(12, candidates.length);
    const defaults = Array.from({ length: count }, (_, i) =>
      count === 1 ? 0 : Math.round((i * (candidates.length - 1)) / (count - 1)),
    );
    const restored = validateCaptureReview(
      savedReview,
      validateCaptureFiles(reviewedFiles),
      reviewedFiles.length,
    );
    const selected = new Set(restored ? restored.selectedIndices : defaults);
    candidates.forEach((item, index) => {
      item.selected = selected.has(index);
      item.button = document.createElement("button");
      item.button.type = "button";
      item.button.className = "capture-view";
      item.button.setAttribute(
        "aria-label",
        `Use view ${index + 1}: ${item.image.alt}`,
      );
      const label = document.createElement("span");
      label.textContent = `View ${index + 1}`;
      item.button.append(item.image, label);
      item.button.onclick = () => {
        if (computing || saving) return;
        if (!item.selected && views.length >= 12) {
          selection.textContent =
            "12 views selected. Exclude one before adding another.";
          return;
        }
        item.selected = !item.selected;
        updateSelection();
        save.disabled = false;
      };
      previews.append(item.button);
    });
    updateSelection();
  }
  document.getElementById("capture-open").onclick = () => {
    dialog.showModal();
    refreshSaved();
    refreshCompute();
    refreshJobs();
  };
  if (new URLSearchParams(location.search).get("capture") === "1")
    document.getElementById("capture-open").click();
  input.onchange = () => review([...input.files]);
  async function review(files, savedReview) {
    const current = ++revision;
    clear();
    reviewedFiles = [];
    views = [];
    create.disabled = true;
    save.disabled = true;
    try {
      validateCaptureFiles(files);
    } catch (error) {
      feedback.textContent = error.message;
      return;
    }
    const videos = files.filter((file) => file.type.startsWith("video/"));
    feedback.textContent = "Reading your capture…";
    try {
      if (videos.length) {
        const url = URL.createObjectURL(videos[0]);
        urls.push(url);
        const video = document.createElement("video");
        video.muted = true;
        video.preload = "auto";
        await mediaEvent(video, "loadedmetadata", () => {
          video.src = url;
        });
        if (
          !Number.isFinite(video.duration) ||
          video.duration <= 0 ||
          video.duration > 120
        )
          throw Error(
            "Use a video shorter than two minutes with a readable duration.",
          );
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(
          1,
          Math.round(
            video.videoWidth *
              Math.min(1, 768 / Math.max(video.videoWidth, video.videoHeight)),
          ),
        );
        canvas.height = Math.max(
          1,
          Math.round((canvas.width * video.videoHeight) / video.videoWidth),
        );
        try {
          for (let i = 0; i < 12; i++) {
            if (current !== revision) return;
            await mediaEvent(video, "seeked", () => {
              video.currentTime = (video.duration * (i + 0.5)) / 12;
            });
            canvas
              .getContext("2d")
              .drawImage(video, 0, 0, canvas.width, canvas.height);
            if (current !== revision) return;
            const image = new Image();
            image.src = canvas.toDataURL("image/png");
            image.alt = `Video sample ${i + 1}`;
            candidates.push({ image, data: image.src });
          }
        } finally {
          video.removeAttribute("src");
          video.load();
        }
        feedback.textContent =
          "12 frames sampled for reconstruction. Check that the object stays still and each view is sharp.";
      } else {
        for (const file of files) {
          if (!/^image\/(jpeg|png|webp)$/.test(file.type))
            throw Error("Use JPEG, PNG or WebP photos.");
          const url = URL.createObjectURL(file);
          urls.push(url);
          const image = new Image();
          image.src = url;
          image.alt = file.name;
          await image.decode();
          if (current !== revision) return;
          candidates.push({ image });
        }
        feedback.textContent = `${files.length} ${files.length === 1 ? "photo" : "photos"} ready for review. Keep the object still and cover its sides.`;
      }
      if (current === revision) {
        reviewedFiles = files;
        showCandidates(savedReview);
        save.disabled = false;
      }
    } catch (error) {
      if (current === revision) {
        clear();
        views = [];
        feedback.textContent = error.message;
      }
    }
  }
}

function mediaEvent(media, name, start) {
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      clearTimeout(timer);
      media.removeEventListener(name, done);
      media.removeEventListener("error", fail);
    };
    const done = () => {
      cleanup();
      resolve();
    };
    const fail = () => {
      cleanup();
      reject(Error("Could not read this video. Try MP4 or WebM."));
    };
    const timer = setTimeout(fail, 15000);
    media.addEventListener(name, done, { once: true });
    media.addEventListener("error", fail, { once: true });
    start();
  });
}
