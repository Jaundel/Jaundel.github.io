const imageTypes = new Set(["image/jpeg", "image/png", "image/webp"]);
const videoTypes = new Set(["video/mp4", "video/webm", "video/quicktime"]);

export function validateCaptureFiles(files) {
  if (!files.length) throw Error("Choose photos or one video.");
  if (
    files.length > 80 ||
    files.reduce((sum, file) => sum + file.size, 0) > 300 * 1024 * 1024
  )
    throw Error(
      "Choose up to 80 photos or one video, totaling less than 300 MB.",
    );
  if (files.some((file) => !file.size))
    throw Error("One of these files is empty. Choose the original capture.");
  if (
    files.some(
      (file) => !imageTypes.has(file.type) && !videoTypes.has(file.type),
    )
  )
    throw Error("Use JPEG, PNG or WebP photos, or an MP4, WebM or MOV video.");
  const videos = files.filter((file) => videoTypes.has(file.type));
  if (videos.length && files.length !== 1)
    throw Error("Choose one video, or a set of photos, in separate captures.");
  return videos.length ? "video" : "photos";
}

export function validateCaptureReview(review, kind, sourceCount) {
  if (review === undefined) return undefined; // Older saved captures used defaults.
  const recipe =
    kind === "video" ? "video-midpoints-12-v1" : "photos-source-order-v1";
  const count = kind === "video" ? 12 : sourceCount;
  if (
    !review ||
    review.recipe !== recipe ||
    !Array.isArray(review.selectedIndices) ||
    review.selectedIndices.length > 12 ||
    new Set(review.selectedIndices).size !== review.selectedIndices.length ||
    review.selectedIndices.some(
      (index) => !Number.isInteger(index) || index < 0 || index >= count,
    )
  )
    throw Error(
      "This saved view selection is invalid or uses an unsupported sampling method. Choose the original files again.",
    );
  return {
    recipe,
    selectedIndices: [...review.selectedIndices].sort((a, b) => a - b),
  };
}

export async function prepareCaptureProject(files, review) {
  const kind = validateCaptureFiles(files);
  const savedReview = validateCaptureReview(review, kind, files.length);
  const sources = [];
  for (const file of files) {
    const hash = await crypto.subtle.digest(
      "SHA-256",
      await file.arrayBuffer(),
    );
    sources.push({
      name: file.name,
      type: file.type,
      size: file.size,
      sha256: [...new Uint8Array(hash)]
        .map((byte) => byte.toString(16).padStart(2, "0"))
        .join(""),
    });
  }
  return {
    id: crypto.randomUUID(),
    version: 1,
    createdAt: new Date().toISOString(),
    name: files[0].name,
    kind,
    state: "captured",
    sources,
    files: [...files],
    ...(savedReview ? { review: savedReview } : {}),
  };
}

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("morphic-captures", 1);
    request.onupgradeneeded = () => {
      request.result.createObjectStore("metadata", { keyPath: "id" });
      request.result.createObjectStore("sources", { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveCaptureProject(project) {
  const database = await openDatabase();
  try {
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(
        ["metadata", "sources"],
        "readwrite",
      );
      const { files, ...metadata } = project;
      transaction.objectStore("metadata").add(metadata);
      transaction.objectStore("sources").add({ id: project.id, files });
      transaction.oncomplete = resolve;
      transaction.onabort = () =>
        reject(transaction.error || Error("Capture storage was interrupted."));
      transaction.onerror = () => {}; // onabort reports the rolled-back transaction.
    });
  } finally {
    database.close();
  }
}

async function readStore(store, id) {
  const database = await openDatabase();
  try {
    return await new Promise((resolve, reject) => {
      const transaction = database.transaction(store, "readonly");
      const request = id
        ? transaction.objectStore(store).get(id)
        : transaction.objectStore(store).getAll();
      transaction.oncomplete = () => resolve(request.result);
      transaction.onabort = () => reject(transaction.error);
      request.onerror = () => reject(request.error);
    });
  } finally {
    database.close();
  }
}

export async function listCaptureProjects() {
  return (await readStore("metadata")).sort((a, b) =>
    b.createdAt.localeCompare(a.createdAt),
  );
}

export async function loadCaptureFiles(id) {
  const record = await readStore("sources", id);
  if (!record)
    throw Error(
      "This capture is no longer in this browser. Choose the original files again.",
    );
  validateCaptureFiles(record.files);
  return record.files;
}
