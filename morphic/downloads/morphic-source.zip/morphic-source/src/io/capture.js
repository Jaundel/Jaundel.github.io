import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { Group, Matrix4 } from "three";
import { inspectGLB, normalizeVertices } from "./glb.js";

export async function loadCapture(buffer, { normalize = true } = {}) {
  inspectGLB(buffer);
  const gltf = await new GLTFLoader().parseAsync(buffer, "");
  gltf.scene.updateMatrixWorld(true);
  const parts = [],
    all = [],
    triangles = [];
  gltf.scene.traverse((mesh) => {
    if (!mesh.isMesh) return;
    if (mesh.isSkinnedMesh || mesh.morphTargetInfluences?.length)
      throw Error("Bake animated objects to a static mesh first.");
    const geometry = mesh.geometry.clone().applyMatrix4(mesh.matrixWorld);
    geometry.deleteAttribute("tangent");
    const p = geometry.attributes.position,
      offset = all.length / 3;
    for (let i = 0; i < p.count; i++) all.push(p.getX(i), p.getY(i), p.getZ(i));
    if (geometry.index)
      for (let i = 0; i < geometry.index.count; i++)
        triangles.push(geometry.index.getX(i) + offset);
    else for (let i = 0; i < p.count; i++) triangles.push(i + offset);
    const copy = mesh.clone();
    copy.geometry = geometry;
    copy.position.set(0, 0, 0);
    copy.quaternion.identity();
    copy.scale.set(1, 1, 1);
    copy.matrixAutoUpdate = true;
    copy.matrix.identity();
    copy.castShadow = true;
    copy.receiveShadow = true;
    parts.push({ mesh: copy, offset, count: p.count });
  });
  if (all.length < 12) throw Error("No usable mesh geometry.");
  const vertices = new Float64Array(all),
    normalization = normalize ? normalizeVertices(vertices) : null,
    group = new Group();
  for (const part of parts) {
    const p = part.mesh.geometry.attributes.position;
    // GLB buffers can interleave positions, normals and UVs. Never treat .array
    // as packed positions: that silently corrupts all three on museum captures.
    for (let i = 0; i < part.count; i++) {
      const o = (part.offset + i) * 3;
      p.setXYZ(i, vertices[o], vertices[o + 1], vertices[o + 2]);
    }
    part.mesh.geometry.computeVertexNormals();
    part.mesh.geometry.computeBoundingSphere();
    part.mesh.geometry.computeBoundingBox();
    group.add(part.mesh);
  }
  return {
    group,
    parts,
    vertices,
    triangles: new Uint32Array(triangles),
    normalization,
    buffer,
  };
}
export function updateCapture(capture, positions) {
  for (const part of capture.parts) {
    const g = part.mesh.geometry,
      p = g.attributes.position;
    for (let i = 0; i < part.count; i++) {
      const o = (part.offset + i) * 3;
      p.setXYZ(i, positions[o], positions[o + 1], positions[o + 2]);
    }
    g.attributes.position.needsUpdate = true;
    g.computeVertexNormals();
    g.computeBoundingSphere();
    g.computeBoundingBox();
  }
}
export function disposeCapture(capture) {
  if (!capture) return;
  const textures = new Set(),
    materials = new Set();
  capture.group.traverse((m) => {
    if (m.geometry) m.geometry.dispose();
    for (const mat of [].concat(m.material ?? [])) {
      materials.add(mat);
      for (const v of Object.values(mat)) if (v?.isTexture) textures.add(v);
    }
  });
  for (const t of textures) {
    t.dispose();
    t.source?.data?.close?.();
  }
  for (const m of materials) m.dispose();
}
export async function digest(buffer) {
  return Array.from(
    new Uint8Array(await crypto.subtle.digest("SHA-256", buffer)),
  )
    .map((q) => q.toString(16).padStart(2, "0"))
    .join("");
}
export function base64(buffer) {
  let s = "";
  const a = new Uint8Array(buffer);
  for (let i = 0; i < a.length; i += 32768)
    s += String.fromCharCode(...a.subarray(i, i + 32768));
  return btoa(s);
}
export function fromBase64(s) {
  if (typeof s !== "string" || s.length > 70 * 1024 * 1024)
    throw Error("Embedded asset is too large.");
  return Uint8Array.from(atob(s), (c) => c.charCodeAt(0)).buffer;
}
export function download(data, name, type) {
  const url = URL.createObjectURL(new Blob([data], { type })),
    a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
