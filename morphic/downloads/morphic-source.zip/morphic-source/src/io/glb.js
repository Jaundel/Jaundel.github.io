import { Matrix4, Vector3 } from "three";

export function inspectGLB(buffer) {
  if (buffer.byteLength > 50 * 1024 * 1024) throw Error("GLB limit is 50 MB.");
  const view = new DataView(buffer);
  if (
    view.byteLength < 28 ||
    view.getUint32(0, true) !== 0x46546c67 ||
    view.getUint32(4, true) !== 2 ||
    view.getUint32(8, true) !== buffer.byteLength
  )
    throw Error("Not a valid GLB 2.0 file.");
  let json, bin;
  for (let off = 12; off < buffer.byteLength; ) {
    if (off + 8 > buffer.byteLength) throw Error("Truncated GLB.");
    const size = view.getUint32(off, true),
      type = view.getUint32(off + 4, true);
    off += 8;
    if (off + size > buffer.byteLength)
      throw Error("Invalid GLB chunk length.");
    if (type === 0x4e4f534a)
      json = JSON.parse(
        new TextDecoder().decode(new Uint8Array(buffer, off, size)),
      );
    if (type === 0x004e4942) bin = buffer.slice(off, off + size);
    off += size;
  }
  if (!json || !bin) throw Error("GLB needs geometry and embedded data.");
  if (
    (json.buffers ?? []).some((b) => b.uri) ||
    (json.images ?? []).some((i) => i.uri)
  )
    throw Error("Use a self-contained GLB with embedded textures.");
  if (json.skins?.length || json.animations?.length)
    throw Error("Bake skinning and animation to a static capture first.");
  if (
    json.extensionsRequired?.some(
      (e) => !["KHR_materials_unlit", "KHR_texture_transform"].includes(e),
    )
  )
    throw Error(
      "Required compressed or advanced extensions are unsupported. Export a core GLB.",
    );
  return { json, bin };
}

// Geometry-only reader used by reproducible CLI experiments. Rendering uses Three's
// GLTFLoader, giving us independent agreement checks for the two import paths.
export function geometryFromGLB(buffer) {
  const { json: g, bin } = inspectGLB(buffer),
    dv = new DataView(bin),
    vertices = [],
    triangles = [];
  function accessor(index) {
    const a = g.accessors[index],
      b = g.bufferViews[a.bufferView];
    if (a.sparse)
      throw Error("Sparse accessors are unsupported in benchmark importer.");
    const n = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 }[a.type];
    const sz = { 5121: 1, 5123: 2, 5125: 4, 5126: 4 }[a.componentType];
    if (!n || !sz) throw Error("Unsupported accessor.");
    const out = [];
    const fn = {
      5121: "getUint8",
      5123: "getUint16",
      5125: "getUint32",
      5126: "getFloat32",
    }[a.componentType];
    for (let i = 0; i < a.count; i++)
      for (let c = 0; c < n; c++)
        out.push(
          dv[fn](
            (b.byteOffset ?? 0) +
              (a.byteOffset ?? 0) +
              i * (b.byteStride ?? n * sz) +
              c * sz,
            true,
          ),
        );
    return out;
  }
  const visiting = new Set();
  function walk(i, parent) {
    if (visiting.has(i)) throw Error("Cyclic scene.");
    visiting.add(i);
    const node = g.nodes[i],
      local = new Matrix4();
    if (node.matrix) local.fromArray(node.matrix);
    else {
      const t = node.translation ?? [0, 0, 0],
        q = node.rotation ?? [0, 0, 0, 1],
        s = node.scale ?? [1, 1, 1];
      // Matrix compose accepts quaternion-like values.
      local.compose(
        new Vector3(...t),
        { _x: q[0], _y: q[1], _z: q[2], _w: q[3] },
        new Vector3(...s),
      );
    }
    const matrix = parent.clone().multiply(local);
    if (node.mesh !== undefined)
      for (const p of g.meshes[node.mesh].primitives) {
        if (p.mode !== undefined && p.mode !== 4)
          throw Error("Only triangle meshes are supported.");
        if (p.targets?.length) throw Error("Bake morph targets first.");
        const pos = accessor(p.attributes.POSITION),
          offset = vertices.length / 3,
          v = new Vector3();
        for (let j = 0; j < pos.length; j += 3) {
          v.fromArray(pos, j).applyMatrix4(matrix);
          vertices.push(v.x, v.y, v.z);
        }
        const idx =
          p.indices === undefined
            ? Array.from({ length: pos.length / 3 }, (_, k) => k)
            : accessor(p.indices);
        for (const k of idx) triangles.push(k + offset);
      }
    for (const child of node.children ?? []) walk(child, matrix);
    visiting.delete(i);
  }
  for (const i of g.scenes[g.scene ?? 0].nodes) walk(i, new Matrix4());
  const x = new Float64Array(vertices);
  normalizeVertices(x);
  return { vertices: x, triangles: new Uint32Array(triangles) };
}
export function normalizeVertices(x) {
  const min = [Infinity, Infinity, Infinity],
    max = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < x.length; i++) {
    min[i % 3] = Math.min(min[i % 3], x[i]);
    max[i % 3] = Math.max(max[i % 3], x[i]);
  }
  const scale = 1.6 / Math.max(...max.map((q, i) => q - min[i]));
  const center = min.map((q, i) => (q + max[i]) / 2);
  for (let i = 0; i < x.length; i++)
    x[i] =
      (x[i] - (i % 3 === 1 ? min[1] : center[i % 3])) * scale +
      (i % 3 === 1 ? 0.25 : 0);
  return { scale, min, center };
}
