// Optional local authoring endpoint. Deployed apps use ordinary downloads.
let capability;
export async function saveLocalArtifact(blob, name, metadata = {}) {
  if (!["127.0.0.1", "localhost"].includes(location.hostname)) return null;
  capability ??= fetch("./__morphic_artifacts")
    .then((r) =>
      r.headers.get("content-type")?.includes("application/json")
        ? r.json()
        : null,
    )
    .catch(() => null);
  if (!(await capability)?.enabled) return null;
  const response = await fetch("./__morphic_artifacts", {
    method: "POST",
    headers: {
      "Content-Type": blob.type,
      "X-Artifact-Name": name,
      "X-Artifact-Metadata": JSON.stringify(metadata),
    },
    body: blob,
  });
  if (!response.ok)
    throw Error(
      "The artifact is ready to download, but saving it to the local project failed.",
    );
  return response.json();
}
