import { inspectGLB } from "./glb.js";

// A matching report establishes artifact consistency, not physical accuracy or
// trusted authorship. Only a live run can establish that inference took place.
export async function validateReconstructionResult(report, buffer) {
  if (
    report?.schema !== 1 ||
    report.state !== "completed" ||
    report.stage !== "completed"
  )
    throw Error("Reconstruction has not completed successfully.");
  if (
    ![
      "trellis2-single-image",
      "trellis-single-image",
      "trellis-multi-image",
    ].includes(report.method) ||
    report.behavior !== "assigned" ||
    report.hiddenSurfaces !== "generated-unverified"
  )
    throw Error("Unsupported reconstruction method or evidence labels.");
  for (const revision of [report.sourceCommit, report.checkpointRevision])
    if (!/^[a-f0-9]{40}$/.test(revision ?? ""))
      throw Error("Missing reconstruction source revision.");
  if (!/^[a-f0-9]{64}$/.test(report.input?.sha256 ?? ""))
    throw Error("Missing source-image checksum.");
  const expectedPipeline =
    report.method === "trellis2-single-image" ? "512" : "trellis-image-large";
  if (!Number.isInteger(report.seed) || report.pipeline !== expectedPipeline)
    throw Error("Unsupported reconstruction settings.");
  const inputs = report.inputs ?? [report.input];
  if (
    !Array.isArray(inputs) ||
    !inputs.length ||
    inputs.length > 80 ||
    inputs.some((input) => !/^[a-f0-9]{64}$/.test(input?.sha256 ?? ""))
  )
    throw Error("Invalid reconstruction input provenance.");
  if (report.method === "trellis-multi-image" && inputs.length < 2)
    throw Error("Multiview reconstruction needs multiple source images.");
  if (report.output?.bytes !== buffer.byteLength)
    throw Error("Reconstruction output size mismatch.");
  const hash = [
    ...new Uint8Array(await crypto.subtle.digest("SHA-256", buffer)),
  ]
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
  if (hash !== report.output.sha256)
    throw Error("Reconstruction output checksum mismatch.");
  inspectGLB(buffer);
  return {
    method: report.method,
    sourceCommit: report.sourceCommit,
    checkpointRevision: report.checkpointRevision,
    inputSha256: report.input.sha256,
    inputs: inputs.map((input) => ({
      sha256: input.sha256,
      name: String(input.name ?? "").slice(0, 250),
    })),
    outputSha256: hash,
    seed: report.seed,
    pipeline: report.pipeline,
    behavior: "assigned",
    hiddenSurfaces: "generated-unverified",
  };
}
