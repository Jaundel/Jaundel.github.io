// Sessions use different solvers. Keep their data local while opening the correct
// workspace; only a random, single-use identifier travels in the URL.
export function sessionWorkspace(session) {
  if (session?.schema === "morphic-measured-session-1") return "measured";
  if (
    session?.schema === 1 &&
    ["morphic-xpbd-2", "morphic-xpbd-3"].includes(session.engine)
  )
    return "capture";
  throw Error("This file is not a supported Morphic session.");
}

function database() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("morphic-session-handoff", 1);
    request.onupgradeneeded = () =>
      request.result.createObjectStore("sessions");
    request.onsuccess = () => resolve(request.result);
    request.onerror = () =>
      reject(
        Error(
          "Browser storage is unavailable. Open this session in its original workspace.",
        ),
      );
  });
}

export async function handoffSession(session) {
  const mode = sessionWorkspace(session);
  const db = await database();
  const id = crypto.randomUUID();
  try {
    await new Promise((resolve, reject) => {
      const transaction = db.transaction("sessions", "readwrite");
      transaction.objectStore("sessions").put(session, id);
      transaction.oncomplete = resolve;
      transaction.onerror = () =>
        reject(
          Error(
            "Could not prepare the session. Keep the saved file and try again.",
          ),
        );
      transaction.onabort = transaction.onerror;
    });
  } finally {
    db.close();
  }
  location.href = `./?mode=${mode}&session=${id}`;
}

export async function takeSession() {
  const url = new URL(location.href);
  const id = url.searchParams.get("session");
  if (!id) return null;
  const db = await database();
  try {
    const session = await new Promise((resolve, reject) => {
      const transaction = db.transaction("sessions", "readwrite");
      const store = transaction.objectStore("sessions");
      const request = store.get(id);
      let result;
      request.onsuccess = () => {
        result = request.result;
        store.delete(id);
      };
      transaction.oncomplete = () => resolve(result);
      transaction.onerror = () =>
        reject(Error("Could not open the saved session."));
      transaction.onabort = transaction.onerror;
    });
    url.searchParams.delete("session");
    history.replaceState(null, "", url);
    if (!session)
      throw Error(
        "Open the saved session file again; this temporary link has expired.",
      );
    return session;
  } finally {
    db.close();
  }
}
