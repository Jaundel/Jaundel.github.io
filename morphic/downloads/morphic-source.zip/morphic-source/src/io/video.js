import {
  Output,
  WebMOutputFormat,
  BufferTarget,
  CanvasSource,
  Quality,
} from "mediabunny";

export async function encodeSimulationVideo(
  canvas,
  frameCount,
  fps,
  renderFrame,
) {
  const output = new Output({
    format: new WebMOutputFormat(),
    target: new BufferTarget(),
  });
  const source = new CanvasSource(canvas, {
    codec: "vp9",
    quality: new Quality({ bitrate: 8_000_000 }),
  });
  output.addVideoTrack(source, { frameRate: fps });
  try {
    await output.start();
    for (let frame = 0; frame < frameCount; frame++) {
      await renderFrame(frame);
      await source.add(frame / fps, 1 / fps);
    }
    await output.finalize();
    return new Blob([output.target.buffer], { type: "video/webm" });
  } catch (error) {
    if (output.state !== "finalized" && output.state !== "canceled")
      await output.cancel();
    throw error;
  }
}
