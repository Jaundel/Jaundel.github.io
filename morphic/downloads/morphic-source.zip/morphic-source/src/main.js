import studioMarkup from "./capture-studio.html?raw";
import { validateReconstructionResult } from "./io/reconstruction-result.js";
import { mountCaptureFlow } from "./capture-flow.js";
import {
  handoffSession,
  sessionWorkspace,
  takeSession,
} from "./io/session-handoff.js";
import "./style.css";
import "./capture-studio.css";
import { simplifyStudio } from "./simple-studio.js";
import "@fontsource/dm-sans/latin-400.css";
import "@fontsource/dm-sans/latin-500.css";
import "@fontsource/dm-sans/latin-700.css";
import "@fontsource/space-grotesk/latin-400.css";
import "@fontsource/space-grotesk/latin-600.css";
import * as THREE from "three";
import { GLTFExporter } from "three/addons/exporters/GLTFExporter.js";
import { createStudio } from "./render/studio.js";
import { bindGPU } from "./render/skinning.js";
import {
  loadCapture,
  updateCapture,
  disposeCapture,
  digest,
  base64,
  fromBase64,
  download,
} from "./io/capture.js";
import { deform } from "./physics/cage.js";
import { validateSession } from "./physics/session.js";

const $ = (id) => document.getElementById(id);
document.querySelector("#app").innerHTML = studioMarkup;
simplifyStudio();
mountCaptureFlow(async (buffer, provenance) => {
  const opened = await openAsset(buffer, {
    id: "generated",
    name: "Your object",
    author: "TRELLIS generated asset",
    license: "Unseen surfaces unverified",
    provenance,
  });
  if (!opened)
    throw Error(
      "The reconstruction finished, but the object could not be opened. Its files are retained in the local job folder.",
    );
  $("asset").value = "";
});

const studio = createStudio($("viewport")),
  worker = new Worker(new URL("./physics/worker.js", import.meta.url), {
    type: "module",
  });
let capture,
  cage,
  x,
  skin,
  ghost,
  gpu,
  sourceBuffer,
  assetInfo,
  sourceHash,
  generation = 0,
  paused = true,
  pinned = false,
  ready = false,
  playing = false,
  savedSession,
  saveMode = "download",
  pendingReplay = null,
  frameCPU = 0,
  updateCPU = 0;
const cpuReference = new URLSearchParams(location.search).has("cpu");
let frameCount = 0,
  frameTime = performance.now(),
  fps = 0,
  dragging = false,
  pointerId = null;
const raycaster = new THREE.Raycaster(),
  pointer = new THREE.Vector2(),
  plane = new THREE.Plane(),
  target = new THREE.Vector3();
let manifest = [];
function status(s, error = false) {
  $("status").textContent = s;
  $("status").classList.toggle("error", error);
}
function sendAction(action) {
  if (!ready || playing) return;
  worker.postMessage({ type: "action", action });
  $("drift").textContent = "—";
}
function pause(value) {
  paused = value;
  worker.postMessage({ type: "pause", value });
  $("play").textContent = value ? "▶" : "Ⅱ";
  $("play").setAttribute(
    "aria-label",
    value ? "Play simulation" : "Pause simulation",
  );
}
function run(type) {
  sendAction({ type });
  pause(false);
}
function busy(value) {
  ready = !value;
  $("loading").hidden = !value;
  for (const el of document.querySelectorAll("button,input,select"))
    if (
      !el.closest("#capture-dialog") &&
      !["file", "session-file", "import", "load", "asset"].includes(el.id)
    )
      el.disabled = value;
}
async function openAsset(buffer, info, session = null) {
  const myGeneration = ++generation;
  busy(true);
  pause(true);
  status("Reading capture and building a volumetric simulation…");
  try {
    const next = await loadCapture(buffer);
    if (myGeneration !== generation) {
      disposeCapture(next);
      return;
    }
    gpu?.dispose();
    gpu = null;
    if (capture) {
      studio.scene.remove(capture.group);
      disposeCapture(capture);
    }
    if (ghost) {
      studio.scene.remove(ghost);
      ghost.traverse((m) => {
        if (m.isMesh) {
          m.material.dispose();
          m.geometry.dispose();
        }
      });
    }
    capture = next;
    sourceBuffer = buffer;
    assetInfo = info;
    sourceHash = await digest(buffer);
    studio.scene.add(capture.group);
    studio.home();
    ghost = capture.group.clone(true);
    ghost.traverse((m) => {
      if (m.isMesh) {
        m.geometry = m.geometry.clone();
        m.material = new THREE.MeshBasicMaterial({
          color: "#1d63b7",
          wireframe: true,
          transparent: true,
          opacity: 0.15,
          depthWrite: false,
        });
        m.castShadow = false;
      }
    });
    ghost.visible = $("ghost").checked;
    studio.scene.add(ghost);
    $("asset-name").textContent = info.name;
    $("capture-story").hidden = info.id !== "capture_glove";
    $("credit").textContent =
      `${info.author ?? "Your capture"} · ${info.license ?? "Local import"}`;
    $("asset-tag").textContent =
      info.id === "lemon"
        ? "OBJECT 01 / TEXTURED ASSET"
        : info.id === "sweet_potato"
          ? "OBJECT 02 / TEXTURED ASSET"
          : info.id?.startsWith("met_")
            ? "MUSEUM SCAN / THE MET"
            : "YOUR CAPTURE / GLB";
    $("drift").textContent = "—";
    savedSession = null;
    pendingReplay = session;
    worker.postMessage({
      type: "init",
      generation,
      vertices: capture.vertices,
      triangles: capture.triangles,
      resolution: Number($("resolution").value),
    });
    return true;
  } catch (e) {
    busy(false);
    ready = Boolean(capture);
    $("loading").hidden = true;
    status(e.message, true);
    return false;
  }
}
worker.onmessage = ({ data: m }) => {
  if (m.generation !== undefined && m.generation !== generation) return;
  if (m.type === "ready") {
    cage = m.cage;
    skin = new Float32Array((cage.bindNodes.length / 4) * 3);
    if (!cpuReference) gpu = bindGPU(capture, cage);
    busy(false);
    pinned = false;
    $("pin").classList.remove("selected");
    $("geometry").textContent =
      `${capture.triangles.length / 3} TRIANGLES / ${cage.rest.length / 3} NODES`;
    status("Drag the object to pull it. Drag the background to look around.");
    if (pendingReplay) {
      worker.postMessage({ type: "replay", session: pendingReplay });
      pendingReplay = null;
    }
  } else if (m.type === "frame") {
    const start = performance.now();
    x = m.x;
    if (cage && capture) {
      if (gpu) gpu.update(x);
      else {
        deform(cage, x, skin);
        updateCapture(capture, skin);
      }
      studio.showCage(cage, x, $("cage").checked);
    }
    updateCPU = performance.now() - start;
    const s = m.stats;
    paused = s.paused;
    playing = s.playing;
    const sec = s.time;
    $("play").textContent = paused ? "▶" : "Ⅱ";
    $("play").setAttribute(
      "aria-label",
      paused ? "Play simulation" : "Pause simulation",
    );
    $("time").textContent = `${Math.floor(sec / 60)
      .toString()
      .padStart(2, "0")}:${(sec % 60).toFixed(3).padStart(6, "0")}`;
    $("progress").style.width = `${Math.min(100, (sec / 60) * 100)}%`;
    $("state").textContent = s.fault
      ? "LIMIT REACHED"
      : playing
        ? "REPLAYING"
        : paused
          ? "PAUSED"
          : "LIVE";
    $("state").classList.toggle("live", !paused);
    $("solver-ms").innerHTML = `${s.stepP95.toFixed(2)} <small>ms</small>`;
    $("volume").innerHTML =
      `${(s.volumeRatio * 100).toFixed(1)} <small>%</small>`;
    $("inverted").textContent = s.inverted;
    $("inverted").classList.toggle("bad", s.inverted > 0);
    $("gravity").checked = s.gravity !== 0;
    $("surface").value = s.surface;
    studio.setSurface(s.surface);
    for (const b of document.querySelectorAll("[data-material]"))
      b.classList.toggle("selected", b.dataset.material === s.material);
    if (s.fault) status(s.fault, true);
    window.morphicStats = {
      ...s,
      updateCPU,
      frameCPU,
      fps,
      nodes: cage?.rest.length / 3,
      renderVertices: capture?.vertices.length / 3,
      skinning: gpu ? "gpu" : "cpu",
    };
  } else if (m.type === "session") {
    savedSession = {
      ...m.session,
      resolution: Number($("resolution").value),
      asset: { ...assetInfo, sha256: sourceHash, glb: base64(sourceBuffer) },
    };
    if (saveMode === "replay") {
      worker.postMessage({ type: "replay", session: savedSession });
      status("Replaying recorded inputs from the original state…");
    } else {
      download(
        JSON.stringify(savedSession),
        `${assetInfo.id ?? "capture"}.morphic.json`,
        "application/json",
      );
      status(
        "Saved a portable session with the capture, inputs, and verification checkpoint.",
      );
    }
  } else if (m.type === "replayComplete") {
    $("drift").textContent =
      m.maxError === 0 ? "0 m" : `${m.maxError.toExponential(2)} m`;
    status(
      `Replay complete. Maximum node drift: ${m.maxError.toExponential(2)} m.`,
      m.maxError > 1e-6,
    );
  } else if (m.type === "error") {
    busy(false);
    pause(true);
    status(m.message, true);
  }
};
worker.onerror = (e) => status(`Simulation worker failed: ${e.message}`, true);
for (const b of document.querySelectorAll("[data-material]"))
  b.onclick = () => sendAction({ type: "material", value: b.dataset.material });
for (const id of ["squash", "stretch", "drop"]) $(id).onclick = () => run(id);
$("pin").onclick = () => {
  pinned = !pinned;
  sendAction({ type: pinned ? "pin" : "unpin" });
  $("pin").classList.toggle("selected", pinned);
};
$("play").onclick = () => pause(!paused);
$("gravity").onchange = () =>
  sendAction({ type: "gravity", value: $("gravity").checked });
$("surface").onchange = () =>
  sendAction({ type: "surface", value: $("surface").value });
$("reset").onclick = () => {
  worker.postMessage({ type: "reset" });
  $("drift").textContent = "—";
  pinned = false;
  $("pin").classList.remove("selected");
  status("Reset to the original capture.");
};
$("resolution").onchange = () => openAsset(sourceBuffer, assetInfo);
$("ghost").onchange = () => {
  if (ghost) ghost.visible = $("ghost").checked;
};
$("cage").onchange = () => {
  if (cage && x) studio.showCage(cage, x, $("cage").checked);
};
$("home").onclick = () => studio.home();
$("photo").onclick = () => {
  studio.render();
  studio.renderer.domElement.toBlob((b) => {
    if (b) download(b, "morphic-capture.png", "image/png");
  });
};
$("export").onclick = async () => {
  try {
    deform(cage, x, skin);
    updateCapture(capture, skin);
    const copy = capture.group.clone(true);
    copy.traverse((m) => {
      if (m.isMesh) {
        m.geometry = m.geometry.clone();
        m.geometry.deleteAttribute("morphicIds");
        m.geometry.deleteAttribute("morphicWeights");
        m.geometry.deleteAttribute("morphicRestNormal");
      }
    });
    const out = await new GLTFExporter().parseAsync(copy, { binary: true });
    copy.traverse((m) => m.geometry?.dispose());
    download(out, "morphic-deformed.glb", "model/gltf-binary");
    status(
      "Exported current geometry with its original materials and textures.",
    );
  } catch (e) {
    status(e.message, true);
  }
};
$("save").onclick = () => {
  saveMode = "download";
  worker.postMessage({ type: "save" });
};
$("replay").onclick = () => {
  saveMode = "replay";
  worker.postMessage({ type: "save" });
};
$("import").onclick = () => $("file").click();
$("load").onclick = () => $("session-file").click();
$("file").onchange = async (e) => {
  try {
    const files = [...e.target.files];
    if (!files.length) return;
    const models = files.filter((file) => /\.glb$/i.test(file.name));
    const reports = files.filter((file) => /\.json$/i.test(file.name));
    if (
      models.length !== 1 ||
      reports.length > 1 ||
      files.length !== models.length + reports.length
    )
      throw Error(
        "Choose one GLB, optionally with its reconstruction result.json.",
      );
    const f = models[0];
    if (f.size > 50 * 1024 * 1024) throw Error("GLB limit is 50 MB.");
    const buffer = await f.arrayBuffer();
    let provenance;
    if (reports.length) {
      if (reports[0].size > 1024 * 1024)
        throw Error("Reconstruction report is too large.");
      provenance = await validateReconstructionResult(
        JSON.parse(await reports[0].text()),
        buffer,
      );
    }
    await openAsset(buffer, {
      id: "import",
      name: f.name.replace(/\.glb$/i, ""),
      author: provenance
        ? `${provenance.method.startsWith("trellis2") ? "TRELLIS.2" : "TRELLIS"} generated asset`
        : "Local capture",
      license: provenance ? "Unseen surfaces unverified" : "Local import",
      ...(provenance ? { provenance } : {}),
    });
    $("asset").value = "";
  } catch (error) {
    status(error.message, true);
  } finally {
    e.target.value = "";
  }
};
$("session-file").onchange = async (e) => {
  try {
    const f = e.target.files[0];
    if (!f) return;
    if (f.size > 75 * 1024 * 1024) throw Error("Session is too large.");
    const parsed = JSON.parse(await f.text());
    if (sessionWorkspace(parsed) !== "capture") {
      await handoffSession(parsed);
      return;
    }
    await openSavedSession(parsed);
  } catch (err) {
    status(err.message, true);
  }
  e.target.value = "";
};
async function openSavedSession(parsed) {
  const s = validateSession(parsed);
  const buffer = fromBase64(s.asset?.glb);
  if ((await digest(buffer)) !== s.asset.sha256)
    throw Error("Asset checksum mismatch.");
  if (![6, 8, 12].includes(s.resolution))
    throw Error("Unsupported session resolution.");
  $("resolution").value = s.resolution;
  await openAsset(buffer, s.asset, s);
  $("asset").value = manifest.some((item) => item.id === s.asset.id)
    ? s.asset.id
    : "";
}
$("asset").onchange = () => selectAsset($("asset").value);
async function selectAsset(id) {
  if (id === "sloth") {
    location.href = "./?mode=measured";
    return;
  }
  try {
    const info = manifest.find((a) => a.id === id),
      response = await fetch(`./assets/${id}.glb`);
    if (!response.ok) throw Error("Asset download failed. Run npm run assets.");
    const b = await response.arrayBuffer();
    if ((await digest(b)) !== info.sha256)
      throw Error("Bundled asset checksum mismatch.");
    await openAsset(b, info);
  } catch (e) {
    status(e.message, true);
  }
}
const canvas = studio.renderer.domElement;
function point(event) {
  const r = canvas.getBoundingClientRect();
  pointer.set(
    ((event.clientX - r.left) / r.width) * 2 - 1,
    (-(event.clientY - r.top) / r.height) * 2 + 1,
  );
  raycaster.setFromCamera(pointer, studio.camera);
}
canvas.addEventListener(
  "pointerdown",
  (e) => {
    if (e.button !== 0 || !ready || playing) return;
    if (gpu) {
      deform(cage, x, skin);
      updateCapture(capture, skin);
    }
    point(e);
    const hit = raycaster.intersectObject(capture.group, true)[0];
    if (!hit) return;
    e.stopImmediatePropagation();
    studio.controls.enabled = false;
    dragging = true;
    pointerId = e.pointerId;
    canvas.setPointerCapture(e.pointerId);
    let closest = 0,
      distance = Infinity;
    for (let i = 0; i < x.length; i += 3) {
      const d =
        (x[i] - hit.point.x) ** 2 +
        (x[i + 1] - hit.point.y) ** 2 +
        (x[i + 2] - hit.point.z) ** 2;
      if (d < distance) {
        distance = d;
        closest = i / 3;
      }
    }
    target.set(x[closest * 3], x[closest * 3 + 1], x[closest * 3 + 2]);
    plane.setFromNormalAndCoplanarPoint(
      studio.camera.getWorldDirection(new THREE.Vector3()),
      target,
    );
    sendAction({ type: "grab", node: closest, target: target.toArray() });
    studio.handle.position.copy(target);
    studio.handle.visible = true;
    pause(false);
  },
  true,
);
canvas.addEventListener(
  "pointermove",
  (e) => {
    if (!dragging) return;
    point(e);
    if (raycaster.ray.intersectPlane(plane, target)) {
      target.clamp(new THREE.Vector3(-6, 0.02, -6), new THREE.Vector3(6, 7, 6));
      sendAction({ type: "move", target: target.toArray() });
      studio.handle.position.copy(target);
    }
  },
  true,
);
function release() {
  if (!dragging) return;
  dragging = false;
  studio.controls.enabled = true;
  studio.handle.visible = false;
  sendAction({ type: "release" });
  if (pointerId !== null && canvas.hasPointerCapture(pointerId))
    canvas.releasePointerCapture(pointerId);
  pointerId = null;
}
canvas.addEventListener("pointerup", release, true);
canvas.addEventListener("pointercancel", release, true);
window.addEventListener("blur", release);
document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    release();
    pause(true);
  }
});
document.addEventListener("keydown", (e) => {
  if (document.querySelector("dialog[open]")) return;
  if (["INPUT", "SELECT", "TEXTAREA", "BUTTON"].includes(e.target.tagName))
    return;
  if (e.code === "Space") {
    e.preventDefault();
    pause(!paused);
  }
  if (e.code === "KeyR") $("reset").click();
});
function animate() {
  requestAnimationFrame(animate);
  const start = performance.now();
  studio.render();
  frameCPU = performance.now() - start + updateCPU;
  frameCount++;
  if (start - frameTime > 500) {
    fps = (frameCount * 1000) / (start - frameTime);
    frameCount = 0;
    frameTime = start;
    $("frame-ms").innerHTML = `${frameCPU.toFixed(2)} <small>ms</small>`;
  }
}
animate();
try {
  const r = await fetch("./assets/manifest.json");
  manifest = await r.json();
  const requested = new URLSearchParams(location.search).get("asset");
  const initial = manifest.some((a) => a.id === requested)
    ? requested
    : "lemon";
  $("asset").value = initial;
  const pending = await takeSession();
  if (pending) await openSavedSession(pending);
  else await selectAsset(initial);
} catch (e) {
  status(`Could not load bundled assets: ${e.message}`, true);
}
