import markup from "./measured-studio.html?raw";
import "./style.css";
import "./measured-studio.css";
import { simplifyStudio } from "./simple-studio.js";
import "@fontsource/dm-sans/latin-400.css";
import "@fontsource/dm-sans/latin-500.css";
import "@fontsource/dm-sans/latin-700.css";
import "@fontsource/space-grotesk/latin-600.css";
import * as THREE from "three";
import { GLTFExporter } from "three/addons/exporters/GLTFExporter.js";
import { createStudio } from "./render/studio.js";
import { recordedCamera } from "./render/recorded-camera.js";
import { saveLocalArtifact } from "./io/local-artifact.js";
import {
  handoffSession,
  sessionWorkspace,
  takeSession,
} from "./io/session-handoff.js";
import { validateMeasuredSession } from "./physics/measured-session.js";
import { gaussianAppearance } from "./render/gaussian-appearance.js";
import { bindGraph, deformGraph } from "./render/graph-binding.js";
import {
  loadCapture,
  updateCapture,
  disposeCapture,
  download,
  base64,
  fromBase64,
  digest,
} from "./io/capture.js";
import {
  MeasuredGraphSolver,
  validateMeasuredAsset,
} from "./physics/measured-graph.js";

const $ = (id) => document.getElementById(id);
const embedded = new URLSearchParams(location.search).get("embed") === "1";
if (embedded) document.body.classList.add("embedded");

$("app").innerHTML = markup;
simplifyStudio(true);
if (embedded) $("app").querySelector(".response-details").open = true;
const motionPreference = matchMedia("(prefers-reduced-motion: reduce)");
const studio = createStudio($("viewport"));

const display = new THREE.Group();
// Display transform only: physics stays in dataset metres with -Z up.
display.rotation.x = Math.PI / 2;
display.scale.setScalar(4);
studio.scene.add(display);

const hands = new THREE.Points(
  new THREE.BufferGeometry(),
  new THREE.PointsMaterial({ color: 0x1d63b7, size: 0.009 }),
);
display.add(hands);

function home() {
  if ($("camera-view")) $("camera-view").value = "studio";
  studio.controls.enabled = true;
  studio.camera.updateProjectionMatrix();
  studio.camera.position.set(-1.6, 2.1, 1.5);
  studio.controls.target.set(0, 0.12, 0);
  studio.controls.update();
}

let capture,
  asset,
  fittedAsset,
  calibration,
  solver,
  binding,
  surface,
  visualCage,
  buffer,
  splatBuffer,
  splats,
  generation = 0;

const experiment = await fetch("./measured/experiment.json").then((r) =>
  r.ok ? r.json() : null,
);

const recordingNames = Array.from($("asset").options, (o) => o.value);

const gaussianCases = ["single_lift_sloth", "double_stretch_sloth"];

function setReady(ready) {
  for (const el of document.querySelectorAll("button,input,select"))
    if (!["asset", "load", "session-file"].includes(el.id))
      el.disabled = !ready;
}
setReady(false);

let paused = true,
  events = [],
  playback = null,
  eventIndex = 0,
  dragging = false;

let previousTime = performance.now(),
  debt = 0,
  exporting = false,
  videoURL = null,
  changed = false;

const ray = new THREE.Raycaster(),
  pointer = new THREE.Vector2(),
  plane = new THREE.Plane(),
  target = new THREE.Vector3();

function status(message, error = false) {
  $("status").textContent = message;
  $("status").classList.toggle("error", error);
}

function pause(value) {
  paused = value;
  debt = 0;
  $("play").textContent = value ? "▶" : "Ⅱ";
  $("play").setAttribute(
    "aria-label",
    value ? "Play recorded loading" : "Pause simulation",
  );
  $("state").textContent = value ? "Paused" : "Playing";
}

function record(action) {
  if (!solver || playback) return;
  solver.apply(action);
  events.push({ tick: solver.tick, action: structuredClone(action) });
  changed = true;
  $("assay").textContent = "Intentional intervention · not a fitted prediction";
}

function reset() {
  if (!asset) return;
  setReplayControls(true);
  solver = new MeasuredGraphSolver(asset);
  events = [];
  playback = null;
  changed = false;
  pause(true);
  $("softness").value = 0;
  $("softness-value").textContent = "1.00×";
  $("assay").textContent =
    asset.provenance.origin === "unfitted-reference"
      ? "Recorded loading · default response"
      : "Recorded loading · fitted response";
  $("asset-tag").textContent =
    asset.provenance.origin === "unfitted-reference"
      ? "Default graph response"
      : "Response fitted from observations";
  update();
}

function update() {
  if (!capture) return;
  deformGraph(binding, solver.x, surface);
  updateCapture(capture, surface);
  splats?.update(solver.x);
  hands.geometry.setAttribute(
    "position",
    new THREE.BufferAttribute(
      Float32Array.from(solver.x.subarray(solver.n * 3)),
      3,
    ),
  );
  hands.geometry.computeBoundingSphere();
  hands.visible = $("hands").checked;
  const stagePositions = new Float32Array(solver.n * 3),
    v = new THREE.Vector3();
  display.updateMatrixWorld(true);
  for (let i = 0; i < solver.n; i++) {
    v.fromArray(solver.x, i * 3)
      .applyMatrix4(display.matrixWorld)
      .toArray(stagePositions, i * 3);
  }
  studio.showCage(visualCage, stagePositions, $("cage").checked);
  $("time").textContent = (solver.tick * solver.dt).toFixed(2) + " s";
  $("scrub").value = Math.min(
    asset.controller.length - 1,
    Math.floor(solver.tick / asset.settings.substeps),
  );
}

async function open(id, session = null) {
  const current = ++generation;
  pause(true);
  setReady(false);
  $("loading").hidden = false;
  try {
    let a, b;
    if (session) {
      validateMeasuredSession(session);
      a = validateMeasuredAsset(session.response);
      b = fromBase64(session.appearance.glb);
      if ((await digest(b)) !== session.appearance.sha256)
        throw Error("Appearance checksum mismatch.");
    } else {
      const [ar, br] = await Promise.all([
        fetch(`./measured/${id}/asset.json`),
        fetch(`./measured/${id}/appearance.glb`),
      ]);
      if (!ar.ok || !br.ok) throw Error("Recording package is unavailable.");
      a = validateMeasuredAsset(await ar.json());
      b = await br.arrayBuffer();
    }
    const next = await loadCapture(b, { normalize: false });
    if (current !== generation) {
      disposeCapture(next);
      return;
    }
    if (splats) {
      display.remove(splats.mesh);
      splats.dispose();
      splats = null;
    }
    if (capture) {
      display.remove(capture.group);
      disposeCapture(capture);
    }
    asset = a;
    fittedAsset = structuredClone(a);
    buffer = b;
    splatBuffer = null;
    calibration = null;
    capture = next;
    display.add(capture.group);
    solver = new MeasuredGraphSolver(asset);
    binding = bindGraph(capture.vertices, solver.rest);
    surface = new Float32Array(capture.vertices.length);
    visualCage = {
      edges: Uint32Array.from(asset.edges.slice(0, asset.objectEdges).flat()),
      regions: asset.region.slice(0, asset.objectEdges),
    };
    const box = new THREE.Box3().setFromArray(solver.rest),
      center = box.getCenter(new THREE.Vector3());
    display.position.set(-center.x * 4, 0, -center.y * 4);
    home();
    $("asset-name").textContent = id?.includes("zebra") ? "Zebra" : "Sloth";
    $("geometry").textContent =
      `${solver.n} nodes / ${asset.objectEdges} object springs`;
    $("provenance").textContent =
      `Fit input: ${(asset.provenance.fitCases ?? [asset.case]).map((v) => v.replaceAll("_", " ")).join(", ")}.`;
    $("scrub").max = asset.controller.length - 1;
    reset();
    setReady(true);
    $("response-model").value = "fitted";
    $("response-model").options[2].disabled = !asset.case.includes("sloth");
    if (recordingNames.includes(asset.case)) {
      $("asset").value = asset.case;
      $("asset").dispatchEvent(new Event("recordingloaded"));
    }
    $("appearance").value = "mesh";
    $("appearance").options[1].disabled = !gaussianCases.includes(asset.case);
    $("loading").hidden = true;
    status(
      "Ready. Play the observed hand loading or drag the object to intervene.",
    );
    if (recordingNames.includes(asset.case)) {
      calibration = await fetch(`./measured/${asset.case}/observations.json`)
        .then((r) => (r.ok ? r.json() : null))
        .catch(() => null);
      if (current !== generation) return;
    }
    $("camera-view").options[1].disabled = !calibration;
    if (session?.appearance.gaussians) {
      const g = fromBase64(session.appearance.gaussians.data);
      if ((await digest(g)) !== session.appearance.gaussians.sha256)
        throw Error("Gaussian checksum mismatch.");
      splatBuffer = g;
      splats = gaussianAppearance(new Float32Array(g), solver.rest);
      display.add(splats.mesh);
      capture.group.visible = false;
      $("appearance").value = "gaussian";
      $("appearance").options[1].disabled = false;
    }
    if (session) startReplay(session);
  } catch (error) {
    if (current === generation) {
      $("loading").hidden = true;
      setReady(!!solver);
      status(error.message, true);
    }
  }
}

function setReplayControls(enabled) {
  for (const id of ["softness", "edit-region", "restore", "replay"])
    $(id).disabled = !enabled;
}

function startReplay(s) {
  validateMeasuredSession(s);
  setReplayControls(false);
  solver = new MeasuredGraphSolver(asset);
  playback = s;
  eventIndex = 0;
  events = [];
  changed = s.events.length > 0;
  if (changed) $("assay").textContent = "Intentional intervention / replay";
  pause(false);
  status("Replaying the recorded actions with the same fitted model.");
}

async function makeSession() {
  if (!solver) throw Error("Load a response first.");
  return {
    schema: "morphic-measured-session-1",
    response: structuredClone(asset),
    appearance: {
      glb: base64(buffer),
      sha256: await digest(buffer),
      ...(splatBuffer && $("appearance").value === "gaussian"
        ? {
            gaussians: {
              data: base64(splatBuffer),
              sha256: await digest(splatBuffer),
              source:
                "PhysTwin pretrained appearance; Morphic SH0 approximation",
            },
          }
        : {}),
    },
    events: structuredClone(
      playback ? playback.events.slice(0, eventIndex) : events,
    ),
    endTick: solver.tick,
    finalPositions: Array.from(solver.x.subarray(0, solver.n * 3)),
  };
}

$("appearance").onchange = async () => {
  const current = generation;
  try {
    if ($("appearance").value === "gaussian" && !splats) {
      status("Loading the attributed Gaussian appearance comparison…");
      const r = await fetch(`./measured/${asset.case}/gaussians.bin`);
      if (!r.ok) throw Error("Gaussian pilot is unavailable.");
      const g = await r.arrayBuffer();
      if (current !== generation) return;
      splatBuffer = g;
      const data = new Float32Array(g);
      splats = gaussianAppearance(data, solver.rest);
      display.add(splats.mesh);
      splats.update(solver.x);
    }
    capture.group.visible = $("appearance").value === "mesh";
    if (splats) splats.mesh.visible = !capture.group.visible;
    status(
      capture.group.visible
        ? "Textured appearance prior."
        : "PhysTwin pretrained appearance, SH0 approximation. Morphic covariance transport; appearance quality is under evaluation.",
    );
  } catch (e) {
    status(e.message, true);
  }
};

$("example").onchange = () => {
  if ($("example").value !== "sloth")
    location.href = `./?mode=capture&asset=${encodeURIComponent($("example").value)}`;
};
$("asset").onchange = async () => {
  await open($("asset").value);
  await showCapturedAppearance();
};

$("response-model").onchange = () => {
  asset = structuredClone(fittedAsset);
  const model = $("response-model").value;
  if (model !== "fitted") {
    const p =
      experiment.protocol.parameters[
        model === "default" ? "default" : "jointRegional"
      ];
    asset.parameters = p.slice(0, 4);
    asset.settings.friction = p[4] ?? 0.5;
    asset.provenance = {
      ...asset.provenance,
      origin:
        model === "default" ? "unfitted-reference" : "fitted-observations",
      model,
    };
  }
  reset();
  status(
    model === "default"
      ? "Default graph response: no parameters fitted to observations."
      : "Loaded a frozen fitted response. Compare using the same recorded loading.",
  );
  $("provenance").textContent =
    model === "default"
      ? "Unfitted reference settings."
      : `Fit input: ${(asset.provenance.fitCases ?? [asset.case]).join(", ").replaceAll("_", " ")}.`;
};

$("camera-view").onchange = () => {
  if ($("camera-view").value === "studio") home();
  else {
    studio.controls.enabled = false;
    render();
  }
};

function render() {
  if ($("camera-view").value === "recorded" && calibration) {
    const size = studio.renderer.getSize(new THREE.Vector2());
    recordedCamera(studio.camera, display, calibration, size.x, size.y);
  }
  studio.render();
}

$("play").onclick = () => pause(!paused);

$("reset").onclick = reset;

$("home").onclick = home;

$("cage").onchange = update;

$("edit-region").onchange = () => {
  if ($("edit-region").value !== "all") $("cage").checked = true;
  update();
  status("Graph colors: blue is the lower-X half; amber is the upper-X half.");
};

$("hands").onchange = update;

$("softness").oninput = () => {
  if (!solver) return;
  const multiplier = 10 ** Number($("softness").value),
    p = asset.parameters.slice(),
    region = $("edit-region").value;
  for (let i = 0; i < 2; i++)
    if (region === "all" || Number(region) === i)
      p[i] = Math.min(0.1, Math.max(1e-9, p[i] * multiplier));
  record({ type: "response", parameters: p });
  $("softness-value").textContent = multiplier.toFixed(2) + "×";
};

$("restore").onclick = () => {
  record({ type: "response", parameters: asset.parameters });
  $("softness").value = 0;
  $("softness-value").textContent = "1.00×";
};
// Capture the requested frame before reset updates the range control.

$("scrub").oninput = function () {
  const frame = Number(this.value);
  reset();
  for (let i = 0; i < frame * asset.settings.substeps; i++)
    solver.stepRecorded();
  update();
};

$("save").onclick = async () => {
  try {
    const saved = await makeSession();
    const blob = new Blob([JSON.stringify(saved)], {
      type: "application/json",
    });
    download(blob, `${asset.case}.morphic.json`);
    const local = await saveLocalArtifact(blob, `${asset.case}.morphic.json`);
    status(
      local
        ? `Saved session to ${local.path}.`
        : "Session saved with appearance, response, loading, and action log.",
    );
  } catch (e) {
    status(e.message, true);
  }
};

$("replay").onclick = async () => {
  try {
    const s = await makeSession();
    startReplay(s);
  } catch (e) {
    status(e.message, true);
  }
};

$("load").onclick = () => $("session-file").click();

$("session-file").onchange = async (e) => {
  try {
    const f = e.target.files[0];
    if (!f) return;
    if (f.size > 75 * 1024 * 1024) throw Error("Session exceeds 75 MB.");
    const s = JSON.parse(await f.text());
    if (sessionWorkspace(s) !== "measured") {
      await handoffSession(s);
      return;
    }
    await open(s.response.case, s);
  } catch (e) {
    status(e.message, true);
  }
  e.target.value = "";
};

$("photo").onclick = () => {
  render();
  studio.renderer.domElement.toBlob((b) =>
    download(b, "morphic-observed-response.png"),
  );
};

$("export").onclick = async () => {
  try {
    const glb = await new GLTFExporter().parseAsync(capture.group, {
      binary: true,
      onlyVisible: false,
    });
    download(
      new Blob([glb], { type: "model/gltf-binary" }),
      `${asset.case}-deformed.glb`,
    );
    status(
      "Exported the deformed mesh in dataset metres. Gaussian appearance remains in the saved session.",
    );
  } catch (e) {
    status(e.message, true);
  }
};

$("record-video").onclick = async () => {
  if (!solver || exporting) return;
  pause(true);
  exporting = true;
  const oldSolver = solver,
    oldPixelRatio = studio.renderer.getPixelRatio();
  const controls = Array.from(document.querySelectorAll("button,input,select"));
  const disabled = controls.map((e) => e.disabled);
  controls.forEach((e) => (e.disabled = true));
  try {
    const { encodeSimulationVideo } = await import("./io/video.js");
    solver = new MeasuredGraphSolver(asset);
    solver.setParameters(oldSolver.parameters);
    studio.renderer.setPixelRatio(1);
    studio.lockSize(1280, 720);
    const appearance = $("appearance").value;
    const blob = await encodeSimulationVideo(
      studio.renderer.domElement,
      asset.controller.length,
      asset.fps,
      async (frame) => {
        if (frame > 0)
          for (let s = 0; s < asset.settings.substeps; s++)
            solver.stepRecorded();
        update();
        splats?.forceSort();
        render();
        status(
          `Rendering video: frame ${frame + 1} of ${asset.controller.length}.`,
        );
      },
    );
    if (videoURL) URL.revokeObjectURL(videoURL);
    videoURL = URL.createObjectURL(blob);
    $("video-preview").src = videoURL;
    $("video-download").href = videoURL;
    $("video-download").download = `${asset.case}-${appearance}-morphic.webm`;
    $("video-dialog").showModal();
    status(
      `Exported ${asset.controller.length} frames at ${asset.fps} fps with the current response. Simulation timestamps are preserved.`,
    );
    const local = await saveLocalArtifact(
      blob,
      `${asset.case}-${appearance}-morphic.webm`,
      {
        case: asset.case,
        appearance,
        parameters: solver.parameters,
        settings: asset.settings,
        provenance: asset.provenance,
        camera: $("camera-view").value,
        cameraWorldMatrix: studio.camera.matrixWorld.toArray(),
        projectionMatrix: studio.camera.projectionMatrix.toArray(),
        frames: asset.controller.length,
        fps: asset.fps,
        width: 1280,
        height: 720,
        scope:
          "Recorded loading with the selected effective response; no mouse actions in this video",
      },
    );
    if (local)
      status(
        `Saved ${asset.controller.length} frames at ${asset.fps} fps to ${local.path}.`,
      );
  } catch (e) {
    status(e.message, true);
  } finally {
    solver = oldSolver;
    studio.renderer.setPixelRatio(oldPixelRatio);
    studio.unlockSize();
    controls.forEach((e, i) => (e.disabled = disabled[i]));
    exporting = false;
    update();
    render();
  }
};

$("video-close").onclick = () => $("video-dialog").close();

const canvas = studio.renderer.domElement;

function point(e) {
  const r = canvas.getBoundingClientRect();
  pointer.set(
    ((e.clientX - r.left) / r.width) * 2 - 1,
    (-(e.clientY - r.top) / r.height) * 2 + 1,
  );
  ray.setFromCamera(pointer, studio.camera);
}
canvas.addEventListener(
  "pointerdown",
  (e) => {
    if (e.button !== 0 || !capture || playback) return;
    point(e);
    const hit = ray.intersectObject(capture.group, true)[0];
    if (!hit) return;
    e.stopImmediatePropagation();
    dragging = true;
    studio.controls.enabled = false;
    canvas.setPointerCapture(e.pointerId);
    const local = display.worldToLocal(hit.point.clone());
    let node = 0,
      distance = Infinity;
    for (let i = 0; i < solver.n; i++) {
      const d =
        (solver.x[i * 3] - local.x) ** 2 +
        (solver.x[i * 3 + 1] - local.y) ** 2 +
        (solver.x[i * 3 + 2] - local.z) ** 2;
      if (d < distance) {
        distance = d;
        node = i;
      }
    }
    target.fromArray(solver.x, node * 3);
    const world = display.localToWorld(target.clone());
    plane.setFromNormalAndCoplanarPoint(
      studio.camera.getWorldDirection(new THREE.Vector3()),
      world,
    );
    record({ type: "grab", node, target: target.toArray() });
    pause(false);
  },
  true,
);
canvas.addEventListener(
  "pointermove",
  (e) => {
    if (!dragging) return;
    point(e);
    if (ray.ray.intersectPlane(plane, target)) {
      const local = display.worldToLocal(target.clone());
      local.z = Math.min(0, local.z);
      record({ type: "move", target: local.toArray() });
    }
  },
  true,
);

function release() {
  if (!dragging) return;
  dragging = false;
  studio.controls.enabled = $("camera-view").value === "studio";
  record({ type: "release" });
}
canvas.addEventListener("pointerup", release, true);
canvas.addEventListener("pointercancel", release, true);
window.addEventListener("blur", () => {
  release();
  pause(true);
});

function animate(now) {
  requestAnimationFrame(animate);
  if (exporting) return;
  const elapsed = Math.min((now - previousTime) / 1000, 0.05);
  previousTime = now;
  if (solver && !paused) {
    debt = Math.min(debt + elapsed, 0.05);
    let stepped = false;
    try {
      while (debt >= solver.dt) {
        if (playback) {
          while (
            eventIndex < playback.events.length &&
            playback.events[eventIndex].tick === solver.tick
          )
            solver.apply(playback.events[eventIndex++].action);
          if (solver.tick >= playback.endTick) {
            let drift = 0;
            for (let i = 0; i < solver.n * 3; i++)
              drift = Math.max(
                drift,
                Math.abs(solver.x[i] - playback.finalPositions[i]),
              );
            events = structuredClone(playback.events);
            playback = null;
            setReplayControls(true);
            pause(true);
            status(
              `Replay maximum coordinate drift: ${drift.toExponential(2)} m.`,
            );
            break;
          }
        }
        if (
          !playback &&
          !changed &&
          solver.tick >= (asset.controller.length - 1) * asset.settings.substeps
        ) {
          pause(true);
          break;
        }
        if (solver.tick >= 30000) {
          pause(true);
          break;
        }
        solver.stepRecorded();
        debt -= solver.dt;
        stepped = true;
      }
      if (stepped) update();
    } catch (e) {
      pause(true);
      status(e.message, true);
    }
  }
  render();
}
requestAnimationFrame(animate);

const requestedRecording = new URLSearchParams(location.search).get(
  "recording",
);
let pendingSession;
try {
  pendingSession = await takeSession();
} catch (error) {
  status(error.message, true);
}
await open(
  pendingSession?.response?.case ??
    (recordingNames.includes(requestedRecording)
      ? requestedRecording
      : "single_lift_sloth"),
  pendingSession,
);

async function showCapturedAppearance() {
  if (solver) {
    if (calibration) {
      $("camera-view").value = "recorded";
      $("camera-view").onchange();
    }
    if (gaussianCases.includes(asset.case)) {
      $("appearance").value = "gaussian";
      await $("appearance").onchange();
    }
  }
}
if (!pendingSession) await showCapturedAppearance();
