import { bounds, volume } from "./math.js";

// Conforming six-tetrahedra (Freudenthal) split. Same face diagonals in every cell.
const permutations = [
  [0, 1, 2],
  [0, 2, 1],
  [1, 0, 2],
  [1, 2, 0],
  [2, 0, 1],
  [2, 1, 0],
];
export function buildCage(vertices, triangles, resolution = 8) {
  if (
    vertices.length < 12 ||
    vertices.length % 3 ||
    !vertices.every(Number.isFinite)
  )
    throw Error("Capture needs finite 3D vertices.");
  if (vertices.length > 900000 || triangles.length > 1800000)
    throw Error(
      "Capture exceeds 300k vertices / 600k triangles. Simplify it first.",
    );
  if (!Number.isInteger(resolution) || resolution < 3 || resolution > 16)
    throw Error("Resolution must be 3–16.");
  if (
    triangles.length % 3 ||
    !triangles.every(
      (i) => Number.isInteger(i) && i >= 0 && i < vertices.length / 3,
    )
  )
    throw Error("Invalid triangle indices.");
  const { min, max } = bounds(vertices),
    span = Math.max(...max.map((v, i) => v - min[i]));
  if (span < 1e-5) throw Error("Capture is empty or too small.");
  const h = span / resolution,
    origin = min.map((v) => v - h * 0.01);
  const size = max.map((v, i) => Math.floor((v - origin[i]) / h) + 1);
  const key = (x, y, z) => `${x},${y},${z}`,
    occupied = new Set();
  const cellOf = (p) =>
    p.map((v, i) =>
      Math.max(0, Math.min(size[i] - 1, Math.floor((v - origin[i]) / h))),
    );
  // Ray parity through triangle geometry fills interiors; surface vertex cells protect
  // open captures. Open surfaces remain approximate envelopes, not inferred solids.
  for (let ix = 0; ix < size[0]; ix++)
    for (let iy = 0; iy < size[1]; iy++) {
      const px = origin[0] + (ix + 0.500013) * h,
        py = origin[1] + (iy + 0.500021) * h,
        hits = [];
      for (let t = 0; t < triangles.length; t += 3) {
        const a = triangles[t] * 3,
          b = triangles[t + 1] * 3,
          c = triangles[t + 2] * 3;
        const ax = vertices[a],
          ay = vertices[a + 1],
          bx = vertices[b],
          by = vertices[b + 1],
          cx = vertices[c],
          cy = vertices[c + 1];
        const det = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy);
        if (Math.abs(det) < 1e-14) continue;
        const u = ((by - cy) * (px - cx) + (cx - bx) * (py - cy)) / det,
          v = ((cy - ay) * (px - cx) + (ax - cx) * (py - cy)) / det;
        if (u >= 0 && v >= 0 && u + v <= 1)
          hits.push(
            u * vertices[a + 2] +
              v * vertices[b + 2] +
              (1 - u - v) * vertices[c + 2],
          );
      }
      hits.sort((a, b) => a - b);
      const unique = hits.filter(
        (z, i) => i === 0 || z - hits[i - 1] > h * 1e-6,
      );
      for (let iz = 0; iz < size[2]; iz++) {
        const z = origin[2] + (iz + 0.5) * h;
        if (unique.filter((v) => v < z).length % 2)
          occupied.add(key(ix, iy, iz));
      }
    }
  for (let v = 0; v < vertices.length; v += 3)
    occupied.add(key(...cellOf(Array.from(vertices.slice(v, v + 3)))));
  const nodes = [],
    tets = [],
    nodeMap = new Map(),
    cellMap = new Map();
  function node(c) {
    const k = key(...c);
    if (!nodeMap.has(k)) {
      nodeMap.set(k, nodes.length / 3);
      nodes.push(...c.map((v, i) => origin[i] + v * h));
    }
    return nodeMap.get(k);
  }
  for (const k of [...occupied].sort()) {
    const cell = k.split(",").map(Number),
      ids = [];
    for (const p of permutations) {
      const c = cell.slice(),
        tet = [node(c)];
      c[p[0]]++;
      tet.push(node(c));
      c[p[1]]++;
      tet.push(node(c));
      c[p[2]]++;
      tet.push(node(c));
      ids.push(tets.length / 4);
      tets.push(...tet);
    }
    cellMap.set(k, ids);
  }
  const rest = new Float64Array(nodes);
  // Binding weights use the same sorted-coordinate tetrahedron, preserving rest
  // positions and every affine map exactly without inverse-distance shrinkage.
  const bindNodes = new Uint32Array((vertices.length / 3) * 4),
    weights = new Float64Array(bindNodes.length);
  for (let v = 0; v < vertices.length / 3; v++) {
    const point = Array.from(vertices.slice(v * 3, v * 3 + 3)),
      cell = cellOf(point),
      f = point.map((q, i) => (q - origin[i]) / h - cell[i]);
    const order = [0, 1, 2].sort((a, b) => f[b] - f[a]),
      pi = permutations.findIndex((p) => p.every((q, i) => q === order[i]));
    const ti = cellMap.get(key(...cell))[pi],
      w = [
        1 - f[order[0]],
        f[order[0]] - f[order[1]],
        f[order[1]] - f[order[2]],
        f[order[2]],
      ];
    for (let j = 0; j < 4; j++) {
      bindNodes[v * 4 + j] = tets[ti * 4 + j];
      weights[v * 4 + j] = w[j];
    }
  }
  // Orient after binding (weights reference node IDs, so are unaffected).
  for (let t = 0; t < tets.length; t += 4)
    if (volume(rest, ...tets.slice(t, t + 4)) < 0)
      [tets[t + 1], tets[t + 2]] = [tets[t + 2], tets[t + 1]];
  const edgeSet = new Map();
  for (let t = 0; t < tets.length; t += 4)
    for (let i = 0; i < 4; i++)
      for (let j = i + 1; j < 4; j++) {
        const a = Math.min(tets[t + i], tets[t + j]),
          b = Math.max(tets[t + i], tets[t + j]);
        edgeSet.set(`${a},${b}`, [a, b]);
      }
  return {
    rest,
    tets: new Uint32Array(tets),
    edges: new Uint32Array([...edgeSet.values()].flat()),
    bindNodes,
    weights,
    h,
    volume: occupied.size * h ** 3,
    cellCount: occupied.size,
  };
}

export function deform(
  cage,
  x,
  out = new Float32Array((cage.bindNodes.length / 4) * 3),
) {
  const { bindNodes: n, weights: w } = cage;
  for (let v = 0; v < n.length / 4; v++)
    for (let a = 0; a < 3; a++) {
      let q = 0;
      for (let j = 0; j < 4; j++) q += w[v * 4 + j] * x[n[v * 4 + j] * 3 + a];
      out[v * 3 + a] = q;
    }
  return out;
}
