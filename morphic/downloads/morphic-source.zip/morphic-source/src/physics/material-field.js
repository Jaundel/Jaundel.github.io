// Discrete XPBD response coefficients. These are NOT continuum elastic moduli.
export function validateField(field) {
  if (!field || ![1, 2].includes(field.edge?.length))
    throw Error("A response field needs one or two edge compliances.");
  if (
    !field.edge.every((v) => Number.isFinite(v) && v >= 1e-8 && v <= 0.1) ||
    !Number.isFinite(field.bulk) ||
    field.bulk < 1e-10 ||
    field.bulk > 0.01 ||
    !Number.isFinite(field.damping) ||
    field.damping < 0 ||
    field.damping > 30 ||
    !Number.isFinite(field.friction) ||
    field.friction < 0 ||
    field.friction > 1
  )
    throw Error("Response coefficients are outside supported bounds.");
  if (
    field.edge.length === 2 &&
    (![0, 1, 2].includes(field.axis) || !Number.isFinite(field.split))
  )
    throw Error("A regional field needs a rest-space split plane.");
  return structuredClone(field);
}

export function edgeCompliances(cage, field) {
  return Float64Array.from({ length: cage.edges.length / 2 }, (_, k) => {
    const a = cage.edges[k * 2],
      b = cage.edges[k * 2 + 1];
    const side =
      field.edge.length === 2 &&
      (cage.rest[a * 3 + field.axis] + cage.rest[b * 3 + field.axis]) / 2 >=
        field.split;
    return field.edge[side ? 1 : 0];
  });
}
