// Small allocation-free numerical primitives shared by preparation and simulation.
export function volume(x, a, b, c, d) {
  a *= 3;
  b *= 3;
  c *= 3;
  d *= 3;
  const ux = x[b] - x[a],
    uy = x[b + 1] - x[a + 1],
    uz = x[b + 2] - x[a + 2];
  const vx = x[c] - x[a],
    vy = x[c + 1] - x[a + 1],
    vz = x[c + 2] - x[a + 2];
  const wx = x[d] - x[a],
    wy = x[d + 1] - x[a + 1],
    wz = x[d + 2] - x[a + 2];
  return (
    (ux * (vy * wz - vz * wy) +
      uy * (vz * wx - vx * wz) +
      uz * (vx * wy - vy * wx)) /
    6
  );
}
export function bounds(x) {
  const min = [Infinity, Infinity, Infinity],
    max = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < x.length; i++) {
    min[i % 3] = Math.min(min[i % 3], x[i]);
    max[i % 3] = Math.max(max[i % 3], x[i]);
  }
  return { min, max };
}
export function finiteArray(x) {
  return x.every(Number.isFinite);
}
export function rms(a, b) {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += (a[i] - b[i]) ** 2;
  return Math.sqrt(s / a.length);
}
