// Distance-constraint response model, paired with scripts/measured_graph.py.
// Unit masses and fixed discretization define an effective response, not a modulus.
export function validateMeasuredAsset(asset) {
  const finiteRows = (a, width, max) =>
    Array.isArray(a) &&
    a.length > 0 &&
    a.length <= max &&
    a.every(
      (r) => Array.isArray(r) && r.length === width && r.every(Number.isFinite),
    );
  if (
    asset?.schema !== "morphic-measured-graph-1" ||
    typeof asset.case !== "string" ||
    !/^[a-z0-9_]{1,80}$/.test(asset.case) ||
    !asset.provenance ||
    typeof asset.provenance !== "object" ||
    !finiteRows(asset.rest, 3, 5000) ||
    !finiteRows(asset.edges, 2, 100000)
  )
    throw Error("Invalid measured-response geometry.");
  const n = asset.rest.length,
    controls = asset.controller?.[0]?.length;
  if (
    !Number.isInteger(controls) ||
    controls < 1 ||
    controls > 100 ||
    !Array.isArray(asset.controller) ||
    asset.controller.length > 1800 ||
    !asset.controller.every(
      (f) => finiteRows(f, 3, controls) && f.length === controls,
    )
  )
    throw Error("Invalid observed controller motion.");
  if (
    !asset.edges.every(
      ([i, j]) =>
        Number.isInteger(i) &&
        Number.isInteger(j) &&
        i >= 0 &&
        i < n &&
        j > i &&
        j < n + controls,
    ) ||
    asset.lengths?.length !== asset.edges.length ||
    !asset.lengths.every((v) => Number.isFinite(v) && v > 1e-7) ||
    asset.region?.length !== asset.edges.length ||
    !asset.region.every((r) => [0, 1, 2].includes(r))
  )
    throw Error("Invalid response-graph connectivity.");
  if (
    !Number.isInteger(asset.objectEdges) ||
    asset.objectEdges < 1 ||
    asset.objectEdges >= asset.edges.length ||
    !asset.edges.every(([, j], e) =>
      e < asset.objectEdges
        ? j < n && asset.region[e] < 2
        : j >= n && asset.region[e] === 2,
    )
  ) {
    throw Error("Invalid object and controller edge partition.");
  }
  const s = asset.settings;
  if (
    !s ||
    s.substeps !== 8 ||
    s.iterations !== 5 ||
    !Number.isFinite(s.friction) ||
    s.friction < 0 ||
    s.friction > 1.5 ||
    s.unitMass !== 1 ||
    s.floorZ !== 0 ||
    JSON.stringify(s.gravity) !== "[0,0,9.81]" ||
    asset.fps !== 30
  )
    throw Error("Unsupported fitted numerical configuration.");
  validateParameters(asset.parameters);
  return asset;
}

export function validateParameters(p) {
  if (
    !Array.isArray(p) ||
    p.length !== 4 ||
    !p.every(Number.isFinite) ||
    p.slice(0, 3).some((v) => v < 1e-9 || v > 0.1) ||
    p[3] < 0 ||
    p[3] > 100
  )
    throw Error("Invalid effective-response parameters.");
  return p;
}

export class MeasuredGraphSolver {
  constructor(asset) {
    this.asset = validateMeasuredAsset(asset);
    this.n = asset.rest.length;
    this.rest = Float64Array.from(asset.rest.flat());
    this.x = Float64Array.from([...this.rest, ...asset.controller[0].flat()]);
    this.v = new Float64Array(this.rest.length);
    this.previous = this.v.slice();
    this.edges = Uint32Array.from(asset.edges.flat());
    this.lengths = Float64Array.from(asset.lengths);
    this.region = Uint8Array.from(asset.region);
    this.lambda = new Float64Array(this.lengths.length);
    this.parameters = asset.parameters.slice();
    this.dt = 1 / (asset.fps * asset.settings.substeps);
    this.tick = 0;
    this.grab = null;
  }

  setParameters(p) {
    this.parameters = validateParameters(p).slice();
  }

  apply(action) {
    if (action.type === "response") this.setParameters(action.parameters);
    else if (action.type === "release") this.grab = null;
    else if (action.type === "grab" || action.type === "move") {
      if (
        !Array.isArray(action.target) ||
        action.target.length !== 3 ||
        !action.target.every((v) => Number.isFinite(v) && Math.abs(v) < 10)
      )
        throw Error("Invalid interaction target.");
      if (action.type === "grab") {
        if (
          !Number.isInteger(action.node) ||
          action.node < 0 ||
          action.node >= this.n
        )
          throw Error("Invalid interaction node.");
        this.grab = { node: action.node, target: action.target.slice() };
      } else if (this.grab) this.grab.target = action.target.slice();
    } else throw Error("Unknown measured-response action.");
  }

  step(controlTarget) {
    const {
      x,
      v,
      n,
      dt,
      previous,
      edges,
      lengths,
      region,
      lambda,
      parameters,
    } = this;
    if (
      controlTarget?.length !== x.length - n * 3 ||
      !controlTarget.every(Number.isFinite)
    )
      throw Error("Invalid controller target.");
    previous.set(x.subarray(0, n * 3));
    const decay = Math.exp(-parameters[3] * dt),
      alpha = parameters.slice(0, 3).map((v) => v / (dt * dt));
    for (let i = 0; i < n; i++) {
      const q = i * 3;
      for (let a = 0; a < 3; a++) v[q + a] *= decay;
      v[q + 2] += 9.81 * dt;
      for (let a = 0; a < 3; a++) x[q + a] += v[q + a] * dt;
    }
    x.set(controlTarget, n * 3);
    lambda.fill(0);
    for (let it = 0; it < this.asset.settings.iterations; it++) {
      for (let e = 0; e < lengths.length; e++) {
        const i = edges[e * 2] * 3,
          j = edges[e * 2 + 1] * 3;
        const dx = x[i] - x[j],
          dy = x[i + 1] - x[j + 1],
          dz = x[i + 2] - x[j + 2];
        const length = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (length < 1e-12) continue;
        const wj = j < n * 3 ? 1 : 0,
          aa = alpha[region[e]];
        const dl = (-(length - lengths[e]) - aa * lambda[e]) / (1 + wj + aa),
          q = dl / length;
        lambda[e] += dl;
        x[i] += dx * q;
        x[i + 1] += dy * q;
        x[i + 2] += dz * q;
        if (wj) {
          x[j] -= dx * q;
          x[j + 1] -= dy * q;
          x[j + 2] -= dz * q;
        }
      }
      if (this.grab) {
        const q = this.grab.node * 3;
        for (let a = 0; a < 3; a++) x[q + a] = this.grab.target[a];
      }
      for (let i = 0; i < n; i++) {
        const q = i * 3;
        if (x[q + 2] > 0) {
          const penetration = x[q + 2];
          x[q + 2] = 0;
          const dx = x[q] - previous[q],
            dy = x[q + 1] - previous[q + 1],
            length = Math.sqrt(dx * dx + dy * dy);
          if (length > 1e-12) {
            const f = Math.min(
              1,
              (this.asset.settings.friction * penetration) / length,
            );
            x[q] -= dx * f;
            x[q + 1] -= dy * f;
          }
        }
      }
    }
    for (let i = 0; i < n * 3; i++) v[i] = (x[i] - previous[i]) / dt;
    this.tick++;
    if (!x.every(Number.isFinite))
      throw Error("Measured-response simulation became non-finite.");
  }

  stepRecorded() {
    const frames = this.asset.controller,
      steps = this.asset.settings.substeps;
    const frame = Math.min(
      Math.floor(this.tick / steps) + 1,
      frames.length - 1,
    );
    const fraction = ((this.tick % steps) + 1) / steps;
    const prev = frames[Math.max(0, frame - 1)],
      next = frames[frame];
    const target = new Float64Array(next.length * 3);
    for (let i = 0; i < next.length; i++)
      for (let a = 0; a < 3; a++)
        target[i * 3 + a] = prev[i][a] + (next[i][a] - prev[i][a]) * fraction;
    if (this.tick >= (frames.length - 1) * steps) target.set(next.flat());
    this.step(target);
  }
}

export function measuredTrajectory(asset) {
  const solver = new MeasuredGraphSolver(asset),
    frames = [Array.from(solver.rest)];
  for (let frame = 1; frame < asset.controller.length; frame++) {
    for (let sub = 0; sub < asset.settings.substeps; sub++)
      solver.stepRecorded();
    frames.push(Array.from(solver.x.subarray(0, solver.n * 3)));
  }
  return frames;
}
