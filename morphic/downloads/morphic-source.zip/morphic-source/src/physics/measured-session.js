import {
  MeasuredGraphSolver,
  validateMeasuredAsset,
} from "./measured-graph.js";

export function validateMeasuredSession(session) {
  if (session?.schema !== "morphic-measured-session-1")
    throw Error("Unsupported response session.");
  const asset = validateMeasuredAsset(session.response);
  if (
    !Array.isArray(session.events) ||
    session.events.length > 20000 ||
    !Number.isInteger(session.endTick) ||
    session.endTick < 0 ||
    session.endTick > 30000 ||
    !Array.isArray(session.finalPositions) ||
    session.finalPositions.length !== asset.rest.length * 3 ||
    !session.finalPositions.every(Number.isFinite)
  ) {
    throw Error("Invalid response session.");
  }
  const probe = new MeasuredGraphSolver(asset);
  let previous = -1;
  for (const event of session.events) {
    if (
      !Number.isInteger(event.tick) ||
      event.tick < previous ||
      event.tick > session.endTick
    )
      throw Error("Invalid session action timing.");
    probe.apply(event.action);
    previous = event.tick;
  }
  if (
    typeof session.appearance?.glb !== "string" ||
    !/^[a-f0-9]{64}$/.test(session.appearance.sha256 ?? "")
  )
    throw Error("Invalid session appearance.");
  return session;
}
