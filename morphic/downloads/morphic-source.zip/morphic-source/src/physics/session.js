import { Solver } from "./solver.js";
export const ENGINE = "morphic-xpbd-3";
export function record(solver, action) {
  solver.apply(action);
  solver.events.push({ tick: solver.tick, action: structuredClone(action) });
}
export function makeSession(solver) {
  return {
    schema: 1,
    engine: ENGINE,
    dt: solver.dt,
    iterations: solver.iterations,
    density: solver.density,
    material: solver.initialMaterial,
    gravity: solver.initialGravity,
    endTick: solver.tick,
    events: solver.events,
    finalPositions: Array.from(solver.x),
  };
}
export function validateSession(s) {
  if (s?.schema !== 1 || ![ENGINE, "morphic-xpbd-2"].includes(s.engine))
    throw Error("Unsupported replay version.");
  if (!Number.isInteger(s.endTick) || s.endTick < 0 || s.endTick > 72000)
    throw Error("Replay duration must be at most ten minutes.");
  if (!Array.isArray(s.events) || s.events.length > 100000)
    throw Error("Invalid replay events.");
  let last = 0;
  for (const e of s.events) {
    if (s.engine === "morphic-xpbd-2" && e.action?.type === "response")
      throw Error("Response fields require replay engine version 3.");
    if (
      !Number.isInteger(e.tick) ||
      e.tick < last ||
      e.tick > s.endTick ||
      !e.action ||
      typeof e.action.type !== "string"
    )
      throw Error("Invalid event order.");
    last = e.tick;
  }
  if (
    !Array.isArray(s.finalPositions) ||
    s.finalPositions.length > 100000 ||
    !s.finalPositions.every(Number.isFinite)
  )
    throw Error("Invalid checkpoint.");
  return s;
}
export function replay(cage, session) {
  const s = validateSession(session),
    solver = new Solver(cage, s);
  let ei = 0;
  for (let tick = 0; tick <= s.endTick; tick++) {
    while (ei < s.events.length && s.events[ei].tick === tick)
      record(solver, s.events[ei++].action);
    if (tick < s.endTick) solver.step();
  }
  return solver;
}
