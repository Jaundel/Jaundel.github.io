import { volume, bounds } from "./math.js";
import { validateField, edgeCompliances } from "./material-field.js";

export const DT = 1 / 120;
// Artistic compliance presets, not material parameters inferred from photographs.
export const MATERIALS = {
  jelly: { edge: 2e-4, bulk: 2e-7, damping: 1.5, friction: 0.65 },
  rubber: { edge: 1e-5, bulk: 1e-8, damping: 2.5, friction: 0.8 },
  foam: { edge: 7e-4, bulk: 6e-5, damping: 5, friction: 0.85 },
};

export class Solver {
  constructor(cage, options = {}) {
    this.cage = cage;
    this.dt = options.dt ?? DT;
    this.iterations = options.iterations ?? 5;
    if (
      !(this.dt > 0 && this.dt <= 1 / 30) ||
      !Number.isInteger(this.iterations) ||
      this.iterations < 1 ||
      this.iterations > 30
    )
      throw Error("Invalid solver settings.");
    this.density = options.density ?? 100;
    this.material = options.material ?? "jelly";
    this.initialMaterial = this.material;
    if (
      !MATERIALS[this.material] ||
      !(this.density > 0 && this.density <= 20000)
    )
      throw Error("Invalid material or density.");
    this.x = cage.rest.slice();
    this.previous = this.x.slice();
    this.v = new Float64Array(this.x.length);
    this.mass = new Float64Array(this.x.length / 3);
    this.invMass = new Float64Array(this.mass.length);
    this.restVolume = new Float64Array(cage.tets.length / 4);
    for (let t = 0; t < cage.tets.length; t += 4) {
      const vol = volume(this.x, ...cage.tets.slice(t, t + 4));
      if (vol <= 1e-14) throw Error("Degenerate tetrahedron.");
      this.restVolume[t / 4] = vol;
      for (let j = 0; j < 4; j++)
        this.mass[cage.tets[t + j]] += (vol * this.density) / 4;
    }
    for (let i = 0; i < this.mass.length; i++)
      this.invMass[i] = this.mass[i] ? 1 / this.mass[i] : 0;
    this.restLength = new Float64Array(cage.edges.length / 2);
    for (let e = 0; e < cage.edges.length; e += 2) {
      const a = cage.edges[e] * 3,
        b = cage.edges[e + 1] * 3;
      this.restLength[e / 2] = Math.hypot(
        this.x[a] - this.x[b],
        this.x[a + 1] - this.x[b + 1],
        this.x[a + 2] - this.x[b + 2],
      );
    }
    this.edgeLambda = new Float64Array(this.restLength.length);
    this.volumeLambda = new Float64Array(this.restVolume.length);
    this.grad = new Float64Array(12);
    this.tick = 0;
    this.gravity = options.gravity ?? 0;
    this.initialGravity = this.gravity;
    this.surface = "floor";
    this.grab = null;
    this.pins = [];
    this.gesture = null;
    this.contacts = new Float64Array(this.x.length);
    this.events = [];
    this.fault = null;
    this.limitedSteps = 0;
    this.candidate = this.x.slice();
  }
  apply(action) {
    const { type } = action;
    if (type === "response") {
      const field = validateField(action.field);
      this.response = field;
      this.edgeCompliance = edgeCompliances(this.cage, field);
    } else if (type === "material") {
      if (!MATERIALS[action.value]) throw Error("Unknown material.");
      this.material = action.value;
      this.response = null;
      this.edgeCompliance = null;
    } else if (type === "gravity") this.gravity = action.value ? -9.81 : 0;
    else if (type === "surface") {
      if (!["floor", "ramp", "sphere"].includes(action.value))
        throw Error("Unknown surface.");
      this.surface = action.value;
    } else if (type === "drop") {
      this.gravity = -9.81;
      this.grab = null;
      this.pins = [];
      this.gesture = null;
      for (let i = 0; i < this.x.length; i += 3) {
        this.x[i + 1] += 1.3;
        this.v[i] = 0.8;
        this.v[i + 1] = 0;
        this.v[i + 2] = 0;
      }
    } else if (type === "grab") {
      const id = action.node;
      if (!Number.isInteger(id) || id < 0 || id >= this.mass.length)
        throw Error("Invalid grab node.");
      this.grab = { node: id, target: checkedTarget(action.target) };
      this.gesture = null;
    } else if (type === "move") {
      if (this.grab) this.grab.target = checkedTarget(action.target);
    } else if (type === "release") this.grab = null;
    else if (type === "pin") {
      const { min } = bounds(this.x);
      this.pins = [];
      for (let i = 0; i < this.mass.length; i++)
        if (this.x[i * 3 + 1] < min[1] + this.cage.h * 0.6)
          this.pins.push({
            node: i,
            target: Array.from(this.x.slice(i * 3, i * 3 + 3)),
          });
    } else if (type === "unpin") this.pins = [];
    else if (type === "squash" || type === "stretch") {
      const { min, max } = bounds(this.x),
        axis = type === "squash" ? 1 : 0,
        center = (min[axis] + max[axis]) / 2;
      const extent = max[axis] - min[axis],
        targets = [];
      for (let i = 0; i < this.mass.length; i++) {
        const q = this.x[i * 3 + axis];
        if (
          q < min[axis] + this.cage.h * 0.65 ||
          q > max[axis] - this.cage.h * 0.65
        )
          targets.push({
            node: i,
            start: Array.from(this.x.slice(i * 3, i * 3 + 3)),
            sign: q < center ? -1 : 1,
          });
      }
      this.gesture = { type, startTick: this.tick, axis, extent, targets };
    } else throw Error("Unknown action.");
  }
  step() {
    if (this.fault) return;
    const { x, v, dt, invMass: w } = this,
      m = this.response ?? MATERIALS[this.material],
      damp = Math.exp(-m.damping * dt);
    this.previous.set(x);
    this.contacts.fill(0);
    for (let i = 0; i < x.length; i++) {
      v[i] *= damp;
      if (i % 3 === 1) v[i] += this.gravity * dt;
      x[i] += v[i] * dt;
    }
    this.edgeLambda.fill(0);
    this.volumeLambda.fill(0);
    for (let it = 0; it < this.iterations; it++) {
      this.solveEdges(this.edgeCompliance ?? m.edge);
      this.solveVolumes(m.bulk);
      for (const pin of this.pins)
        this.constrainPoint(pin.node, pin.target, 1e-9);
      if (this.grab)
        this.constrainPoint(this.grab.node, this.grab.target, 2e-7);
      if (this.gesture) {
        const g = this.gesture,
          age = (this.tick - g.startTick) * dt;
        if (age >= 1.4) this.gesture = null;
        else {
          const amount =
            Math.sin(Math.PI * Math.min(age / 1.4, 1)) *
            (g.type === "squash" ? -0.25 : 0.22) *
            g.extent;
          for (const q of g.targets) {
            const t = q.start.slice();
            t[g.axis] += q.sign * amount;
            this.constrainPoint(q.node, t, 1e-7);
          }
        }
      }
      this.collide();
    }
    // Global backtracking retains a positive oriented volume in thin appendages.
    // Both endpoints satisfy planar contacts, so convex interpolation preserves them.
    if (!this.orientationValid()) {
      this.candidate.set(x);
      let fraction = 0.5;
      this.limitedSteps++;
      do {
        for (let i = 0; i < x.length; i++)
          x[i] =
            this.previous[i] +
            fraction * (this.candidate[i] - this.previous[i]);
        fraction *= 0.5;
      } while (!this.orientationValid() && fraction > 1 / 4096);
      // A saturated handle may request an impossible step. Keep the last valid
      // geometry and advance time so releasing the handle can recover naturally.
      if (!this.orientationValid()) x.set(this.previous);
    }
    for (let i = 0; i < x.length; i++) v[i] = (x[i] - this.previous[i]) / dt;
    // Coulomb-like tangential damping after nonpenetration; no fake restitution kick.
    for (let i = 0; i < x.length; i += 3) {
      const nx = this.contacts[i],
        ny = this.contacts[i + 1],
        nz = this.contacts[i + 2],
        nn = nx * nx + ny * ny + nz * nz;
      if (nn > 0.1) {
        const d = v[i] * nx + v[i + 1] * ny + v[i + 2] * nz;
        v[i] = (v[i] - Math.min(d, 0) * nx) * (1 - m.friction);
        v[i + 1] = (v[i + 1] - Math.min(d, 0) * ny) * (1 - m.friction);
        v[i + 2] = (v[i + 2] - Math.min(d, 0) * nz) * (1 - m.friction);
      }
    }
    this.tick++;
    if (!x.every(Number.isFinite) || x.some((q) => Math.abs(q) > 100)) {
      x.set(this.previous);
      v.fill(0);
      this.fault =
        "Simulation exceeded its stable range. Reset or choose rubber.";
    }
  }
  orientationValid() {
    const t = this.cage.tets;
    for (let k = 0; k < this.restVolume.length; k++)
      if (
        volume(this.x, t[k * 4], t[k * 4 + 1], t[k * 4 + 2], t[k * 4 + 3]) <
        0.02 * this.restVolume[k]
      )
        return false;
    return true;
  }
  solveEdges(compliance) {
    const {
      x,
      invMass: w,
      cage: { edges: e },
      edgeLambda: l,
      restLength: r,
    } = this;
    for (let k = 0; k < r.length; k++) {
      const alpha =
        (typeof compliance === "number" ? compliance : compliance[k]) /
        this.dt ** 2;
      const ia = e[k * 2],
        ib = e[k * 2 + 1],
        a = ia * 3,
        b = ib * 3;
      const dx = x[a] - x[b],
        dy = x[a + 1] - x[b + 1],
        dz = x[a + 2] - x[b + 2],
        len = Math.hypot(dx, dy, dz);
      if (len < 1e-12) continue;
      const dl = (-(len - r[k]) - alpha * l[k]) / (w[ia] + w[ib] + alpha);
      l[k] += dl;
      const sa = (dl * w[ia]) / len,
        sb = (dl * w[ib]) / len;
      x[a] += sa * dx;
      x[a + 1] += sa * dy;
      x[a + 2] += sa * dz;
      x[b] -= sb * dx;
      x[b + 1] -= sb * dy;
      x[b + 2] -= sb * dz;
    }
  }
  solveVolumes(compliance) {
    const {
      x,
      invMass: w,
      cage: { tets: t },
      grad: g,
      restVolume: r,
      volumeLambda: l,
    } = this;
    for (let k = 0; k < r.length; k++) {
      const a = t[k * 4] * 3,
        b = t[k * 4 + 1] * 3,
        c = t[k * 4 + 2] * 3,
        d = t[k * 4 + 3] * 3;
      const ux = x[b] - x[a],
        uy = x[b + 1] - x[a + 1],
        uz = x[b + 2] - x[a + 2],
        vx = x[c] - x[a],
        vy = x[c + 1] - x[a + 1],
        vz = x[c + 2] - x[a + 2],
        wx = x[d] - x[a],
        wy = x[d + 1] - x[a + 1],
        wz = x[d + 2] - x[a + 2];
      g[3] = (vy * wz - vz * wy) / 6;
      g[4] = (vz * wx - vx * wz) / 6;
      g[5] = (vx * wy - vy * wx) / 6;
      g[6] = (wy * uz - wz * uy) / 6;
      g[7] = (wz * ux - wx * uz) / 6;
      g[8] = (wx * uy - wy * ux) / 6;
      g[9] = (uy * vz - uz * vy) / 6;
      g[10] = (uz * vx - ux * vz) / 6;
      g[11] = (ux * vy - uy * vx) / 6;
      for (let j = 0; j < 3; j++) g[j] = -g[3 + j] - g[6 + j] - g[9 + j];
      const vol = ux * g[3] + uy * g[4] + uz * g[5];
      // Relative-volume strain C=V/V0-1, so alpha has a consistent definition.
      const alpha = compliance / this.dt ** 2;
      let denom = alpha;
      for (let j = 0; j < 12; j++) {
        g[j] /= r[k];
        denom += w[t[k * 4 + Math.floor(j / 3)]] * g[j] ** 2;
      }
      const dl = (-(vol / r[k] - 1) - alpha * l[k]) / denom;
      l[k] += dl;
      for (let j = 0; j < 4; j++)
        for (let q = 0; q < 3; q++)
          x[t[k * 4 + j] * 3 + q] += w[t[k * 4 + j]] * g[j * 3 + q] * dl;
    }
  }
  constrainPoint(node, target, compliance) {
    const s =
        this.invMass[node] / (this.invMass[node] + compliance / this.dt ** 2),
      a = node * 3;
    // Bounded positional correction avoids explosive mouse teleports.
    for (let j = 0; j < 3; j++)
      this.x[a + j] += Math.max(
        -0.045,
        Math.min(0.045, (target[j] - this.x[a + j]) * s),
      );
  }
  collide() {
    const { x } = this;
    for (let i = 0; i < x.length; i += 3) {
      if (x[i + 1] < 0.012) {
        x[i + 1] = 0.012;
        this.contacts[i + 1] = 1;
      }
      if (this.surface === "sphere") {
        const dx = x[i] - 0.55,
          dy = x[i + 1] - 0.48,
          dz = x[i + 2],
          len = Math.hypot(dx, dy, dz),
          r = 0.5;
        if (len < r && len > 1e-10) {
          const nx = dx / len,
            ny = dy / len,
            nz = dz / len;
          x[i] += (r - len) * nx;
          x[i + 1] += (r - len) * ny;
          x[i + 2] += (r - len) * nz;
          this.contacts[i] = nx;
          this.contacts[i + 1] = ny;
          this.contacts[i + 2] = nz;
        }
      }
      if (this.surface === "ramp") {
        // Infinite tilted plane above a floor, matches visible ramp slope.
        const nx = 0.2873478856,
          ny = 0.9578262852,
          d = x[i] * nx + x[i + 1] * ny - 0.35;
        if (d < 0.012) {
          x[i] += (0.012 - d) * nx;
          x[i + 1] += (0.012 - d) * ny;
          this.contacts[i] = nx;
          this.contacts[i + 1] = ny;
        }
      }
    }
    if (this.surface === "sphere") this.collideSurfaceSphere();
  }
  collideSurfaceSphere() {
    // Contact on the embedded visual surface, not only on coarse cage vertices.
    const {
      x,
      invMass: w,
      cage: { bindNodes: n, weights: b },
    } = this;
    for (let i = 0; i < n.length; i += 4) {
      let px = 0,
        py = 0,
        pz = 0,
        denom = 0;
      for (let j = 0; j < 4; j++) {
        const a = n[i + j] * 3,
          weight = b[i + j];
        px += weight * x[a];
        py += weight * x[a + 1];
        pz += weight * x[a + 2];
        denom += weight * weight * w[n[i + j]];
      }
      const dx = px - 0.55,
        dy = py - 0.48,
        dz = pz,
        len2 = dx * dx + dy * dy + dz * dz;
      if (len2 >= 0.25 || len2 < 1e-15 || denom < 1e-15) continue;
      const len = Math.sqrt(len2),
        correction = (0.5 - len) / denom;
      for (let j = 0; j < 4; j++) {
        const a = n[i + j] * 3,
          s = correction * b[i + j] * w[n[i + j]];
        x[a] += (s * dx) / len;
        x[a + 1] += (s * dy) / len;
        x[a + 2] += (s * dz) / len;
      }
    }
  }
  diagnostics() {
    let total = 0,
      abs = 0,
      inverted = 0,
      maxStrain = 0,
      ke = 0;
    for (let k = 0; k < this.restVolume.length; k++) {
      const v = volume(this.x, ...this.cage.tets.slice(k * 4, k * 4 + 4));
      total += v;
      abs += Math.abs(v - this.restVolume[k]);
      if (v <= 0) inverted++;
    }
    for (let k = 0; k < this.restLength.length; k++) {
      const a = this.cage.edges[k * 2] * 3,
        b = this.cage.edges[k * 2 + 1] * 3;
      maxStrain = Math.max(
        maxStrain,
        Math.abs(
          Math.hypot(
            this.x[a] - this.x[b],
            this.x[a + 1] - this.x[b + 1],
            this.x[a + 2] - this.x[b + 2],
          ) /
            this.restLength[k] -
            1,
        ),
      );
    }
    for (let i = 0; i < this.v.length; i++)
      ke += 0.5 * this.mass[Math.floor(i / 3)] * this.v[i] ** 2;
    const rest = this.restVolume.reduce((a, b) => a + b, 0);
    return {
      tick: this.tick,
      time: this.tick * this.dt,
      volumeRatio: total / rest,
      meanVolumeError: abs / rest,
      inverted,
      maxStrain,
      kineticEnergy: ke,
      material: this.material,
      surface: this.surface,
      gravity: this.gravity,
      mass: this.mass.reduce((a, b) => a + b, 0),
      limitedSteps: this.limitedSteps,
      fault: this.fault,
    };
  }
}
function checkedTarget(t) {
  if (
    !Array.isArray(t) ||
    t.length !== 3 ||
    !t.every((q) => Number.isFinite(q) && Math.abs(q) < 30)
  )
    throw Error("Invalid handle target.");
  return t.slice();
}
