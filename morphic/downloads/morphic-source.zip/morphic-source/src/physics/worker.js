import { buildCage } from "./cage.js";
import { Solver } from "./solver.js";
import { record, makeSession, validateSession } from "./session.js";
let solver,
  paused = true,
  playing = null,
  eventIndex = 0,
  last = performance.now(),
  debt = 0,
  generation = 0;
let timings = [],
  sentAt = 0;
function sendFrame(force = false) {
  if (!solver) return;
  const now = performance.now();
  if (!force && now - sentAt < 1000 / 60) return;
  sentAt = now;
  const x = Float32Array.from(solver.x),
    sorted = timings.slice().sort((a, b) => a - b);
  postMessage(
    {
      type: "frame",
      generation,
      x,
      stats: {
        ...solver.diagnostics(),
        stepMs: timings.at(-1) ?? 0,
        stepP95: sorted[Math.floor(sorted.length * 0.95)] ?? 0,
        paused,
        playing: !!playing,
      },
    },
    [x.buffer],
  );
}
self.onmessage = ({ data: m }) => {
  try {
    if (m.type === "init") {
      paused = true;
      generation = m.generation;
      const start = performance.now(),
        cage = buildCage(m.vertices, m.triangles, m.resolution);
      solver = new Solver(cage);
      timings = [];
      playing = null;
      debt = 0;
      last = performance.now();
      postMessage({
        type: "ready",
        generation,
        cage,
        prepareMs: performance.now() - start,
      });
      sendFrame(true);
    } else if (m.type === "action" && solver && !playing) {
      record(solver, m.action);
      sendFrame(true);
    } else if (m.type === "pause") {
      paused = m.value;
      last = performance.now();
      debt = 0;
      sendFrame(true);
    } else if (m.type === "reset") {
      solver = new Solver(solver.cage);
      playing = null;
      paused = true;
      debt = 0;
      sendFrame(true);
    } else if (m.type === "save")
      postMessage({ type: "session", session: makeSession(solver) });
    else if (m.type === "replay") {
      playing = validateSession(m.session);
      solver = new Solver(solver.cage, playing);
      eventIndex = 0;
      paused = false;
      debt = 0;
      last = performance.now();
      sendFrame(true);
    }
  } catch (e) {
    paused = true;
    postMessage({ type: "error", message: e.message });
  }
};
setInterval(() => {
  const now = performance.now(),
    elapsed = Math.min((now - last) / 1000, 0.1);
  last = now;
  if (!solver || paused) return;
  debt = Math.min(debt + elapsed, solver.dt * 6);
  try {
    let budget = 0;
    while (debt >= solver.dt && budget++ < 6) {
      if (playing) {
        while (
          eventIndex < playing.events.length &&
          playing.events[eventIndex].tick === solver.tick
        )
          record(solver, playing.events[eventIndex++].action);
        if (solver.tick >= playing.endTick) {
          let error = 0;
          if (playing.finalPositions.length !== solver.x.length)
            throw Error("Replay topology differs from checkpoint.");
          for (let i = 0; i < solver.x.length; i++)
            error = Math.max(
              error,
              Math.abs(solver.x[i] - playing.finalPositions[i]),
            );
          postMessage({ type: "replayComplete", maxError: error });
          playing = null;
          paused = true;
          sendFrame(true);
          break;
        }
      }
      const start = performance.now();
      solver.step();
      timings.push(performance.now() - start);
      if (timings.length > 240) timings.shift();
      debt -= solver.dt;
      if (solver.fault || solver.tick >= 72000) {
        paused = true;
        sendFrame(true);
        break;
      }
    }
    sendFrame();
  } catch (e) {
    paused = true;
    playing = null;
    postMessage({ type: "error", message: e.message });
  }
}, 4);
