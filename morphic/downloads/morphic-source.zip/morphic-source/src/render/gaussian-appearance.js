import * as THREE from "three";

// EWA projection of isotropic source Gaussians, with covariance transported by
// the derivative of Morphic's rest-space displacement field. SH0 appearance only.
// Equations: Kerbl et al. 2023; covariance push-forward: Xie et al. 2024.
const vertexShader = `
in float splatId;
uniform sampler2D splats;
uniform sampler2D nodes;
uniform sampler2D restNodes;
uniform int textureWidth;
uniform vec2 viewportSize;
out vec2 gaussianCoordinate;
out vec4 gaussianColor;
vec4 getSplat(int index) { return texelFetch(splats, ivec2(index % textureWidth,index / textureWidth),0); }
void main(){
  int id=int(splatId)*4;
  vec4 p=getSplat(id),color=getSplat(id+1),ids=getSplat(id+2),weights=getSplat(id+3);
  vec3 delta[4]; vec3 gradients[4]; float raw[4]; float total=0.;vec3 totalGradient=vec3(0.);
  vec3 center=p.xyz;
  for(int k=0;k<4;k++){
    vec3 r=texelFetch(restNodes,ivec2(int(ids[k]),0),0).xyz;
    delta[k]=texelFetch(nodes,ivec2(int(ids[k]),0),0).xyz-r;
    center+=weights[k]*delta[k];
    vec3 difference=p.xyz-r;float distance2=dot(difference,difference);
    raw[k]=1./max(distance2,1.e-10);total+=raw[k];
    gradients[k]=distance2>1.e-10 ? -2.*difference*raw[k]*raw[k] : vec3(0.);
    totalGradient+=gradients[k];
  }
  mat3 F=mat3(1.);
  for(int k=0;k<4;k++) F+=outerProduct(delta[k],(gradients[k]-weights[k]*totalGradient)/total);
  vec4 camera=modelViewMatrix*vec4(center,1.);
  vec4 clip=projectionMatrix*camera;
  if(camera.z>-.01 || clip.w<=0.){gl_Position=vec4(2.,2.,2.,1.);gaussianCoordinate=vec2(4.);gaussianColor=vec4(0.);return;}
  float z=-camera.z;
  float fx=viewportSize.x*projectionMatrix[0][0]*.5;
  float fy=viewportSize.y*projectionMatrix[1][1]*.5;
  vec3 Jx=vec3(fx/z,0.,fx*camera.x/(z*z));
  vec3 Jy=vec3(0.,fy/z,fy*camera.y/(z*z));
  mat3 B=mat3(modelViewMatrix)*F*p.w;
  vec3 bx=transpose(B)*Jx,by=transpose(B)*Jy;
  float a=dot(bx,bx)+.3,b=dot(bx,by),c=dot(by,by)+.3;
  float middle=.5*(a+c),radius=sqrt(max(0.,.25*(a-c)*(a-c)+b*b));
  float lambda1=max(.1,middle+radius),lambda2=max(.1,middle-radius);
  vec2 axis1=abs(b)>1.e-7 ? normalize(vec2(b,lambda1-a)) : (a>=c ? vec2(1.,0.) : vec2(0.,1.));
  vec2 axis2=vec2(-axis1.y,axis1.x);
  vec2 offset=3.*(position.x*sqrt(lambda1)*axis1+position.y*sqrt(lambda2)*axis2);
  clip.xy+=offset*2./viewportSize*clip.w;
  gl_Position=clip;gaussianCoordinate=position.xy*3.;gaussianColor=color;
}`;
const fragmentShader = `
in vec2 gaussianCoordinate;
in vec4 gaussianColor;
out vec4 outputColor;
void main(){
  float radius2=dot(gaussianCoordinate,gaussianCoordinate);
  if(radius2>9.) discard;
  float alpha=min(.99,gaussianColor.a*exp(-.5*radius2));
  if(alpha<.003) discard;
  outputColor=vec4(gaussianColor.rgb,alpha);
}`;

export function gaussianAppearance(packed, rest) {
  validateGaussianData(packed, rest);
  const count = packed.length / 16,
    width = 1024,
    height = Math.ceil((count * 4) / width);
  const data = new Float32Array(width * height * 4);
  data.set(packed);
  const texture = new THREE.DataTexture(
    data,
    width,
    height,
    THREE.RGBAFormat,
    THREE.FloatType,
  );
  texture.needsUpdate = true;
  const n = rest.length / 3,
    nodeData = new Float32Array(n * 4),
    restData = new Float32Array(n * 4);
  for (let i = 0; i < n; i++)
    for (let a = 0; a < 3; a++)
      nodeData[i * 4 + a] = restData[i * 4 + a] = rest[i * 3 + a];
  function nodeTexture(a) {
    const t = new THREE.DataTexture(a, n, 1, THREE.RGBAFormat, THREE.FloatType);
    t.needsUpdate = true;
    return t;
  }
  const current = nodeTexture(nodeData),
    reference = nodeTexture(restData),
    viewport = new THREE.Vector2();
  const geometry = new THREE.InstancedBufferGeometry();
  geometry.setAttribute(
    "position",
    new THREE.Float32BufferAttribute(
      [-1, -1, 0, 1, -1, 0, 1, 1, 0, -1, 1, 0],
      3,
    ),
  );
  geometry.setIndex([0, 1, 2, 0, 2, 3]);
  geometry.instanceCount = count;
  const indices = Float32Array.from({ length: count }, (_, i) => i);
  geometry.setAttribute(
    "splatId",
    new THREE.InstancedBufferAttribute(indices, 1),
  );
  const material = new THREE.ShaderMaterial({
    glslVersion: THREE.GLSL3,
    vertexShader,
    fragmentShader,
    uniforms: {
      splats: { value: texture },
      nodes: { value: current },
      restNodes: { value: reference },
      textureWidth: { value: width },
      viewportSize: { value: viewport },
    },
    transparent: true,
    depthTest: true,
    depthWrite: false,
    toneMapped: false,
  });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.frustumCulled = false;
  mesh.renderOrder = 10;
  const order = Array.from({ length: count }, (_, i) => i),
    depth = new Float64Array(count),
    matrix = new THREE.Matrix4();
  let lastSort = -Infinity,
    dirty = true,
    view = "";
  mesh.onBeforeRender = (renderer, scene, camera) => {
    renderer.getDrawingBufferSize(viewport);
    matrix.multiplyMatrices(camera.matrixWorldInverse, mesh.matrixWorld);
    const key = matrix.elements.join(",");
    if ((dirty || view !== key) && performance.now() - lastSort > 160) {
      const m = matrix.elements;
      for (let i = 0; i < count; i++) {
        const p = i * 16;
        let x = packed[p],
          y = packed[p + 1],
          z = packed[p + 2];
        for (let k = 0; k < 4; k++) {
          const j = packed[p + 8 + k] * 4,
            w = packed[p + 12 + k];
          x += w * (nodeData[j] - restData[j]);
          y += w * (nodeData[j + 1] - restData[j + 1]);
          z += w * (nodeData[j + 2] - restData[j + 2]);
        }
        depth[i] = m[2] * x + m[6] * y + m[10] * z + m[14];
      }
      order.sort((a, b) => depth[a] - depth[b]);
      indices.set(order);
      geometry.attributes.splatId.needsUpdate = true;
      view = key;
      lastSort = performance.now();
      dirty = false;
    }
  };
  return {
    mesh,
    count,
    forceSort() {
      lastSort = -Infinity;
      dirty = true;
    },
    update(x) {
      for (let i = 0; i < n; i++)
        for (let a = 0; a < 3; a++) nodeData[i * 4 + a] = x[i * 3 + a];
      current.needsUpdate = true;
      dirty = true;
    },
    dispose() {
      geometry.dispose();
      material.dispose();
      texture.dispose();
      current.dispose();
      reference.dispose();
    },
  };
}

export function validateGaussianData(packed, rest) {
  if (
    !(packed instanceof Float32Array) ||
    !packed.length ||
    packed.length % 16 ||
    packed.length > 16 * 500000 ||
    !packed.every(Number.isFinite)
  )
    throw Error("Invalid Gaussian appearance data.");
  const n = rest.length / 3;
  for (let p = 0; p < packed.length; p += 16) {
    if (
      packed[p + 3] <= 0 ||
      packed[p + 3] > 1 ||
      packed.subarray(p + 4, p + 8).some((v) => v < 0 || v > 1)
    )
      throw Error("Invalid Gaussian scale or color.");
    let sum = 0;
    for (let k = 0; k < 4; k++) {
      const index = packed[p + 8 + k],
        weight = packed[p + 12 + k];
      if (
        !Number.isInteger(index) ||
        index < 0 ||
        index >= n ||
        weight < 0 ||
        weight > 1
      )
        throw Error("Invalid Gaussian response binding.");
      sum += weight;
    }
    if (Math.abs(sum - 1) > 1e-5)
      throw Error("Gaussian weights must sum to one.");
  }
}
