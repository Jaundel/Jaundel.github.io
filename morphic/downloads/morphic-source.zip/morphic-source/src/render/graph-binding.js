// Appearance uses the same rest-space displacement interpolation as track scoring.
// This is intentionally distinct from the tetrahedral GPU binding in the baseline.
export function bindGraph(vertices, rest, count = 4) {
  const ids = new Uint32Array((vertices.length / 3) * count);
  const weights = new Float64Array(ids.length);
  for (let i = 0; i < vertices.length; i += 3) {
    const nearest = [];
    for (let n = 0; n < rest.length; n += 3) {
      const d =
        (vertices[i] - rest[n]) ** 2 +
        (vertices[i + 1] - rest[n + 1]) ** 2 +
        (vertices[i + 2] - rest[n + 2]) ** 2;
      let j = 0;
      while (j < nearest.length && nearest[j].d <= d) j++;
      if (j < count) {
        nearest.splice(j, 0, { id: n / 3, d });
        if (nearest.length > count) nearest.pop();
      }
    }
    const offset = (i / 3) * count;
    let total = 0;
    for (let j = 0; j < count; j++) {
      ids[offset + j] = nearest[j].id;
      weights[offset + j] = 1 / Math.max(nearest[j].d, 1e-10);
      total += weights[offset + j];
    }
    for (let j = 0; j < count; j++) weights[offset + j] /= total;
  }
  return { ids, weights, rest, vertices, count };
}

export function deformGraph(binding, positions, output) {
  const { ids, weights, rest, vertices, count } = binding;
  for (let i = 0; i < vertices.length; i += 3) {
    for (let a = 0; a < 3; a++) {
      let displacement = 0;
      for (let k = 0; k < count; k++) {
        const b = (i / 3) * count + k,
          q = ids[b] * 3 + a;
        displacement += weights[b] * (positions[q] - rest[q]);
      }
      output[i + a] = vertices[i + a] + displacement;
    }
  }
  return output;
}
