import * as THREE from "three";

// OpenCV camera coordinates (+Y down, +Z forward) to Three's camera convention.
export function recordedCamera(camera, display, calibration, width, height) {
  display.updateMatrixWorld(true);
  const pose = new THREE.Matrix4()
    .fromArray(calibration.c2w.flat())
    .transpose();
  pose.multiply(new THREE.Matrix4().makeScale(1, -1, -1));
  pose.premultiply(display.matrixWorld);
  pose.decompose(camera.position, camera.quaternion, new THREE.Vector3());
  camera.updateMatrixWorld(true);
  const scale = Math.min(
    width / calibration.width,
    height / calibration.height,
  );
  const fx = calibration.K[0][0] * scale,
    fy = calibration.K[1][1] * scale;
  const cx =
    (width - calibration.width * scale) / 2 + calibration.K[0][2] * scale;
  const cy =
    (height - calibration.height * scale) / 2 + calibration.K[1][2] * scale;
  const near = camera.near,
    far = camera.far;
  camera.projectionMatrix.set(
    (2 * fx) / width,
    0,
    1 - (2 * cx) / width,
    0,
    0,
    (2 * fy) / height,
    (2 * cy) / height - 1,
    0,
    0,
    0,
    -(far + near) / (far - near),
    (-2 * far * near) / (far - near),
    0,
    0,
    -1,
    0,
  );
  camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert();
}
