import * as THREE from "three";

const header = `
uniform sampler2D morphicNodes;
uniform sampler2D morphicRest;
uniform float morphicWidth;
attribute vec4 morphicIds;
attribute vec4 morphicWeights;
attribute vec3 morphicRestNormal;
vec3 nodeAt(sampler2D t, float id) { return texture2D(t,vec2((id+.5)/morphicWidth,.5)).xyz; }
mat3 safeInverse(mat3 m) {
  vec3 a=cross(m[1],m[2]),b=cross(m[2],m[0]),c=cross(m[0],m[1]);
  float d=dot(m[0],a); d=abs(d)<1.e-10 ? (d<0. ? -1.e-10:1.e-10) : d;
  return transpose(mat3(a,b,c))/d;
}
mat3 morphicGradient() {
  vec3 r0=nodeAt(morphicRest,morphicIds.x),r1=nodeAt(morphicRest,morphicIds.y),r2=nodeAt(morphicRest,morphicIds.z),r3=nodeAt(morphicRest,morphicIds.w);
  vec3 p0=nodeAt(morphicNodes,morphicIds.x),p1=nodeAt(morphicNodes,morphicIds.y),p2=nodeAt(morphicNodes,morphicIds.z),p3=nodeAt(morphicNodes,morphicIds.w);
  return mat3(p1-p0,p2-p0,p3-p0)*safeInverse(mat3(r1-r0,r2-r0,r3-r0));
}
`;
const position = `vec3 transformed = morphicWeights.x*nodeAt(morphicNodes,morphicIds.x)+morphicWeights.y*nodeAt(morphicNodes,morphicIds.y)+morphicWeights.z*nodeAt(morphicNodes,morphicIds.z)+morphicWeights.w*nodeAt(morphicNodes,morphicIds.w);`;

// Transfer only the coarse cage. Appearance vertices and inverse-transpose normal
// transport are evaluated on the GPU, including depth/shadow passes.
export function bindGPU(capture, cage) {
  const n = cage.rest.length / 3,
    data = new Float32Array(n * 4),
    rest = new Float32Array(n * 4);
  for (let i = 0; i < n; i++)
    for (let j = 0; j < 3; j++)
      data[i * 4 + j] = rest[i * 4 + j] = cage.rest[i * 3 + j];
  function texture(d) {
    const t = new THREE.DataTexture(d, n, 1, THREE.RGBAFormat, THREE.FloatType);
    t.needsUpdate = true;
    return t;
  }
  const current = texture(data),
    reference = texture(rest),
    custom = [];
  function patch(material, normal = true) {
    material.onBeforeCompile = (shader) => {
      shader.uniforms.morphicNodes = { value: current };
      shader.uniforms.morphicRest = { value: reference };
      shader.uniforms.morphicWidth = { value: n };
      shader.vertexShader =
        header +
        shader.vertexShader.replace("#include <begin_vertex>", position);
      if (normal)
        shader.vertexShader = shader.vertexShader.replace(
          "#include <beginnormal_vertex>",
          "#include <beginnormal_vertex>\nobjectNormal = transpose(safeInverse(morphicGradient())) * morphicRestNormal;",
        );
    };
    material.customProgramCacheKey = () => `morphic-gpu-v1-${normal}`;
    material.needsUpdate = true;
  }
  for (const part of capture.parts) {
    const g = part.mesh.geometry,
      start = part.offset * 4,
      end = (part.offset + part.count) * 4;
    g.setAttribute(
      "morphicIds",
      new THREE.BufferAttribute(
        Float32Array.from(cage.bindNodes.slice(start, end)),
        4,
      ),
    );
    g.setAttribute(
      "morphicWeights",
      new THREE.BufferAttribute(
        Float32Array.from(cage.weights.slice(start, end)),
        4,
      ),
    );
    g.setAttribute("morphicRestNormal", g.attributes.normal.clone());
    for (const mat of [].concat(part.mesh.material)) patch(mat);
    const depth = new THREE.MeshDepthMaterial({
      depthPacking: THREE.RGBADepthPacking,
    });
    patch(depth, false);
    part.mesh.customDepthMaterial = depth;
    custom.push(depth);
    part.mesh.frustumCulled = false;
  }
  return {
    update(x) {
      for (let i = 0; i < n; i++)
        for (let j = 0; j < 3; j++) data[i * 4 + j] = x[i * 3 + j];
      current.needsUpdate = true;
    },
    dispose() {
      current.dispose();
      reference.dispose();
      for (const m of custom) m.dispose();
    },
  };
}
