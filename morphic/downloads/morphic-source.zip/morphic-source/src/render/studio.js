import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
export function createStudio(element) {
  const renderer = new THREE.WebGLRenderer({
    antialias: true,
    preserveDrawingBuffer: true,
  });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.85;
  element.append(renderer.domElement);
  const scene = new THREE.Scene();
  scene.background = new THREE.Color("#f5f7fa");
  scene.fog = new THREE.Fog("#f5f7fa", 10, 23);
  const camera = new THREE.PerspectiveCamera(38, 1, 0.01, 60);
  camera.position.set(2.5, 2.3, 3.4);
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.target.set(0, 1, 0);
  controls.enableDamping = true;
  controls.minDistance = 1.4;
  controls.maxDistance = 13;
  controls.maxPolarAngle = Math.PI * 0.49;
  controls.update();
  const pmrem = new THREE.PMREMGenerator(renderer),
    room = new RoomEnvironment(),
    env = pmrem.fromScene(room, 0.04);
  scene.environment = env.texture;
  room.dispose();
  pmrem.dispose();
  const sun = new THREE.DirectionalLight("#fff0da", 2.4);
  sun.position.set(-3, 6, 4);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -5;
  sun.shadow.camera.right = 5;
  sun.shadow.camera.top = 5;
  sun.shadow.camera.bottom = -5;
  sun.shadow.normalBias = 0.018;
  sun.shadow.bias = -0.0002;
  scene.add(sun);
  const rim = new THREE.DirectionalLight("#b1dfe0", 1);
  rim.position.set(4, 3, -4);
  scene.add(rim);
  scene.add(new THREE.HemisphereLight("#d3e5ee", "#a5abb0", 1));
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(80, 80),
    new THREE.MeshStandardMaterial({ color: "#f5f7fa", roughness: 0.83 }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);
  const grid = new THREE.GridHelper(30, 60, "#cbd5df", "#dbe2ea");
  grid.position.y = 0.002;
  grid.material.transparent = true;
  grid.material.opacity = 0.4;
  scene.add(grid);
  const sphere = new THREE.Mesh(
    new THREE.SphereGeometry(0.5, 48, 32),
    new THREE.MeshStandardMaterial({
      color: "#ccd7d4",
      metalness: 0.55,
      roughness: 0.23,
    }),
  );
  sphere.position.set(0.55, 0.48, 0);
  sphere.castShadow = true;
  sphere.receiveShadow = true;
  sphere.visible = false;
  scene.add(sphere);
  const ramp = new THREE.Mesh(
    new THREE.PlaneGeometry(30, 30),
    new THREE.MeshStandardMaterial({
      color: "#dfe7ee",
      roughness: 0.72,
      side: THREE.DoubleSide,
    }),
  );
  ramp.quaternion.setFromUnitVectors(
    new THREE.Vector3(0, 0, 1),
    new THREE.Vector3(0.2873478856, 0.9578262852, 0),
  );
  ramp.position.y = 0.35 / 0.9578262852;
  ramp.receiveShadow = true;
  ramp.visible = false;
  scene.add(ramp);
  const handle = new THREE.Mesh(
    new THREE.SphereGeometry(0.035, 16, 12),
    new THREE.MeshBasicMaterial({ color: "#1d63b7", depthTest: false }),
  );
  handle.renderOrder = 100;
  handle.visible = false;
  scene.add(handle);
  let wire;
  let resizeLocked = false;
  const resize = () => {
    if (resizeLocked) return;
    const w = element.clientWidth,
      h = element.clientHeight;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  };
  new ResizeObserver(resize).observe(element);
  function showCage(cage, x, visible) {
    if (!wire) {
      wire = new THREE.LineSegments(
        new THREE.BufferGeometry(),
        new THREE.LineBasicMaterial({
          color: "#1d63b7",
          transparent: true,
          opacity: 0.35,
          depthTest: false,
        }),
      );
      wire.renderOrder = 90;
      scene.add(wire);
    }
    wire.visible = visible;
    if (!visible) return;
    const colored = !!cage.regions;
    if (wire.material.vertexColors !== colored) {
      wire.material.vertexColors = colored;
      wire.material.color.set(colored ? "#ffffff" : "#1d63b7");
      wire.material.needsUpdate = true;
    }
    if (colored && wire.userData.regions !== cage.regions) {
      const colors = new Float32Array(cage.edges.length * 3);
      const palette = [new THREE.Color("#1d63b7"), new THREE.Color("#a15b14")];
      for (let i = 0; i < cage.edges.length; i++) {
        palette[cage.regions[Math.floor(i / 2)]].toArray(colors, i * 3);
      }
      wire.geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
      wire.userData.regions = cage.regions;
    }
    let p = wire.geometry.attributes.position;
    if (!p || p.count !== cage.edges.length) {
      p = new THREE.BufferAttribute(new Float32Array(cage.edges.length * 3), 3);
      wire.geometry.setAttribute("position", p);
    }
    for (let i = 0; i < cage.edges.length; i++)
      for (let j = 0; j < 3; j++) p.array[i * 3 + j] = x[cage.edges[i] * 3 + j];
    p.needsUpdate = true;
    wire.geometry.computeBoundingSphere();
  }
  return {
    renderer,
    scene,
    camera,
    controls,
    lockSize(width, height) {
      resizeLocked = true;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    },
    unlockSize() {
      resizeLocked = false;
      resize();
    },
    handle,
    showCage,
    setSurface(s) {
      sphere.visible = s === "sphere";
      ramp.visible = s === "ramp";
    },
    home() {
      camera.position.set(2.5, 2.3, 3.4);
      controls.target.set(0, 1, 0);
      controls.update();
    },
    render() {
      if (controls.enabled) controls.update();
      renderer.render(scene, camera);
    },
  };
}
