import "./research-article.css";

async function mountHistoricalStudy() {
  const data = await fetch("./measured/experiment.json").then((r) => {
    if (!r.ok) throw Error("Evidence package unavailable.");
    return r.json();
  });
  const cases = [
    ["single_lift_sloth", "Lift", "Fit"],
    ["single_push_sloth", "Push", "Fit"],
    ["double_lift_sloth", "Double lift", "Validation"],
    ["double_stretch_sloth", "Stretch", "Test"],
  ];
  const models = ["default", "jointUniform", "jointRegional"];
  const mm = (v) => (v * 1000).toFixed(2);
  const metric = (c, m, key) =>
    data.metrics.find((row) => row.case === c && row.model === m)[key];
  function resultRows(key) {
    return cases
      .map(
        ([c, title, role]) =>
          `<tr><td>${title}<small>${role}</small></td>${models.map((m) => `<td>${mm(metric(c, m, key))}</td>`).join("")}</tr>`,
      )
      .join("");
  }
  document.querySelector("#track-results").innerHTML = resultRows(
    "filteredTrackRMSEMetres",
  );
  document.querySelector("#landmark-results").innerHTML = resultRows(
    "landmarkMeanErrorMetres",
  );

  const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)");
  for (const comparison of document.querySelectorAll("[data-gif-comparison]")) {
    const image = comparison.querySelector("img");
    const recording = comparison.querySelector("select");
    const updateComparison = () => {
      const caseId = recording.value;
      const action = recording.selectedOptions[0].textContent.trim();
      const gifSuffix = comparison.dataset.gifSuffix ?? "-landmarks";
      const stillSuffix = comparison.dataset.stillSuffix ?? "-frame-000";
      const altTail =
        comparison.dataset.altTail ??
        "recording compared with the default and jointly fitted Morphic responses";
      image.src = reducedMotion.matches
        ? `./media/measured/${caseId}${stillSuffix}.jpg`
        : `./media/measured/${caseId}${gifSuffix}.gif`;
      image.alt = `${action} ${altTail}`;
    };
    recording.addEventListener("change", updateComparison);
    reducedMotion.addEventListener("change", updateComparison);
  }

  const staticGifs = document.querySelectorAll("[data-static-gif]");
  const updateStaticGifs = () =>
    staticGifs.forEach((image) => {
      image.src = reducedMotion.matches
        ? image.dataset.staticSrc
        : image.dataset.animatedSrc;
    });
  reducedMotion.addEventListener("change", updateStaticGifs);
  updateStaticGifs();

  // Each comparison file contains all its panels: decoding cannot desynchronize them.
  for (const figure of document.querySelectorAll("[data-video-control]")) {
    const video = figure.querySelector("video"),
      button = figure.querySelector("button"),
      range = figure.querySelector("input[type=range]"),
      time = figure.querySelector("output"),
      select = figure.querySelector("select");
    button.addEventListener("click", () =>
      video.paused ? video.play() : video.pause(),
    );
    video.addEventListener("play", () => (button.textContent = "Pause"));
    video.addEventListener(
      "pause",
      () => (button.textContent = "Play comparison"),
    );
    video.addEventListener("timeupdate", () => {
      range.value = video.currentTime * 30;
      time.textContent = `${video.currentTime.toFixed(2)} s`;
    });
    video.addEventListener(
      "loadedmetadata",
      () => (range.max = Math.max(0, Math.round(video.duration * 30) - 1)),
    );
    range.addEventListener("input", () => {
      video.pause();
      video.currentTime = Number(range.value) / 30;
    });
    if (select)
      select.addEventListener("change", () => {
        video.pause();
        video.src = `./media/measured/${select.value}-landmarks.mp4`;
        video.poster = `./media/measured/${select.value}-frame-000.jpg`;
        video.load();
      });
  }

  const appearance = document.querySelector("#appearance-compare");
  const mesh = appearance.querySelector(".top");
  const divider = appearance.querySelector(".divider");
  let appearanceSplit = 50;
  function setAppearanceSplit(value) {
    appearanceSplit = Math.max(0, Math.min(100, value));
    mesh.style.clipPath = `inset(0 ${100 - appearanceSplit}% 0 0)`;
    divider.style.left = `${appearanceSplit}%`;
    divider.setAttribute("aria-valuenow", Math.round(appearanceSplit));
  }
  function splitFromPointer(event) {
    const bounds = appearance.getBoundingClientRect();
    setAppearanceSplit(((event.clientX - bounds.left) / bounds.width) * 100);
  }
  divider.addEventListener("pointerdown", (event) => {
    divider.setPointerCapture(event.pointerId);
    splitFromPointer(event);
  });
  divider.addEventListener("pointermove", (event) => {
    if (divider.hasPointerCapture(event.pointerId)) splitFromPointer(event);
  });
  divider.addEventListener("keydown", (event) => {
    const movement = { ArrowLeft: -2, ArrowRight: 2 }[event.key];
    if (movement) {
      event.preventDefault();
      setAppearanceSplit(appearanceSplit + movement);
    } else if (event.key === "Home") setAppearanceSplit(0);
    else if (event.key === "End") setAppearanceSplit(100);
  });

  const load = document.querySelector("#load-studio");
  load.addEventListener("click", () => {
    const frame = document.createElement("iframe");
    frame.className = "interactive";
    frame.title = "Morphic interactive fitted response";
    frame.src = "./?mode=measured&embed=1";
    frame.loading = "lazy";
    load.replaceWith(frame);
  });
}

function revealLinkedSection() {
  let id;
  try { id = decodeURIComponent(location.hash.slice(1)); } catch { return; }
  const target = document.getElementById(id);
  if (!target) return;
  for (let parent = target.parentElement; parent; parent = parent.parentElement) {
    if (parent.tagName === "DETAILS") parent.open = true;
  }
  requestAnimationFrame(() => target.scrollIntoView());
}
window.addEventListener("hashchange", revealLinkedSection);
mountHistoricalStudy().then(revealLinkedSection).catch(() => {
  document.getElementById("article-status").textContent =
    "Interactive evidence could not load. Reload to try again.";
});
