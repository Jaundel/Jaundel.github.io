import "./simple-studio.css";

const ACTION_LABELS = {
  save: "Save session",
  load: "Open session",
  import: "Open 3D file",
  export: "Export 3D",
  photo: "Save image",
  "record-video": "Export video",
  replay: "Replay saved actions",
  home: "Reset view",
};
const SLOTH_RECORDINGS = new Set([
  "single_lift_sloth",
  "single_push_sloth",
  "double_lift_sloth",
  "double_stretch_sloth",
]);
const $ = (id) => document.getElementById(id);

// Move the existing controls, preserving their listeners and session behavior.
export function simplifyStudio(measured = false) {
  if (document.body.classList.contains("embedded")) return;
  document.body.classList.add("simple-studio");
  const header = document.querySelector("header");
  const aside = document.querySelector("main > aside");
  const picker = $(measured ? "example" : "asset");
  picker.setAttribute("aria-label", "Choose an object");
  for (const option of picker.options)
    option.textContent = option.textContent.split(" · ")[0];
  aside.querySelector(`label[for="${picker.id}"]`)?.remove();
  header.append(picker);

  const panel = document.createElement("dialog");
  panel.id = "studio-options";
  panel.setAttribute("aria-labelledby", "studio-options-title");
  panel.innerHTML =
    '<div class="options-heading"><h2 id="studio-options-title">Studio options</h2><button type="button" aria-label="Close options">×</button></div><div class="options-actions"></div>';
  document.getElementById("app").append(panel);
  const actions = panel.querySelector(".options-actions");
  const close = panel.querySelector("button");
  close.onclick = () => panel.close();
  panel.addEventListener("click", (event) => {
    if (event.target === panel) {
      const r = panel.getBoundingClientRect();
      if (
        event.clientX < r.left ||
        event.clientX > r.right ||
        event.clientY < r.top ||
        event.clientY > r.bottom
      )
        panel.close();
    }
  });
  for (const [id, label] of Object.entries(ACTION_LABELS)) {
    const control = $(id);
    if (!control) continue;
    control.textContent = label;
    actions.append(control);
    control.addEventListener("click", () => panel.close());
  }
  const create = header.querySelector(".button-link, #capture-open");
  if (create) {
    create.textContent = "Create from capture";
    actions.prepend(create);
    create.addEventListener("click", () => panel.close());
  }
  const article = header.querySelector(".header-note");
  if (article) {
    article.textContent = "About";
    article.className = "studio-about";
    header.append(article);
  }
  const more = document.createElement("button");
  more.className = "studio-more";
  more.textContent = "•••";
  more.title = "More options";
  more.setAttribute("aria-label", "More options");
  more.onclick = () => panel.showModal();
  header.append(more);
  aside
    .querySelectorAll("h1, .intro, .measured-intro, .research-link")
    .forEach((el) => el.remove());
  aside.querySelectorAll("details").forEach((el) => {
    if (el.children.length === 1 && el.firstElementChild.tagName === "SUMMARY")
      el.remove();
  });
  panel.append(aside);

  const transport =
    document.querySelector(".transport") || document.createElement("div");
  transport.className = "transport";
  const play = $("play");
  play.textContent = "▶";
  play.title = "Play / pause";
  const reset = $("reset");
  reset.textContent = "↺";
  reset.title = "Reset object";
  reset.setAttribute("aria-label", "Reset object");
  transport.prepend(play, reset);
  if (!measured) {
    transport.append($("drop"));
    document.querySelector(".workspace").append(transport);
  }
  document.querySelector(".stage-bottom span").textContent = "Drag to interact";
  mountSourcePanel(measured, aside);
}

function mountSourcePanel(measured, aside) {
  const viewport = $("viewport");
  const presentation = document.createElement("div");
  presentation.className = "object-presentation";
  viewport.before(presentation);
  const source = measured
    ? document.createElement("section")
    : $("capture-story");
  source.classList.add("object-source");
  source.setAttribute(
    "aria-label",
    measured ? "Source recording" : "Source photographs",
  );
  if (measured) {
    source.innerHTML =
      '<h2>From recorded motion</h2><p>The captured movement becomes an object you can interact with.</p><a class="source-animation" target="_blank" rel="noreferrer"><img alt="Observed sloth recording alongside simulated motion" /></a><p class="source-caption">Observed video and simulated response · PhysTwin data</p><a class="source-article" href="./article.html#experiments">See how it works</a>';
    const image = source.querySelector("img");
    function updateSource() {
      const recording = $("asset").value;
      const supported = SLOTH_RECORDINGS.has(recording);
      source.hidden = !supported;
      if (!supported) return;
      const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
      image.src = reduced
        ? `./media/measured/${recording}-frame-000.jpg`
        : `./media/measured/${recording}-landmarks.gif`;
      source.querySelector(".source-animation").href =
        `./media/measured/${recording}-landmarks.gif`;
    }
    $("asset").addEventListener("change", updateSource);
    $("asset").addEventListener("recordingloaded", updateSource);
    updateSource();
    aside.querySelector(".sloth-preview")?.remove();
  } else {
    const heading = document.createElement("h2");
    heading.textContent = "From photographs";
    source.prepend(heading);
    source.querySelector(".fine").textContent =
      "Seven views became this 3D glove. Three of the input photos are shown here.";
    const caption = document.createElement("p");
    caption.className = "source-caption";
    caption.textContent = "Reconstructed shape · assigned soft-body response";
    source.append(caption);
  }
  presentation.append(source, viewport);
  mountSourceToggle(presentation, source);
}

function mountSourceToggle(presentation, source) {
  const sourceToggle = document.createElement("button");
  sourceToggle.className = "source-toggle";
  sourceToggle.type = "button";
  source.id ||= "recording-source";
  sourceToggle.setAttribute("aria-controls", source.id);
  function setSourceOpen(open) {
    presentation.classList.toggle("source-collapsed", !open);
    source.inert = !open;
    sourceToggle.setAttribute("aria-expanded", String(open));
    sourceToggle.setAttribute(
      "aria-label",
      open ? "Hide source panel" : "Show source panel",
    );
    sourceToggle.title = open ? "Hide source panel" : "Show source panel";
    sourceToggle.textContent = open ? "‹" : "›";
  }
  sourceToggle.onclick = () =>
    setSourceOpen(presentation.classList.contains("source-collapsed"));
  presentation.append(sourceToggle);
  setSourceOpen(true);
}
