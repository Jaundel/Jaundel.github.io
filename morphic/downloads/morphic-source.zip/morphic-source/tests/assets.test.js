import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { inspectGLB, geometryFromGLB } from "../src/io/glb.js";
import { buildCage, deform } from "../src/physics/cage.js";
const manifest = JSON.parse(
  await readFile("public/assets/manifest.json", "utf8"),
);
for (const a of manifest)
  test(`${a.id}: source hash, import, and appearance geometry binding`, async () => {
    const b = await readFile(`public/assets/${a.id}.glb`),
      buffer = b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
    assert.equal(createHash("sha256").update(b).digest("hex"), a.sha256);
    const { json } = inspectGLB(buffer);
    assert.ok(json.images.length > 0);
    assert.ok(json.images.every((i) => i.bufferView !== undefined));
    const g = geometryFromGLB(buffer),
      c = buildCage(g.vertices, g.triangles, 8),
      bound = deform(c, c.rest);
    assert.equal(bound.length, g.vertices.length);
    let max = 0;
    for (let i = 0; i < bound.length; i++)
      max = Math.max(max, Math.abs(bound[i] - g.vertices[i]));
    assert.ok(max < 1e-6);
  });
test("GLB parser rejects truncated headers and hostile lengths", () => {
  assert.throws(() => inspectGLB(new ArrayBuffer(7)));
  const b = new ArrayBuffer(28),
    v = new DataView(b);
  v.setUint32(0, 0x46546c67, true);
  v.setUint32(4, 2, true);
  v.setUint32(8, 28, true);
  v.setUint32(12, 999999, true);
  assert.throws(() => inspectGLB(b), /chunk length/);
});
