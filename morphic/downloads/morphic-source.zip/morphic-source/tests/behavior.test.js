import test from "node:test";
import assert from "node:assert/strict";
import {
  specimen,
  SETTINGS,
  INITIAL,
  loading,
  observe,
} from "../src/behavior/fixture.js";
import {
  predict,
  fitResponse,
  evaluate,
  makePhysicalAsset,
  deployAsset,
  verifyReplay,
  validateTrial,
} from "../src/behavior/experiment.js";
import { Solver } from "../src/physics/solver.js";
import { knownCage } from "../src/behavior/known-cage.js";
import { score } from "../src/behavior/experiment.js";
import { makeSession, replay } from "../src/physics/session.js";

test("baseline engine-2 sessions still replay without response events", () => {
  const { cage } = specimen(),
    solver = new Solver(cage);
  for (let i = 0; i < 20; i++) solver.step();
  const session = makeSession(solver);
  session.engine = "morphic-xpbd-2";
  delete session.gravity;
  delete session.material;
  assert.deepEqual(replay(cage, session).x, solver.x);
});

test("held-out observations cannot enter the fitting API", () => {
  const { cage } = specimen();
  const trial = observe(
    cage,
    SETTINGS,
    INITIAL,
    loading(cage, { endTick: 90 }),
    { role: "test" },
  );
  assert.throws(
    () => fitResponse(cage, SETTINGS, [trial], INITIAL),
    /held-out/,
  );
});

test("known specimen mass, topology, and embedded marker observation contract", () => {
  const { cage } = specimen();
  const rebuilt = knownCage(
    Array.from(cage.rest),
    Array.from(cage.tets),
    cage.h,
  );
  assert.deepEqual(rebuilt.edges, cage.edges);
  assert.ok(
    Math.abs(new Solver(rebuilt, SETTINGS).diagnostics().mass - 4.1472) < 1e-10,
  );
  assert.equal(
    score(
      { frames: [{ tick: 0, x: Array.from(cage.rest) }] },
      [
        {
          tick: 0,
          points: [
            { vertex: 4, position: Array.from(cage.rest.slice(12, 15)) },
          ],
        },
      ],
      cage,
    ).rmseM,
    0,
  );
});

test("response replay preserves nondefault initial gravity", () => {
  const { cage } = specimen();
  const p = predict(
    cage,
    { ...SETTINGS, gravity: -9.81 },
    INITIAL,
    loading(cage, { endTick: 90 }),
    [90],
  );
  assert.equal(verifyReplay(cage, p), 0);
});
test("prediction does not read observations, and fitted-field replay is exact", () => {
  const { cage } = specimen(),
    input = loading(cage, { endTick: 90 });
  Object.defineProperty(input, "observations", {
    get() {
      throw Error("Test leakage");
    },
  });
  const result = predict(
    cage,
    SETTINGS,
    { ...INITIAL, edge: [1e-5, 5e-4] },
    input,
    [30, 90],
  );
  assert.equal(verifyReplay(cage, result), 0);
});
test("deployment rejects changed numerical settings or geometry", () => {
  const { cage } = specimen();
  const asset = makePhysicalAsset(
    cage,
    SETTINGS,
    { field: INITIAL },
    { kind: "synthetic" },
  );
  assert.deepEqual(
    deployAsset(cage, SETTINGS, JSON.parse(JSON.stringify(asset))),
    INITIAL,
  );
  assert.throws(
    () => deployAsset(cage, { ...SETTINGS, dt: 1 / 240 }, asset),
    /refit/,
  );
  const altered = { ...cage, rest: cage.rest.slice() };
  altered.rest[0] += 0.001;
  assert.throws(() => deployAsset(altered, SETTINGS, asset), /refit/);
});
test("invalid fields and observation duplicates fail explicitly; presets clear a field", () => {
  const { cage } = specimen(),
    solver = new Solver(cage);
  assert.throws(
    () =>
      solver.apply({ type: "response", field: { ...INITIAL, edge: [NaN] } }),
    /bounds/,
  );
  solver.apply({ type: "response", field: INITIAL });
  solver.apply({ type: "material", value: "rubber" });
  assert.equal(solver.response, null);
  const t = observe(cage, SETTINGS, INITIAL, loading(cage, { endTick: 90 }));
  t.observations[0].points.push(t.observations[0].points[0]);
  assert.throws(() => validateTrial(cage, t), /duplicate/);
});
test("training on a separate action improves a synthetic held-out prediction", () => {
  const { cage } = specimen(),
    truth = { ...INITIAL, edge: [2e-5], damping: 4 };
  const train = observe(cage, SETTINGS, truth, loading(cage, { endTick: 90 }), {
    stride: 8,
  });
  const heldout = observe(
    cage,
    SETTINGS,
    truth,
    loading(cage, { axis: 2, endTick: 90 }),
    { role: "test", stride: 8 },
  );
  const fit = fitResponse(cage, SETTINGS, [train], INITIAL, { rounds: 6 });
  assert.ok(
    evaluate(cage, SETTINGS, fit.field, heldout).rmseM <
      evaluate(cage, SETTINGS, INITIAL, heldout).rmseM * 0.5,
  );
});
