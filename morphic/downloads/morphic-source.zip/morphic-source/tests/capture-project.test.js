import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import {
  validateCaptureFiles,
  prepareCaptureProject,
  validateCaptureReview,
} from "../src/io/capture-project.js";

test("capture submission rejects mixed media, empty files and oversize input", () => {
  const photo = new File(["abc"], "photo.png", { type: "image/png" });
  const video = new File(["abc"], "video.mp4", { type: "video/mp4" });
  assert.equal(validateCaptureFiles([photo]), "photos");
  assert.equal(validateCaptureFiles([video]), "video");
  assert.throws(
    () => validateCaptureFiles([photo, video]),
    /separate captures/,
  );
  assert.throws(
    () =>
      validateCaptureFiles([new File([], "empty.png", { type: "image/png" })]),
    /empty/,
  );
  assert.throws(
    () =>
      validateCaptureFiles([{ type: "image/png", size: 301 * 1024 * 1024 }]),
    /300 MB/,
  );
  assert.throws(() => validateCaptureFiles(Array(81).fill(photo)), /80 photos/);
  assert.throws(
    () =>
      validateCaptureFiles([
        new File(["x"], "page.html", { type: "text/html" }),
      ]),
    /Use JPEG/,
  );
});

test("saved view selections preserve exclusions, empty choices and legacy captures", async () => {
  const photos = [
    new File(["one"], "a.png", { type: "image/png" }),
    new File(["two"], "b.png", { type: "image/png" }),
  ];
  const review = { recipe: "photos-source-order-v1", selectedIndices: [1] };
  const project = await prepareCaptureProject(photos, review);
  review.selectedIndices.push(0);
  assert.deepEqual(project.review.selectedIndices, [1]);
  assert.equal(project.files.length, 2); // Excluded views remain original source evidence.
  assert.deepEqual(
    validateCaptureReview(
      { recipe: "video-midpoints-12-v1", selectedIndices: [] },
      "video",
      1,
    ).selectedIndices,
    [],
  );
  assert.equal(validateCaptureReview(undefined, "photos", 2), undefined);
  for (const indices of [[2], [-1], [0, 0], [0.5], [NaN]])
    assert.throws(
      () =>
        validateCaptureReview(
          { recipe: "photos-source-order-v1", selectedIndices: indices },
          "photos",
          2,
        ),
      /invalid/,
    );
  assert.throws(
    () =>
      validateCaptureReview(
        { recipe: "video-midpoints-12-v1", selectedIndices: [12] },
        "video",
        1,
      ),
    /invalid/,
  );
  assert.throws(
    () =>
      validateCaptureReview(
        { recipe: "video-midpoints-12-v2", selectedIndices: [0] },
        "video",
        1,
      ),
    /unsupported/,
  );
  assert.throws(
    () =>
      validateCaptureReview(
        {
          recipe: "photos-source-order-v1",
          selectedIndices: Array.from({ length: 13 }, (_, i) => i),
        },
        "photos",
        20,
      ),
    /invalid/,
  );
});

test("capture provenance hashes original bytes and preserves source ordering", async () => {
  const files = [
    new File(["abc"], "first.png", { type: "image/png" }),
    new File(["different"], "second.png", { type: "image/png" }),
  ];
  const project = await prepareCaptureProject(files);
  assert.equal(project.state, "captured");
  assert.deepEqual(
    project.sources.map((source) => source.name),
    ["first.png", "second.png"],
  );
  assert.equal(
    project.sources[0].sha256,
    createHash("sha256").update("abc").digest("hex"),
  );
  assert.equal(await project.files[1].text(), "different");
  assert.notEqual(project.id, (await prepareCaptureProject(files)).id);
});
