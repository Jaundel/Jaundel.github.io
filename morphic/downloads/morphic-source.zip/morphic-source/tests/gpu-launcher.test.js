import test from "node:test";
import assert from "node:assert/strict";
import {
  validateConnection,
  connectionEnvironment,
} from "../scripts/start-gpu-studio.mjs";

const now = Date.parse("2026-09-16T12:00:00Z");
const connection = {
  host: "gpu.example",
  sshPort: "12345",
  key: "existing-key",
  until: "2026-09-16T14:00:00+00:00",
  jobs: "2",
};

test("reopening saved connection retains deadline and allowance instead of extending them", () => {
  const first = validateConnection(connection, now);
  const resumed = validateConnection(
    JSON.parse(JSON.stringify(first)),
    now + 30 * 60_000,
  );
  assert.deepEqual(resumed, first);
  assert.deepEqual(connectionEnvironment(resumed), {
    MORPHIC_GPU_HOST: "gpu.example",
    MORPHIC_GPU_PORT: "12345",
    MORPHIC_GPU_KEY: first.key,
    MORPHIC_GPU_DEADLINE: "2026-09-16T14:00:00.000Z",
    MORPHIC_GPU_MAX_JOBS: "2",
  });
  assert.equal(connection.until, "2026-09-16T14:00:00+00:00");
});

test("launcher rejects ambiguous deadlines, expired sessions and invalid connection fields", () => {
  for (const change of [
    { until: "2026-09-16T14:00:00" },
    { until: "garbageZ" },
    { until: "2026-09-16T12:16:00Z" },
    { host: "-oProxyCommand=bad" },
    { host: "gpu.example; echo bad" },
    { sshPort: "70000" },
    { sshPort: "0" },
    { jobs: 0 },
    { jobs: 11 },
    { jobs: 1.5 },
    { key: "" },
  ]) {
    assert.throws(() => validateConnection({ ...connection, ...change }, now));
  }
  assert.throws(
    () => validateConnection(connection, now + 2 * 3_600_000),
    /too little time/,
  );
});
