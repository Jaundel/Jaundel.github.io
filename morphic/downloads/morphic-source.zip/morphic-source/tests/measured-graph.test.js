import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  MeasuredGraphSolver,
  measuredTrajectory,
  validateMeasuredAsset,
} from "../src/physics/measured-graph.js";
import { bindGraph, deformGraph } from "../src/render/graph-binding.js";
const asset = JSON.parse(
  readFileSync(
    new URL("../public/measured/single_lift_sloth/asset.json", import.meta.url),
  ),
);

test("measured response follows recorded loading and remains above the table", () => {
  const frames = measuredTrajectory(asset);
  assert.equal(frames.length, asset.controller.length);
  assert.deepEqual(frames[0], asset.rest.flat());
  assert.ok(frames.at(-1).some((v, i) => Math.abs(v - frames[0][i]) > 0.005));
  for (const f of frames)
    for (let i = 2; i < f.length; i += 3) assert.ok(f[i] <= 1e-12);
});

test("response edits and hand interventions replay deterministically", () => {
  const actions = [
    { tick: 5, action: { type: "grab", node: 12, target: [0.2, 0.1, -0.2] } },
    { tick: 18, action: { type: "move", target: [0.23, 0.13, -0.18] } },
    { tick: 26, action: { type: "release" } },
    {
      tick: 35,
      action: { type: "response", parameters: [2e-5, 8e-5, 1e-6, 4] },
    },
  ];
  function run(a) {
    const s = new MeasuredGraphSolver(a);
    for (let t = 0; t < 80; t++) {
      for (const e of actions) if (e.tick === t) s.apply(e.action);
      s.stepRecorded();
    }
    return Array.from(s.x);
  }
  const before = JSON.stringify(asset);
  assert.deepEqual(run(asset), run(JSON.parse(before)));
  assert.equal(JSON.stringify(asset), before);
});

test("effective parameters never silently override the fitted numerical settings", () => {
  for (const [key, value] of [
    ["substeps", 4],
    ["iterations", 6],
    ["unitMass", 2],
    ["gravity", [0, 0, 0]],
  ]) {
    const a = structuredClone(asset);
    a.settings[key] = value;
    assert.throws(() => validateMeasuredAsset(a), /configuration/);
  }
  const a = structuredClone(asset);
  a.region[0] = 3;
  assert.throws(() => validateMeasuredAsset(a), /connectivity/);
});

test("response graph interpolates original appearance exactly at rest and under translation", () => {
  const rest = Float64Array.from([0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1]);
  const surface = Float64Array.from([0.1, 0.2, 0.3, 0.4, 0.1, 0.1]);
  const binding = bindGraph(surface, rest),
    output = new Float64Array(surface.length);
  assert.deepEqual(
    Array.from(deformGraph(binding, rest, output)),
    Array.from(surface),
  );
  const moved = rest.map((v, i) => v + [0.3, -0.2, 0.1][i % 3]);
  deformGraph(binding, moved, output);
  for (let i = 0; i < output.length; i++)
    assert.ok(
      Math.abs(output[i] - surface[i] - [0.3, -0.2, 0.1][i % 3]) < 1e-14,
    );
});

test("invalid external targets and response edits are rejected", () => {
  const s = new MeasuredGraphSolver(asset);
  assert.throws(() => s.step([NaN]), /controller/);
  assert.throws(
    () => s.apply({ type: "grab", node: 99999, target: [0, 0, 0] }),
    /node/,
  );
  assert.throws(() => s.setParameters([-1, 1, 1, 1]), /parameters/);
  assert.throws(
    () => s.apply({ type: "move", target: [Infinity, 0, 0] }),
    /target/,
  );
});
