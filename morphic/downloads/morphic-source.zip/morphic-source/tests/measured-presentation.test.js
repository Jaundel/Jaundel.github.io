import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import * as THREE from "three";
import { recordedCamera } from "../src/render/recorded-camera.js";
import { validateGaussianData } from "../src/render/gaussian-appearance.js";
import { validateMeasuredSession } from "../src/physics/measured-session.js";
import { validateMeasuredAsset } from "../src/physics/measured-graph.js";
const read = (name) =>
  JSON.parse(
    readFileSync(
      new URL("../public/measured/single_lift_sloth/" + name, import.meta.url),
    ),
  );

test("measured packages preserve the object/controller edge partition", () => {
  const asset = read("asset.json");
  const wrong = structuredClone(asset);
  wrong.objectEdges = asset.edges.length;
  assert.throws(() => validateMeasuredAsset(wrong), /partition/);
  wrong.objectEdges = asset.objectEdges;
  wrong.region[0] = 2;
  assert.throws(() => validateMeasuredAsset(wrong), /partition/);
});

test("recorded camera projects dataset points to the calibrated pixel coordinates", () => {
  const calibration = read("observations.json"),
    asset = read("asset.json");
  const display = new THREE.Group();
  display.rotation.x = Math.PI / 2;
  display.scale.setScalar(4);
  display.position.set(0.2, 0, -0.1);
  const camera = new THREE.PerspectiveCamera();
  recordedCamera(camera, display, calibration, 848, 480);
  const worldToCamera = new THREE.Matrix4()
    .fromArray(calibration.c2w.flat())
    .transpose()
    .invert();
  for (const p of asset.rest.slice(0, 40)) {
    const cv = new THREE.Vector3(...p).applyMatrix4(worldToCamera);
    const ndc = new THREE.Vector3(...p)
      .applyMatrix4(display.matrixWorld)
      .project(camera);
    const u = (ndc.x + 1) * 424,
      v = (1 - ndc.y) * 240;
    assert.ok(
      Math.abs(
        u - ((calibration.K[0][0] * cv.x) / cv.z + calibration.K[0][2]),
      ) < 1e-9,
    );
    assert.ok(
      Math.abs(
        v - ((calibration.K[1][1] * cv.y) / cv.z + calibration.K[1][2]),
      ) < 1e-9,
    );
  }
});

test("Gaussian appearance rejects corrupted node bindings before GPU use", () => {
  const packed = Float32Array.from([
    0, 0, 0, 0.001, 0.5, 0.5, 0.5, 1, 0, 1, 2, 3, 0.25, 0.25, 0.25, 0.25,
  ]);
  const rest = new Float64Array(12);
  validateGaussianData(packed, rest);
  for (const [index, value] of [
    [8, 4],
    [8, 0.5],
    [12, -0.5],
    [3, 0],
    [12, 0.1],
  ]) {
    const bad = packed.slice();
    bad[index] = value;
    assert.throws(() => validateGaussianData(bad, rest));
  }
});

test("session preflight rejects malformed actions and non-finite replay references", () => {
  const session = {
    schema: "morphic-measured-session-1",
    response: read("asset.json"),
    events: [],
    endTick: 0,
    appearance: { glb: "AA==", sha256: "a".repeat(64) },
  };
  session.finalPositions = session.response.rest.flat();
  validateMeasuredSession(session);
  const bad = structuredClone(session);
  bad.events = [
    { tick: 0, action: { type: "grab", node: 99999, target: [0, 0, 0] } },
  ];
  assert.throws(() => validateMeasuredSession(bad), /node/);
  bad.events = [];
  bad.finalPositions[0] = NaN;
  assert.throws(() => validateMeasuredSession(bad), /session/);
});
