import test from "node:test";
import assert from "node:assert/strict";
import { buildCage, deform } from "../src/physics/cage.js";
import { Solver, DT } from "../src/physics/solver.js";
import { volume, rms } from "../src/physics/math.js";
import {
  record,
  makeSession,
  replay,
  validateSession,
} from "../src/physics/session.js";

export function block() {
  return buildCage(
    new Float64Array([
      -0.5, 1, -0.5, 0.5, 1, -0.5, 0.5, 2, -0.5, -0.5, 2, -0.5, -0.5, 1, 0.5,
      0.5, 1, 0.5, 0.5, 2, 0.5, -0.5, 2, 0.5,
    ]),
    new Uint32Array([
      0, 2, 1, 0, 3, 2, 4, 5, 6, 4, 6, 7, 0, 1, 5, 0, 5, 4, 2, 3, 7, 2, 7, 6, 0,
      4, 7, 0, 7, 3, 1, 2, 6, 1, 6, 5,
    ]),
    4,
  );
}
test("positive tetrahedra and exact volume-to-mass accounting", () => {
  const c = block(),
    s = new Solver(c);
  let total = 0;
  for (let t = 0; t < c.tets.length; t += 4) {
    const v = volume(c.rest, ...c.tets.slice(t, t + 4));
    assert.ok(v > 0);
    total += v;
  }
  assert.ok(Math.abs(total - c.volume) < 1e-12);
  assert.ok(Math.abs(s.diagnostics().mass - total * 100) < 1e-9);
});
test("binding reproduces affine maps, including rotation, shear and translation", () => {
  const c = block(),
    before = deform(c, c.rest),
    x = c.rest.slice();
  for (let i = 0; i < x.length; i += 3) {
    const a = x[i],
      b = x[i + 1],
      d = x[i + 2];
    x[i] = -b + 0.2 * d + 3;
    x[i + 1] = a * 1.4 - 1;
    x[i + 2] = d * 0.8 + 2;
  }
  const after = deform(c, x);
  for (let i = 0; i < after.length; i += 3) {
    assert.ok(
      Math.abs(after[i] - (-before[i + 1] + 0.2 * before[i + 2] + 3)) < 1e-6,
    );
    assert.ok(Math.abs(after[i + 1] - (before[i] * 1.4 - 1)) < 1e-6);
  }
  for (let v = 0; v < c.weights.length; v += 4) {
    assert.ok(
      Math.abs(c.weights.slice(v, v + 4).reduce((a, b) => a + b) - 1) < 1e-12,
    );
    assert.ok(c.weights.slice(v, v + 4).every((q) => q >= -1e-12));
  }
});
test("rest pose has no artificial drift in zero gravity", () => {
  const c = block(),
    s = new Solver(c);
  for (let i = 0; i < 240; i++) s.step();
  assert.ok(rms(s.x, c.rest) < 1e-10);
});
test("free fall matches damped semi-implicit analytic recurrence before impact", () => {
  const s = new Solver(block(), { gravity: -9.81 }),
    initial = s.x[1];
  let y = initial,
    v = 0;
  for (let i = 0; i < 30; i++) {
    v = v * Math.exp(-1.5 * DT) - 9.81 * DT;
    y += v * DT;
    s.step();
  }
  assert.ok(Math.abs(s.x[1] - y) < 1e-9);
});
test("single compliant edge converges to its implicit spring solution", () => {
  const s = new Solver(block());
  s.cage = { ...s.cage, edges: new Uint32Array([0, 1]) };
  s.restLength = new Float64Array([1]);
  s.edgeLambda = new Float64Array(1);
  s.x[0] = 0;
  s.x[1] = s.x[2] = s.x[4] = s.x[5] = 0;
  s.x[3] = 2;
  s.invMass[0] = 0;
  s.invMass[1] = 1;
  const compliance = 0.0001,
    alpha = compliance / DT ** 2;
  s.solveEdges(compliance);
  assert.ok(Math.abs(s.x[3] - (2 - 1 / (1 + alpha))) < 1e-12);
  const once = s.x[3];
  s.solveEdges(compliance);
  assert.ok(Math.abs(s.x[3] - once) < 1e-12);
});
test("drop contact stays finite, nonpenetrating, and avoids inverted volume", () => {
  const s = new Solver(block());
  s.apply({ type: "drop" });
  for (let i = 0; i < 600; i++) s.step();
  assert.ok(!s.fault);
  assert.equal(s.diagnostics().inverted, 0);
  assert.ok(s.x.filter((_, i) => i % 3 === 1).every((y) => y >= 0.012 - 1e-10));
  assert.ok(s.diagnostics().meanVolumeError < 0.05);
});
test("action replay reproduces full final state after mixed interactions", () => {
  const c = block(),
    s = new Solver(c);
  for (let i = 0; i < 300; i++) {
    if (i === 0) record(s, { type: "material", value: "rubber" });
    if (i === 10) record(s, { type: "squash" });
    if (i === 190) record(s, { type: "drop" });
    if (i === 220) record(s, { type: "surface", value: "sphere" });
    s.step();
  }
  const copy = replay(c, makeSession(s));
  assert.deepEqual(copy.x, s.x);
  assert.deepEqual(copy.v, s.v);
});
test("invalid inputs and incompatible replay fail explicitly", () => {
  assert.throws(() => buildCage([NaN, 0, 0], [], 8));
  assert.throws(() => new Solver(block(), { dt: 0 }));
  assert.throws(() => validateSession({ engine: "unknown" }));
  assert.throws(() =>
    new Solver(block()).apply({
      type: "grab",
      node: 0,
      target: [Infinity, 1, 1],
    }),
  );
});
