import test from "node:test";
import assert from "node:assert/strict";
import {
  reconstructionBridge,
  validateSubmission,
} from "../scripts/reconstruction-bridge.mjs";

test("reconstruction uploads reject extra views, nonimages and oversized dimensions", () => {
  assert.throws(() => validateSubmission({ images: [] }));
  assert.throws(() => validateSubmission({ images: Array(13).fill("x") }));
  assert.throws(() =>
    validateSubmission({ images: ["data:text/html;base64,AAAA"] }),
  );
  const png = Buffer.alloc(24);
  Buffer.from("89504e470d0a1a0a", "hex").copy(png);
  png.writeUInt32BE(2048, 16);
  png.writeUInt32BE(768, 20);
  assert.throws(() =>
    validateSubmission({
      images: ["data:image/png;base64," + png.toString("base64")],
    }),
  );
});

test("GPU bridge is unavailable by default and rejects cross-origin submissions", async () => {
  let handle;
  reconstructionBridge().configureServer({
    middlewares: {
      use: (_path, fn) => {
        handle = fn;
      },
    },
  });
  async function request(method, headers) {
    let status, body;
    const response = {
      writeHead(code) {
        status = code;
        return this;
      },
      end(value) {
        body = JSON.parse(value);
      },
    };
    await handle({ method, url: "/", headers }, response);
    return { status, body };
  }
  assert.equal(
    (await request("GET", { host: "127.0.0.1:4180" })).body.available,
    false,
  );
  assert.equal(
    (
      await request("POST", {
        host: "127.0.0.1:4180",
        origin: "https://example.com",
        "content-type": "application/json",
      })
    ).status,
    403,
  );
  assert.equal(
    (
      await request("POST", {
        host: "127.0.0.1:4180",
        "content-type": "application/json",
      })
    ).status,
    403,
  );
  assert.equal(
    (await request("GET", { host: "evil.example:4180" })).status,
    403,
  );
});
