import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { validateReconstructionResult } from "../src/io/reconstruction-result.js";

// Existing asset is only a protocol fixture, never a claimed reconstruction.
const bytes = await readFile("public/assets/lemon.glb");
const buffer = bytes.buffer.slice(
  bytes.byteOffset,
  bytes.byteOffset + bytes.byteLength,
);
const report = {
  schema: 1,
  state: "completed",
  stage: "completed",
  method: "trellis-single-image",
  behavior: "assigned",
  hiddenSurfaces: "generated-unverified",
  sourceCommit: "a".repeat(40),
  checkpointRevision: "b".repeat(40),
  input: { sha256: "c".repeat(64) },
  seed: 42,
  pipeline: "trellis-image-large",
  output: {
    bytes: bytes.byteLength,
    sha256: createHash("sha256").update(bytes).digest("hex"),
  },
};

test("reconstruction import binds provenance to the actual GLB bytes", async () => {
  const provenance = await validateReconstructionResult(report, buffer);
  assert.equal(provenance.outputSha256, report.output.sha256);
  assert.equal(provenance.behavior, "assigned");
  const changed = buffer.slice(0);
  new Uint8Array(changed)[changed.byteLength - 1] ^= 1;
  await assert.rejects(
    validateReconstructionResult(report, changed),
    /checksum/,
  );
});

test("failed runs and unsupported physical claims cannot enter as completed reconstruction", async () => {
  await assert.rejects(
    validateReconstructionResult({ ...report, state: "failed" }, buffer),
    /not completed/,
  );
  await assert.rejects(
    validateReconstructionResult({ ...report, behavior: "measured" }, buffer),
    /evidence labels/,
  );
  await assert.rejects(
    validateReconstructionResult(
      { ...report, method: "trellis-multi-image" },
      buffer,
    ),
    /multiple source/,
  );
  await assert.rejects(
    validateReconstructionResult({ ...report, sourceCommit: "main" }, buffer),
    /revision/,
  );
});
