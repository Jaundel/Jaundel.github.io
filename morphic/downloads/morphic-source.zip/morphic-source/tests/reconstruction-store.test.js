import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtemp,
  mkdir,
  copyFile,
  writeFile,
  readFile,
  rm,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve, basename } from "node:path";
import { randomUUID, createHash } from "node:crypto";
import { persistJob, restoreJobs } from "../scripts/reconstruction-store.mjs";
import { reconstructionBridge } from "../scripts/reconstruction-bridge.mjs";

test("server restart restores verified artifacts and keeps unknown jobs interrupted", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "morphic-recovery-"));
  t.after(async () => {
    assert.equal(resolve(root, ".."), resolve(tmpdir()));
    assert.ok(basename(root).startsWith("morphic-recovery-"));
    await rm(root, { recursive: true });
  });
  const completed = {
    id: randomUUID(),
    stage: "completed",
    allocation: "test",
    createdAt: 123,
  };
  completed.local = join(root, completed.id);
  await persistJob(completed);
  await copyFile(
    "tests/fixtures/reconstruction/generated_character.glb",
    join(completed.local, "asset.glb"),
  );
  await copyFile(
    "tests/fixtures/reconstruction/generated_character.json",
    join(completed.local, "result.json"),
  );
  const pending = {
    id: randomUUID(),
    stage: "reconstructing",
    allocation: "test",
    createdAt: 456,
  };
  pending.local = join(root, pending.id);
  await persistJob(pending);
  const restored = await restoreJobs(root);
  assert.equal(restored.get(completed.id).stage, "completed");
  assert.equal(restored.get(pending.id).stage, "interrupted");
  assert.equal(restored.get(pending.id).allocation, "test");

  // A completely new bridge instance serves saved output while GPU is disabled.
  let handler;
  reconstructionBridge({ jobRoot: root }).configureServer({
    middlewares: {
      use(_path, fn) {
        handler = fn;
      },
    },
  });
  async function request(path) {
    let status, data;
    await handler(
      { method: "GET", url: path, headers: { host: "127.0.0.1:4181" } },
      {
        writeHead(code) {
          status = code;
          return this;
        },
        end(value) {
          data = value;
        },
      },
    );
    return { status, data };
  }
  assert.equal(JSON.parse((await request("/")).data).available, false);
  assert.equal(JSON.parse((await request("/jobs")).data).length, 2);
  const output = await request(`/${completed.id}/asset`);
  assert.equal(output.status, 200);
  assert.deepEqual(
    output.data,
    await readFile(join(completed.local, "asset.glb")),
  );
  assert.equal((await request(`/${pending.id}/asset`)).status, 409);

  const settings = {
    MORPHIC_GPU_HOST: "example.invalid",
    MORPHIC_GPU_PORT: "22",
    MORPHIC_GPU_KEY: "unused-test-key",
    MORPHIC_GPU_DEADLINE: new Date(Date.now() + 3600_000).toISOString(),
    MORPHIC_GPU_MAX_JOBS: "1",
  };
  const previous = Object.fromEntries(
    Object.keys(settings).map((key) => [key, process.env[key]]),
  );
  try {
    Object.assign(process.env, settings);
    completed.allocation = createHash("sha256")
      .update(`example.invalid:22:${Date.parse(settings.MORPHIC_GPU_DEADLINE)}`)
      .digest("hex");
    await persistJob(completed);
    reconstructionBridge({ jobRoot: root }).configureServer({
      middlewares: {
        use(_path, fn) {
          handler = fn;
        },
      },
    });
    const status = JSON.parse((await request("/")).data);
    assert.equal(
      status.remainingJobs,
      0,
      "Restart must not reset the paid job allowance",
    );
    assert.equal(status.available, false);
  } finally {
    for (const [key, value] of Object.entries(previous)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  }

  // An old success label cannot turn a corrupt GLB into a valid result.
  await writeFile(join(completed.local, "asset.glb"), "corrupt");
  assert.equal((await restoreJobs(root)).get(completed.id).stage, "invalid");
  await mkdir(join(root, "not-a-job"));
  assert.equal((await restoreJobs(root)).size, 2);
});
