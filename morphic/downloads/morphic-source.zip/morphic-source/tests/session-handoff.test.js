import test from "node:test";
import assert from "node:assert/strict";
import { sessionWorkspace } from "../src/io/session-handoff.js";

test("saved sessions select their solver and unknown formats fail closed", () => {
  assert.equal(
    sessionWorkspace({ schema: "morphic-measured-session-1" }),
    "measured",
  );
  assert.equal(
    sessionWorkspace({ schema: 1, engine: "morphic-xpbd-3" }),
    "capture",
  );
  assert.equal(
    sessionWorkspace({ schema: 1, engine: "morphic-xpbd-2" }),
    "capture",
  );
  for (const invalid of [
    null,
    {},
    { schema: 1 },
    { schema: 1, engine: "other" },
    { schema: "morphic-measured-session-2" },
  ])
    assert.throws(() => sessionWorkspace(invalid), /not a supported/);
});
