import copy
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from co3d_geometry import camera_from_frame
from deform360_geometry import project


class CO3DCameraTests(unittest.TestCase):
    def setUp(self):
        self.frame = {'image': {'size': [128, 256]}, 'viewpoint': {
            'R': np.eye(3).tolist(), 'T': [0, 0, 0],
            'focal_length': [1.2, 1.2], 'principal_point': [.2, .5],
            'intrinsics_format': 'ndc_isotropic'}}

    def test_documented_nonsquare_pytorch3d_example(self):
        c = camera_from_frame(self.frame)
        np.testing.assert_allclose(c['K'], [[76.8, 0, 115.2], [0, 76.8, 32], [0, 0, 1]])
        pixels, front = project([[0, 0, 2], [1, 1, 2], [0, 0, -2]], c)
        np.testing.assert_allclose(pixels[:2], [[115.2, 32], [76.8, -6.4]])
        np.testing.assert_array_equal(front, [True, True, False])

    def test_rotation_translation_and_camera_center(self):
        v = self.frame['viewpoint']
        v['R'] = [[0, -1, 0], [1, 0, 0], [0, 0, 1]]
        v['T'] = [2, 3, 4]
        c = camera_from_frame(self.frame)
        pixels, _ = project([[3, -2, -2]], c)
        np.testing.assert_allclose(pixels, [[115.2, 32]])
        transform = np.asarray(c['worldToCamera'])
        center = -transform[:3, :3].T @ transform[:3, 3]
        np.testing.assert_allclose(center, [3, -2, -4])

    def test_legacy_uses_each_image_dimension(self):
        del self.frame['viewpoint']['intrinsics_format']
        c = camera_from_frame(self.frame)
        np.testing.assert_allclose(c['K'], [[153.6, 0, 102.4], [0, 76.8, 32], [0, 0, 1]])

    def test_invalid_camera_fails_closed(self):
        for key, value in [('R', np.zeros((3, 3)).tolist()), ('T', [0, float('nan'), 0]),
                           ('focal_length', [-1, 1]), ('intrinsics_format', 'unknown')]:
            frame = copy.deepcopy(self.frame)
            frame['viewpoint'][key] = value
            with self.assertRaises(ValueError):
                camera_from_frame(frame)


if __name__ == '__main__':
    unittest.main()
