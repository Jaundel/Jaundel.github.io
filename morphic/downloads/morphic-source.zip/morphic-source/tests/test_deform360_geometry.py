"""Analytical checks independent of the real capture and its held-out images."""
import sys
import unittest
import importlib.util
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from deform360_geometry import project, mask_membership, centroid_ray, intersect_rays, silhouette_iou


class GeometryTests(unittest.TestCase):
    def setUp(self):
        self.camera = {'K': [[100, 0, 50], [0, 100, 50], [0, 0, 1]],
                       'worldToCamera': np.eye(4).tolist()}

    def test_pinhole_projection_and_behind_camera(self):
        pixels, visible = project([[0, 0, 2], [0.2, -0.4, 2], [0, 0, -2]], self.camera)
        np.testing.assert_allclose(pixels[:2], [[50, 50], [60, 30]])
        np.testing.assert_array_equal(visible, [True, True, False])

    def test_world_to_camera_translation(self):
        self.camera['worldToCamera'][0][3] = -1
        pixels, _ = project([[1, 0, 2]], self.camera)
        np.testing.assert_allclose(pixels, [[50, 50]])

    def test_mask_rejects_outside_and_behind(self):
        mask = np.zeros((100, 100), bool)
        mask[45:55, 45:55] = True
        actual = mask_membership([[0, 0, 2], [1, 0, 2], [0, 0, -2]], self.camera, mask)
        np.testing.assert_array_equal(actual, [True, False, False])

    def test_ray_recovery_and_degenerate_views(self):
        mask = np.zeros((101, 101), bool)
        mask[49:52, 49:52] = True
        origin, direction = centroid_ray(self.camera, mask)
        np.testing.assert_allclose(origin, [0, 0, 0])
        np.testing.assert_allclose(direction, [0, 0, 1])
        other_direction = np.array([-1, 0, 2]) / np.sqrt(5)
        np.testing.assert_allclose(intersect_rays([(origin, direction),
            (np.array([1, 0, 0]), other_direction)]), [0, 0, 2], atol=1e-12)
        with self.assertRaises(ValueError):
            intersect_rays([(origin, direction), (np.array([1, 0, 0]), direction)])

    def test_iou_does_not_reward_empty_observations(self):
        self.assertAlmostEqual(silhouette_iou([[1, 1, 0]], [[0, 1, 1]]), 1 / 3)
        self.assertEqual(silhouette_iou([[0, 0]], [[1, 0]]), 0)
        with self.assertRaises(ValueError):
            silhouette_iou([[0, 0]], [[0, 0]])

    def test_mesh_rasterization_matches_analytical_square(self):
        spec = importlib.util.spec_from_file_location('hull', Path(__file__).resolve().parents[1] / 'scripts/reconstruct-deform360-hull.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.camera.update(width=101, height=101)
        mesh = module.trimesh.Trimesh([[-0.2, -0.2, 2], [0.2, -0.2, 2],
                                     [0.2, 0.2, 2], [-0.2, 0.2, 2]],
                                    [[0, 1, 2], [0, 2, 3]], process=False)
        expected = np.zeros((101, 101), bool)
        expected[40:61, 40:61] = True
        np.testing.assert_array_equal(module.render_silhouette(mesh, self.camera), expected)

    def test_similarity_recovers_known_rotation_scale_translation(self):
        spec = importlib.util.spec_from_file_location('align', Path(__file__).resolve().parents[1] / 'scripts/align-capture-mesh.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        source = np.random.default_rng(7).normal(size=(100, 3))
        rotation = module.Rotation.from_euler('xyz', [0.3, -0.4, 0.2]).as_matrix()
        target = source @ rotation.T * 2.5 + [0.2, 0.4, -0.1]
        transform = module.similarity(source, target)
        np.testing.assert_allclose(module.transform_points(source, transform), target, atol=1e-12)


if __name__ == '__main__':
    unittest.main()
