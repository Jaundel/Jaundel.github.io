import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { workerHealth } from "../scripts/worker-health.mjs";
import { reconstructionBridge } from "../scripts/reconstruction-bridge.mjs";

test("worker health expires and a fresh submission never trusts cached readiness", async () => {
  let time = 0,
    reachable = true,
    calls = 0;
  const health = workerHealth(
    async () => {
      calls++;
      if (!reachable) throw Error("connection refused");
      return { stdout: "MORPHIC_WORKER_READY\n" };
    },
    { now: () => time, ttl: 100 },
  );
  assert.equal((await health.check()).ready, true);
  reachable = false;
  assert.equal((await health.check()).ready, true);
  assert.equal(calls, 1);
  assert.equal((await health.check({ fresh: true })).ready, false);
  reachable = true;
  time = 101;
  assert.equal((await health.check()).ready, true);
  assert.equal(calls, 3);
});

test("concurrent health requests share the probe; unrelated output is not readiness", async () => {
  let release,
    calls = 0;
  const health = workerHealth(() => {
    calls++;
    return new Promise((resolve) => {
      release = resolve;
    });
  });
  const first = health.check();
  const second = health.check({ fresh: true });
  release({ stdout: "setup incomplete\n" });
  assert.equal((await first).ready, false);
  assert.equal((await second).ready, false);
  assert.equal(calls, 1);
});

test("stopped worker after ready status cannot create or consume a reconstruction job", async () => {
  const jobRoot = await mkdtemp(join(tmpdir(), "morphic-health-"));
  let handle,
    reachable = true;
  const calls = [];
  try {
    reconstructionBridge({
      jobRoot,
      env: {
        MORPHIC_GPU_HOST: "worker.example",
        MORPHIC_GPU_PORT: "22",
        MORPHIC_GPU_KEY: "/test/key",
        MORPHIC_GPU_DEADLINE: new Date(Date.now() + 3_600_000).toISOString(),
        MORPHIC_GPU_MAX_JOBS: "2",
      },
      executeCommand: async (command, args) => {
        calls.push({ command, args });
        if (!reachable) throw Error("worker stopped");
        return { stdout: "MORPHIC_WORKER_READY\n" };
      },
    }).configureServer({
      middlewares: {
        use: (_path, fn) => {
          handle = fn;
        },
      },
    });
    async function request(method, url = "/") {
      let status, body;
      await handle(
        {
          method,
          url,
          headers: {
            host: "127.0.0.1:4181",
            origin: "http://127.0.0.1:4181",
            "content-type": "application/json",
          },
        },
        {
          writeHead(value) {
            status = value;
          },
          end(value) {
            body = JSON.parse(value);
          },
        },
      );
      return { status, body };
    }
    assert.equal((await request("GET")).body.available, true);
    reachable = false;
    const refused = await request("POST");
    assert.equal(refused.status, 400);
    assert.match(refused.body.error, /No reconstruction was started/);
    assert.deepEqual((await request("GET", "/jobs")).body, []);
    const state = (await request("GET")).body;
    assert.equal(state.available, false);
    assert.equal(state.busy, false);
    assert.equal(state.remainingJobs, 2);
    assert.equal(calls.length, 2);
    assert.ok(
      calls.every(
        (c) => c.command === "ssh" && c.args.at(-1).startsWith("test -f"),
      ),
    );
  } finally {
    await rm(jobRoot, { recursive: true, force: true });
  }
});
