import { defineConfig } from "vite";
import { localArtifacts } from "./scripts/local-artifacts.mjs";
import { reconstructionBridge } from "./scripts/reconstruction-bridge.mjs";
export default defineConfig({
  base: "./",
  plugins: [localArtifacts(), reconstructionBridge()],
  build: {
    rollupOptions: {
      input: {
        studio: "index.html",
        article: "article.html",
        guide: "guide.html",
        synthetic: "synthetic.html",
      },
    },
  },
});
